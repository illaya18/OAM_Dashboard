"""
THD OAM Weekly Report Generator
Run this script any time Productivity_Sheet.xlsx is updated.
Produces: THD_OAM_Weekly_Report_<week>.xlsx  in the same directory.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "thd_portal"))

import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime
from openpyxl import Workbook
from openpyxl.styles import (
    PatternFill, Font, Alignment, Border, Side, GradientFill
)
from openpyxl.utils import get_column_letter
from openpyxl.chart import BarChart, PieChart, LineChart, Reference
from openpyxl.chart.series import DataPoint
from openpyxl.formatting.rule import ColorScaleRule, DataBarRule

from data_processor import load_all, BENCHMARKS

# ─── THD Color Palette ────────────────────────────────────────────────────────
C_ORANGE      = "F96302"
C_DARK_ORANGE = "CC4E00"
C_BLACK       = "000000"
C_WHITE       = "FFFFFF"
C_LIGHT_ORG   = "FFF3EB"
C_PALE_ORG    = "FFE0C8"
C_GRAY_DARK   = "333333"
C_GRAY_MID    = "666666"
C_GRAY_LIGHT  = "F5F5F5"
C_GREEN       = "1E8449"
C_AMBER       = "F39C12"
C_RED         = "C0392B"
C_GREEN_LIGHT = "D5F5E3"
C_AMBER_LIGHT = "FDEBD0"
C_RED_LIGHT   = "FADBD8"

# ─── Pre-built shared style objects (created once, reused everywhere) ─────────
_SIDE          = Side(style="thin", color=C_GRAY_MID)
_BORDER        = Border(left=_SIDE, right=_SIDE, top=_SIDE, bottom=_SIDE)
_FILLS: dict   = {}   # hex → PatternFill, populated lazily
_FONTS: dict   = {}   # (color, bold, size) → Font

def fill(hex_color):
    if hex_color not in _FILLS:
        _FILLS[hex_color] = PatternFill(start_color=hex_color,
                                        end_color=hex_color, fill_type="solid")
    return _FILLS[hex_color]

def font(color=C_BLACK, bold=False, size=11, name="Calibri"):
    key = (color, bold, size)
    if key not in _FONTS:
        _FONTS[key] = Font(color=color, bold=bold, size=size, name=name)
    return _FONTS[key]

def border(style="thin"):
    return _BORDER

def align(h="center", v="center", wrap=False):
    return Alignment(horizontal=h, vertical=v, wrap_text=wrap)

def hdr(ws, row, col, text, bg=C_ORANGE, fg=C_WHITE, bold=True, size=11, h_align="center"):
    c = ws.cell(row=row, column=col, value=text)
    c.fill  = fill(bg)
    c.font  = font(fg, bold, size)
    c.alignment = align(h_align, "center")
    c.border = border()
    return c

def val(ws, row, col, text, bg=C_WHITE, fg=C_BLACK, bold=False, size=10, h_align="center"):
    c = ws.cell(row=row, column=col, value=text)
    c.fill  = fill(bg)
    c.font  = font(fg, bold, size)
    c.alignment = align(h_align, "center", True)
    c.border = border()
    return c

def kpi_color(value, target, lower_is_better=True):
    """Return background color based on performance vs target."""
    if value is None or pd.isna(value):
        return C_GRAY_LIGHT
    ratio = value / target if target else 0
    if lower_is_better:
        if ratio <= 0.9:   return C_GREEN_LIGHT
        if ratio <= 1.1:   return C_AMBER_LIGHT
        return C_RED_LIGHT
    else:
        if ratio >= 1.1:   return C_GREEN_LIGHT
        if ratio >= 0.9:   return C_AMBER_LIGHT
        return C_RED_LIGHT

def set_col_width(ws, col, width):
    ws.column_dimensions[get_column_letter(col)].width = width

def merge_hdr(ws, r1, c1, r2, c2, text, bg=C_ORANGE, fg=C_WHITE, size=13):
    ws.merge_cells(start_row=r1, start_column=c1, end_row=r2, end_column=c2)
    c = ws.cell(row=r1, column=c1, value=text)
    c.fill = fill(bg); c.font = font(fg, True, size)
    c.alignment = align("center", "center")
    return c

def pct_str(v): return f"{v:.1f}%" if v is not None and not (isinstance(v, float) and np.isnan(v)) else "N/A"
def min_str(v): return f"{v:.0f} min" if v is not None and not (isinstance(v, float) and np.isnan(v)) else "N/A"
def hrs_str(v): return f"{v:.1f} hrs" if v is not None and not (isinstance(v, float) and np.isnan(v)) else "N/A"
def num_str(v): return str(int(v)) if v is not None and not (isinstance(v, float) and np.isnan(v)) else "N/A"


# ═══════════════════════════════════════════════════════════════════════════════
# SHEET BUILDERS
# ═══════════════════════════════════════════════════════════════════════════════

def _legend_row(ws, row, start_col=1, end_col=8):
    """Add a color-coding legend row at the given row."""
    ws.merge_cells(start_row=row, start_column=start_col,
                   end_row=row, end_column=start_col + 1)
    lbl = ws.cell(row=row, column=start_col, value="Color Legend:")
    lbl.font = font(C_GRAY_DARK, True, 9); lbl.alignment = align("right", "center")

    legend = [
        ("Meeting Target", C_GREEN_LIGHT, C_GREEN),
        ("Near Target",    C_AMBER_LIGHT, C_AMBER),
        ("Below Target",   C_RED_LIGHT,   C_RED),
    ]
    for i, (txt, bg, fg) in enumerate(legend):
        c = ws.cell(row=row, column=start_col + 2 + i)
        c.value = txt; c.fill = fill(bg); c.font = font(fg, True, 9)
        c.alignment = align("center", "center"); c.border = border()


def build_cover(wb, data):
    ws = wb.active
    ws.title = "Cover"
    ws.sheet_view.showGridLines = False

    snap = data["snapshot"]
    bv   = data["business_value_kpis"]
    tr   = data["transferred_summary"]
    wk   = data["weekly_kpis"]

    # ── Orange header band (rows 1-8) ─────────────────────────────────────────
    orange_fill = fill(C_ORANGE)
    for r in range(1, 9):
        for c in range(1, 22):
            ws.cell(row=r, column=c).fill = orange_fill

    ws.merge_cells("B2:T3")
    c = ws.cell(row=2, column=2,
                value="THE HOME DEPOT  |  OAM Supplier Support Analytics")
    c.font = font(C_WHITE, True, 24, "Calibri"); c.alignment = align("center", "center")

    ws.merge_cells("B4:T5")
    c2 = ws.cell(row=4, column=2,
                 value=f"Weekly Report  ·  {snap.get('week_label','Latest')}  "
                       f"·  Auto-Generated: {datetime.now().strftime('%d %b %Y')}")
    c2.font = font(C_PALE_ORG, False, 13); c2.alignment = align("center", "center")

    ws.merge_cells("B6:T7")
    c3 = ws.cell(row=6, column=2,
                 value="Prepared by iOPEX Technologies  |  Confidential — For Internal Use Only")
    c3.font = font(C_WHITE, False, 10); c3.alignment = align("center", "center")

    # ── Section: Key Metrics ──────────────────────────────────────────────────
    merge_hdr(ws, 10, 2, 10, 20, "KEY METRICS AT A GLANCE — Current Week",
              bg=C_BLACK, fg=C_WHITE, size=12)

    kpis_display = [
        ("Total Volume",         num_str(snap.get("total_volume")),      C_ORANGE,    "contacts"),
        ("FCR Rate",             pct_str(snap.get("fcr_pct")),
         C_GREEN if (snap.get("fcr_pct") or 0) >= 80 else C_RED,                      "Benchmark ≥80%"),
        ("Chat FRT",             min_str(snap.get("frt_chat")),
         C_GREEN if (snap.get("frt_chat") or 999) <= 1 else C_AMBER,                  "Benchmark ≤1 min"),
        ("Mail FRT",             min_str(snap.get("frt_mail")),
         C_GREEN if (snap.get("frt_mail") or 999) <= 60 else C_AMBER,                 "Benchmark ≤60 min"),
        ("Transfer Rate",        pct_str(snap.get("transfer_rate_pct")),
         C_GREEN if (snap.get("transfer_rate_pct") or 99) <= 5 else C_AMBER,          "Benchmark ≤5%"),
        ("After-Hours %",        pct_str(snap.get("after_hours_pct")),   C_ORANGE,    "informational"),
        ("Transferred Resolved", pct_str(tr.get("completion_pct")),
         C_GREEN if (tr.get("completion_pct") or 0) >= 80 else C_AMBER,               "target ≥80%"),
        ("Unique Brands",        num_str(bv.get("unique_brands_served")), C_ORANGE,   "brands supported"),
    ]

    # 4 cards per row, 2 rows — each card = 4 columns wide + 1 gap
    for i, (label, value, color, note) in enumerate(kpis_display):
        row_base = 12 if i < 4 else 18
        col_base = 2 + (i % 4) * 5

        # Label row
        ws.merge_cells(start_row=row_base, start_column=col_base,
                       end_row=row_base, end_column=col_base + 3)
        lc = ws.cell(row=row_base, column=col_base, value=label)
        lc.fill = fill(C_GRAY_DARK); lc.font = font(C_WHITE, True, 9)
        lc.alignment = align("center", "center")

        # Value row
        ws.merge_cells(start_row=row_base + 1, start_column=col_base,
                       end_row=row_base + 2, end_column=col_base + 3)
        vc = ws.cell(row=row_base + 1, column=col_base, value=value)
        vc.fill = fill(C_LIGHT_ORG); vc.font = font(color, True, 18)
        vc.alignment = align("center", "center")

        # Note row
        ws.merge_cells(start_row=row_base + 3, start_column=col_base,
                       end_row=row_base + 3, end_column=col_base + 3)
        nc = ws.cell(row=row_base + 3, column=col_base, value=note)
        nc.fill = fill(C_GRAY_LIGHT); nc.font = font(C_GRAY_MID, False, 8)
        nc.alignment = align("center", "center")

    # ── Row heights & row separators ──────────────────────────────────────────
    ws.row_dimensions[2].height = 36
    ws.row_dimensions[4].height = 22
    for r in [12, 18]:
        ws.row_dimensions[r].height = 18
    for r in [13, 14, 19, 20]:
        ws.row_dimensions[r].height = 28
    for r in [15, 21]:
        ws.row_dimensions[r].height = 16

    # ── Section: Benchmarks reference ────────────────────────────────────────
    merge_hdr(ws, 24, 2, 24, 20, "BENCHMARK REFERENCE & KPI GLOSSARY",
              bg=C_DARK_ORANGE, fg=C_WHITE, size=11)

    bm_data = [
        ("FCR (First Contact Resolution)", "% of contacts closed on first interaction", "≥ 80%",
         "Higher is better. Reflects team capability and knowledge depth."),
        ("FRT — Chat (First Response Time)", "Time from chat start to first agent reply", "≤ 1 min",
         "Lower is better. Chat contacts expect near-instant responses."),
        ("FRT — Mail (First Response Time)", "Time from email receipt to first reply sent", "≤ 60 min",
         "Lower is better. Email SLA window is 1 business hour."),
        ("AHT (Average Handling Time)", "Total time agent spends on a contact end-to-end", "≤ 30 min",
         "Lower is better, but must not compromise resolution quality."),
        ("Transfer / Escalation Rate", "% of contacts transferred to another team", "≤ 5%",
         "Lower is better. High rates indicate scope or knowledge gaps."),
        ("Resolution Time", "Time from contact received to fully resolved", "≤ 30 min",
         "Lower is better. Directly impacts supplier satisfaction."),
    ]

    bm_hdrs = ["KPI", "Definition", "Target", "Interpretation"]
    for ci, h in enumerate(bm_hdrs, 2):
        hdr(ws, 25, ci, h, bg=C_ORANGE)

    for ri, (kpi, defn, tgt, interp) in enumerate(bm_data, 26):
        bg = C_LIGHT_ORG if ri % 2 == 0 else C_WHITE
        val(ws, ri, 2, kpi,   bg, bold=True, h_align="left")
        val(ws, ri, 3, defn,  bg, h_align="left")
        val(ws, ri, 4, tgt,   C_GREEN_LIGHT, C_GREEN, bold=True)
        val(ws, ri, 5, interp, bg, h_align="left")
        ws.row_dimensions[ri].height = 22

    # ── Section: YTD Summary ──────────────────────────────────────────────────
    fy_label = snap.get("fiscal_year", "FY26")
    ytd_rows = wk[wk["Fiscal_Year_Label"] == fy_label] if "Fiscal_Year_Label" in wk.columns else wk
    ytd_row = 34
    merge_hdr(ws, ytd_row, 2, ytd_row, 20,
              f"YEAR-TO-DATE SUMMARY  ({fy_label}  —  {len(ytd_rows)} weeks covered)",
              bg=C_BLACK, fg=C_WHITE, size=11)

    ytd_cols = [
        ("Weeks Covered",  len(ytd_rows)),
        ("Total Volume",   int(ytd_rows["Total_Volume"].sum()) if len(ytd_rows) else 0),
        ("Mail Volume",    int(ytd_rows["Mail_Volume"].sum()) if len(ytd_rows) else 0),
        ("Chat Volume",    int(ytd_rows["Chat_Volume"].sum()) if len(ytd_rows) else 0),
        ("Avg FCR %",      pct_str(ytd_rows["FCR_Pct"].mean() if len(ytd_rows) else None)),
        ("Avg Transfer %", pct_str(ytd_rows["Transfer_Rate_Pct"].mean() if len(ytd_rows) else None)),
        ("Avg AHT Mail",   min_str(ytd_rows["Avg_AHT_Mail_min"].mean(skipna=True) if len(ytd_rows) else None)),
        ("Avg FRT Chat",   min_str(ytd_rows["Avg_FRT_Chat_min"].mean(skipna=True) if len(ytd_rows) else None)),
    ]
    for ci, (lbl, v) in enumerate(ytd_cols, 2):
        hdr(ws, ytd_row + 1, ci + ci - 2, lbl, bg=C_ORANGE, size=9)
        val(ws, ytd_row + 2, ci + ci - 2, str(v), C_LIGHT_ORG, C_ORANGE, bold=True, size=13)
        ws.merge_cells(start_row=ytd_row + 1, start_column=ci + ci - 2,
                       end_row=ytd_row + 1, end_column=ci + ci - 1)
        ws.merge_cells(start_row=ytd_row + 2, start_column=ci + ci - 2,
                       end_row=ytd_row + 3, end_column=ci + ci - 1)

    # ── Column widths ─────────────────────────────────────────────────────────
    ws.column_dimensions["A"].width = 2
    for i in range(2, 22):
        ws.column_dimensions[get_column_letter(i)].width = 9
    # Wider for definition columns
    ws.column_dimensions["C"].width = 28
    ws.column_dimensions["D"].width = 14
    ws.column_dimensions["E"].width = 38


def build_weekly_scorecard(wb, data):
    ws = wb.create_sheet("Weekly Scorecard")
    ws.sheet_view.showGridLines = False

    snap = data["snapshot"]
    wk   = data["weekly_kpis"]
    tr   = data["transferred_summary"]

    # Header
    merge_hdr(ws, 1, 1, 2, 14,
              f"OAM SUPPLIER SUPPORT SCORE CARD  |  {snap.get('week_label','Latest')}",
              bg=C_ORANGE, fg=C_WHITE, size=14)

    # ── Section 1: Weekly Stats ─────────────────────────────────────────────
    merge_hdr(ws, 4, 1, 4, 14, "WEEKLY SUPPLIER SUPPORT", bg=C_BLACK, fg=C_WHITE, size=12)

    headers = ["", "OAM INBOX", "FRONT CHAT", "TOTAL"]
    for ci, h in enumerate(headers, 1):
        hdr(ws, 5, ci, h)

    latest = wk.iloc[-1] if len(wk) else pd.Series(dtype=float)
    prev   = wk.iloc[-2] if len(wk) >= 2 else pd.Series(dtype=float)

    def delta_str(cur, prv, label):
        if pd.isna(cur) or pd.isna(prv): return ""
        d = cur - prv
        arrow = "↑" if d > 0 else "↓" if d < 0 else "→"
        return f"{arrow} {abs(d):.0f}"

    rows_data = [
        ("Total Messages Received",
         num_str(latest.get("Mail_Volume")),
         num_str(latest.get("Chat_Volume")),
         num_str(latest.get("Total_Volume"))),
        ("FCR Rate",
         pct_str(latest.get("FCR_Pct")),
         "100%",
         pct_str(latest.get("FCR_Pct"))),
        ("Avg AHT",
         min_str(latest.get("Avg_AHT_Mail_min")),
         min_str(latest.get("Avg_AHT_Chat_min")),
         ""),
        ("Avg First Response Time",
         min_str(latest.get("Avg_FRT_Mail_min")),
         min_str(latest.get("Avg_FRT_Chat_min")),
         ""),
        ("Avg Resolution Time",
         min_str(latest.get("Avg_Res_Mail_min")),
         min_str(latest.get("Avg_Res_Chat_min")),
         ""),
        ("Transfer Rate",
         pct_str(latest.get("Transfer_Rate_Pct")),
         "—",
         pct_str(latest.get("Transfer_Rate_Pct"))),
        ("After-Hours Support",
         pct_str(latest.get("AfterHours_Pct")),
         "—",
         pct_str(latest.get("AfterHours_Pct"))),
        ("Transferred Tickets",
         str(tr["total"]),
         "—",
         str(tr["total"])),
        ("Transferred Resolved",
         pct_str(tr["completion_pct"]),
         "—",
         pct_str(tr["completion_pct"])),
    ]

    for ri, (label, mail_v, chat_v, total_v) in enumerate(rows_data, 6):
        bg = C_LIGHT_ORG if ri % 2 == 0 else C_WHITE
        val(ws, ri, 1, label,  bg, C_GRAY_DARK, bold=True, h_align="left")
        val(ws, ri, 2, mail_v, bg)
        val(ws, ri, 3, chat_v, bg)
        val(ws, ri, 4, total_v, bg)

    # ── Section 2: KPI vs Benchmark ────────────────────────────────────────
    bench_row = len(rows_data) + 8
    merge_hdr(ws, bench_row, 1, bench_row, 14,
              "KPI PERFORMANCE vs BENCHMARK", bg=C_DARK_ORANGE, fg=C_WHITE, size=12)
    bench_row += 1

    bh = ["KPI", "Benchmark", "Chat — Current", "Chat — vLW", "Chat — vBench",
          "Mail — Current", "Mail — vLW", "Mail — vBench"]
    for ci, h in enumerate(bh, 1):
        hdr(ws, bench_row, ci, h)

    bench_kpis = [
        ("Response Time (FRT)",
         "Chat ≤1 min  |  Mail ≤60 min",
         min_str(latest.get("Avg_FRT_Chat_min")),
         "",
         pct_str(BENCHMARKS["chat_frt_min"] / latest["Avg_FRT_Chat_min"] * 100
                 if latest.get("Avg_FRT_Chat_min") and latest.get("Avg_FRT_Chat_min") > 0 else None),
         min_str(latest.get("Avg_FRT_Mail_min")),
         "",
         pct_str(BENCHMARKS["mail_frt_min"] / latest["Avg_FRT_Mail_min"] * 100
                 if latest.get("Avg_FRT_Mail_min") and latest.get("Avg_FRT_Mail_min") > 0 else None),
         latest.get("Avg_FRT_Chat_min"), BENCHMARKS["chat_frt_min"],
         latest.get("Avg_FRT_Mail_min"), BENCHMARKS["mail_frt_min"],
         ),
        ("Resolution Time",
         "≤ 30 min",
         min_str(latest.get("Avg_Res_Chat_min")),
         "", "",
         min_str(latest.get("Avg_Res_Mail_min")),
         "", "",
         latest.get("Avg_Res_Chat_min"), BENCHMARKS["resolution_min"],
         latest.get("Avg_Res_Mail_min"), BENCHMARKS["resolution_min"],
         ),
        ("FCR",
         "≥ 80%",
         "100%", "", "125%",
         pct_str(latest.get("FCR_Pct")), "", "",
         None, None, None, None,
         ),
        ("Escalation Rate",
         "≤ 5%",
         "0%", "", "100%",
         pct_str(latest.get("Transfer_Rate_Pct")), "", "",
         latest.get("Transfer_Rate_Pct"), BENCHMARKS["escalation_rate_pct"],
         None, None,
         ),
    ]

    for ri, row_data in enumerate(bench_kpis, bench_row + 1):
        fields = row_data[:8]
        chat_act, chat_tgt, mail_act, mail_tgt = row_data[8], row_data[9], row_data[10], row_data[11]
        bg_base = C_LIGHT_ORG if ri % 2 == 0 else C_WHITE

        for ci, fld in enumerate(fields, 1):
            col_bg = bg_base
            if ci in (3, 5):
                col_bg = kpi_color(chat_act, chat_tgt, lower_is_better=True) if chat_act and chat_tgt else bg_base
            if ci in (6, 8):
                col_bg = kpi_color(mail_act, mail_tgt, lower_is_better=True) if mail_act and mail_tgt else bg_base
            v = val(ws, ri, ci, fld, col_bg,
                    bold=(ci == 1), h_align="left" if ci <= 2 else "center")

    # ── Section 3: YTD Summary ─────────────────────────────────────────────
    ytd_start = bench_row + len(bench_kpis) + 3
    fy_label = snap.get("fiscal_year", "FY26")
    ytd_rows = wk[wk["Fiscal_Year_Label"] == fy_label] if "Fiscal_Year_Label" in wk.columns else wk
    merge_hdr(ws, ytd_start, 1, ytd_start, 8,
              f"YEAR-TO-DATE SUMMARY  ({fy_label}  —  {len(ytd_rows)} weeks)",
              bg=C_BLACK, fg=C_WHITE, size=12)

    ytd_hdrs = ["Metric", "YTD Value", "KPI Note"]
    for ci, h in enumerate(ytd_hdrs, 1):
        hdr(ws, ytd_start + 1, ci, h)

    ytd_kpis = [
        ("Total Volume",          num_str(ytd_rows["Total_Volume"].sum() if len(ytd_rows) else 0),
         "Cumulative contacts handled since start of fiscal year"),
        ("Mail Volume",           num_str(ytd_rows["Mail_Volume"].sum() if len(ytd_rows) else 0),
         "Email contacts — OAM inbox"),
        ("Chat Volume",           num_str(ytd_rows["Chat_Volume"].sum() if len(ytd_rows) else 0),
         "Live chat contacts — Front platform"),
        ("Avg FCR Rate",          pct_str(ytd_rows["FCR_Pct"].mean() if len(ytd_rows) else None),
         "Average first-contact resolution rate across all weeks"),
        ("Avg Transfer Rate",     pct_str(ytd_rows["Transfer_Rate_Pct"].mean() if len(ytd_rows) else None),
         "Average escalation rate — benchmark ≤5%"),
        ("Avg After-Hours %",     pct_str(ytd_rows["AfterHours_Pct"].mean() if len(ytd_rows) else None),
         "Average % of contacts outside business hours"),
        ("Avg AHT Mail",          min_str(ytd_rows["Avg_AHT_Mail_min"].mean(skipna=True) if len(ytd_rows) else None),
         "Average handling time for mail — benchmark ≤30 min"),
        ("Avg AHT Chat",          min_str(ytd_rows["Avg_AHT_Chat_min"].mean(skipna=True) if len(ytd_rows) else None),
         "Average handling time for chat — benchmark ≤30 min"),
        ("Avg FRT Mail",          min_str(ytd_rows["Avg_FRT_Mail_min"].mean(skipna=True) if len(ytd_rows) else None),
         "Average first response time for mail — benchmark ≤60 min"),
        ("Avg FRT Chat",          min_str(ytd_rows["Avg_FRT_Chat_min"].mean(skipna=True) if len(ytd_rows) else None),
         "Average first response time for chat — benchmark ≤1 min"),
    ]
    for ri, (metric, ytd_val, note) in enumerate(ytd_kpis, ytd_start + 2):
        bg = C_LIGHT_ORG if ri % 2 == 0 else C_WHITE
        val(ws, ri, 1, metric,  bg, bold=True, h_align="left")
        val(ws, ri, 2, ytd_val, C_LIGHT_ORG, C_ORANGE, bold=True)
        val(ws, ri, 3, note,    bg, h_align="left")
        ws.row_dimensions[ri].height = 18

    # Legend
    _legend_row(ws, ytd_start + len(ytd_kpis) + 3, start_col=1)

    # Column widths
    widths = [30, 16, 14, 10, 12, 14, 10, 12, 40]
    for i, w in enumerate(widths, 1):
        set_col_width(ws, i, w)

    ws.freeze_panes = "A5"


def build_brand_analysis(wb, data):
    ws = wb.create_sheet("Brand Analysis")
    ws.sheet_view.showGridLines = False

    brand = data["brand_analysis"]
    bs    = brand["brand_summary"]

    merge_hdr(ws, 1, 1, 2, 12,
              "BRAND INTELLIGENCE  —  Repeated vs New Issues",
              bg=C_ORANGE, fg=C_WHITE, size=14)

    # Summary banner
    hdr(ws, 4, 1, "Total Issues");    val(ws, 4, 2, brand["total_issues"], C_LIGHT_ORG, bold=True)
    hdr(ws, 4, 3, "New Issues");      val(ws, 4, 4, brand["new_issues"],    C_GREEN_LIGHT, C_GREEN, bold=True)
    hdr(ws, 4, 5, "Repeated Issues"); val(ws, 4, 6, brand["repeated_issues"], C_AMBER_LIGHT, C_AMBER, bold=True)
    hdr(ws, 4, 7, "% New");           val(ws, 4, 8, pct_str(brand["new_pct"]),      C_GREEN_LIGHT, C_GREEN, bold=True)
    hdr(ws, 4, 9, "% Repeated");      val(ws, 4, 10, pct_str(brand["repeated_pct"]), C_AMBER_LIGHT, C_AMBER, bold=True)

    # Brand table
    merge_hdr(ws, 6, 1, 6, 12, "BRAND-WISE ISSUE ANALYSIS", bg=C_BLACK, fg=C_WHITE, size=11)

    col_hdrs = ["Brand Name", "Total Issues", "New Issues", "Repeated Issues",
                "% Repeated", "Weeks Active", "Top Category", "Last Seen"]
    for ci, h in enumerate(col_hdrs, 1):
        hdr(ws, 7, ci, h)

    for ri, row in bs.iterrows():
        r = 8 + list(bs.index).index(ri)
        bg = C_LIGHT_ORG if r % 2 == 0 else C_WHITE
        rep_pct = row.get("Repeated_Pct", 0)
        rep_bg  = C_GREEN_LIGHT if rep_pct == 0 else (C_AMBER_LIGHT if rep_pct < 50 else C_RED_LIGHT)

        val(ws, r, 1, row["Brand Name"],          bg, bold=True, h_align="left")
        val(ws, r, 2, int(row["Total_Issues"]),    bg)
        val(ws, r, 3, int(row["New_Issues"]),      C_GREEN_LIGHT, C_GREEN)
        val(ws, r, 4, int(row["Repeated_Issues"]), rep_bg)
        val(ws, r, 5, pct_str(rep_pct),           rep_bg, bold=True)
        val(ws, r, 6, int(row["Weeks_Active"]),    bg)
        val(ws, r, 7, str(row["Top_Category"])[:30], bg, h_align="left")
        last = row.get("Last_Seen")
        val(ws, r, 8, pd.Timestamp(last).strftime("%d %b %Y") if pd.notna(last) else "—", bg)

    # Category drilldown
    cat_row = 8 + len(bs) + 3
    merge_hdr(ws, cat_row, 1, cat_row, 8,
              "REPEATED ISSUES BY CATEGORY (Brand + Category drilldown)",
              bg=C_DARK_ORANGE, fg=C_WHITE, size=11)
    cat_row += 1

    cat_hdrs = ["Brand Name", "Category", "Total Occurrences", "New", "Repeated", "Repeated %"]
    for ci, h in enumerate(cat_hdrs, 1):
        hdr(ws, cat_row, ci, h)

    cs = brand["cat_summary"][brand["cat_summary"]["Repeated"] > 0].head(30)
    for i, (_, row) in enumerate(cs.iterrows()):
        r = cat_row + 1 + i
        bg = C_LIGHT_ORG if r % 2 == 0 else C_WHITE
        rep_pct = round(row["Repeated"] / row["Count"] * 100, 1)
        val(ws, r, 1, row["Brand Name"],    bg, bold=True, h_align="left")
        val(ws, r, 2, row["Category"],      bg, h_align="left")
        val(ws, r, 3, int(row["Count"]),    bg)
        val(ws, r, 4, int(row["New"]),      C_GREEN_LIGHT, C_GREEN)
        val(ws, r, 5, int(row["Repeated"]), C_AMBER_LIGHT, C_AMBER)
        val(ws, r, 6, pct_str(rep_pct),     C_AMBER_LIGHT, bold=True)

    set_col_width(ws, 1, 30); set_col_width(ws, 2, 12); set_col_width(ws, 3, 12)
    set_col_width(ws, 4, 12); set_col_width(ws, 5, 14); set_col_width(ws, 6, 14)
    set_col_width(ws, 7, 32); set_col_width(ws, 8, 14)

    # Interpretation note
    note_row = cat_row + 1 + len(cs) + 2
    merge_hdr(ws, note_row, 1, note_row, 8,
              "HOW TO READ THIS SHEET", bg=C_GRAY_LIGHT, fg=C_GRAY_DARK, size=10)
    notes = [
        "New Issue: First time this Brand + Category combination appears in the data. "
        "Action: Ensure the team is familiar with this brand's supplier requirements.",
        "Repeated Issue: Same Brand + Category appeared in a prior week. "
        "Action: Investigate root cause — is the supplier receiving incorrect guidance? "
        "Is there a process gap that needs escalation?",
        "% Repeated < 20%: Healthy — most issues are being resolved permanently.",
        "% Repeated 20–50%: Monitor — some patterns are recurring; review root causes.",
        "% Repeated > 50%: Alert — significant recurrence; proactive supplier coaching recommended.",
    ]
    for i, note in enumerate(notes, note_row + 1):
        ws.merge_cells(start_row=i, start_column=1, end_row=i, end_column=8)
        c = ws.cell(row=i, column=1, value=("• " + note))
        bg = C_GREEN_LIGHT if "< 20%" in note else (C_AMBER_LIGHT if "20–50%" in note
             else (C_RED_LIGHT if "> 50%" in note else C_WHITE))
        c.fill = fill(bg); c.font = font(C_GRAY_DARK, False, 9)
        c.alignment = align("left", "center", True); c.border = border()
        ws.row_dimensions[i].height = 24

    ws.auto_filter.ref = f"A7:H7"
    ws.freeze_panes = "A8"


def build_channel_analysis(wb, data):
    ws = wb.create_sheet("Channel Performance")
    ws.sheet_view.showGridLines = False

    wk   = data["weekly_kpis"]
    snap = data["snapshot"]

    merge_hdr(ws, 1, 1, 2, 14, "CHANNEL PERFORMANCE  —  Chat vs Mail",
              bg=C_ORANGE, fg=C_WHITE, size=14)

    # Current week comparison table
    merge_hdr(ws, 4, 1, 4, 7, "CURRENT WEEK  —  KPI vs BENCHMARK",
              bg=C_BLACK, fg=C_WHITE, size=12)

    hdrs = ["KPI", "Benchmark", "CHAT Current", "CHAT Status", "MAIL Current", "MAIL Status"]
    for ci, h in enumerate(hdrs, 1):
        hdr(ws, 5, ci, h)

    def status(actual, target, lower_is_better=True):
        if actual is None or pd.isna(actual): return "N/A"
        if lower_is_better:
            if actual <= target: return "✓ Meeting"
            return "✗ Below Target"
        else:
            if actual >= target: return "✓ Meeting"
            return "✗ Below Target"

    def status_bg(actual, target, lower_is_better=True):
        if actual is None or pd.isna(actual): return C_GRAY_LIGHT
        if lower_is_better:
            return C_GREEN_LIGHT if actual <= target else C_RED_LIGHT
        return C_GREEN_LIGHT if actual >= target else C_RED_LIGHT

    channel_rows = [
        ("First Response Time",
         f"Chat ≤{BENCHMARKS['chat_frt_min']} min  |  Mail ≤{BENCHMARKS['mail_frt_min']} min",
         min_str(snap.get("frt_chat")), snap.get("frt_chat"), BENCHMARKS["chat_frt_min"], True,
         min_str(snap.get("frt_mail")), snap.get("frt_mail"), BENCHMARKS["mail_frt_min"], True),
        ("Avg Handling Time (AHT)",
         f"≤ {BENCHMARKS['aht_min']} min",
         min_str(snap.get("aht_chat")), snap.get("aht_chat"), BENCHMARKS["aht_min"], True,
         min_str(snap.get("aht_mail")), snap.get("aht_mail"), BENCHMARKS["aht_min"], True),
        ("Resolution Time",
         f"≤ {BENCHMARKS['resolution_min']} min",
         min_str(snap.get("res_chat")), snap.get("res_chat"), BENCHMARKS["resolution_min"], True,
         min_str(snap.get("res_mail")), snap.get("res_mail"), BENCHMARKS["resolution_min"], True),
        ("FCR", "≥ 80%",
         "100%", 100, 80, False,
         pct_str(snap.get("fcr_pct")), snap.get("fcr_pct"), 80, False),
    ]

    for ri, row in enumerate(channel_rows, 6):
        bg = C_LIGHT_ORG if ri % 2 == 0 else C_WHITE
        (label, bench, chat_disp, chat_val_, chat_tgt, chat_lower,
         mail_disp, mail_val_, mail_tgt, mail_lower) = row

        val(ws, ri, 1, label,      bg, bold=True, h_align="left")
        val(ws, ri, 2, bench,      bg, h_align="left")
        val(ws, ri, 3, chat_disp,  bg, bold=True)
        val(ws, ri, 4, status(chat_val_, chat_tgt, chat_lower),
            status_bg(chat_val_, chat_tgt, chat_lower))
        val(ws, ri, 5, mail_disp,  bg, bold=True)
        val(ws, ri, 6, status(mail_val_, mail_tgt, mail_lower),
            status_bg(mail_val_, mail_tgt, mail_lower))

    # Category distribution
    cat_start = 13
    merge_hdr(ws, cat_start, 1, cat_start, 7,
              "REQUEST CATEGORY DISTRIBUTION (Chat vs Mail)",
              bg=C_DARK_ORANGE, fg=C_WHITE, size=11)

    df_bau = data["bau"]
    cat_dist = df_bau.groupby(["Category", "Mode"]).size().unstack(fill_value=0).reset_index()
    cols_to_show = ["Category"] + [c for c in cat_dist.columns if c != "Category"]

    for ci, h in enumerate(cols_to_show, 1):
        hdr(ws, cat_start + 1, ci, str(h))

    for ri, (_, row) in enumerate(cat_dist.iterrows()):
        r = cat_start + 2 + ri
        bg = C_LIGHT_ORG if ri % 2 == 0 else C_WHITE
        for ci, col in enumerate(cols_to_show, 1):
            v = row.get(col, "")
            val(ws, r, ci, v, bg, h_align="left" if ci == 1 else "center",
                bold=(ci == 1))

    # Weekly trend table
    trend_start = cat_start + 3 + len(cat_dist) + 2
    merge_hdr(ws, trend_start, 1, trend_start, 10,
              "WEEKLY VOLUME & AHT TREND", bg=C_BLACK, fg=C_WHITE, size=11)

    wk_cols = ["Week_Label", "Total_Volume", "Mail_Volume", "Chat_Volume",
               "FCR_Pct", "Avg_AHT_Mail_min", "Avg_AHT_Chat_min",
               "Avg_FRT_Mail_min", "Avg_FRT_Chat_min", "Transfer_Rate_Pct"]
    disp_cols = ["Week", "Total", "Mail", "Chat", "FCR%", "AHT Mail", "AHT Chat",
                 "FRT Mail", "FRT Chat", "Transfer%"]

    for ci, h in enumerate(disp_cols, 1):
        hdr(ws, trend_start + 1, ci, h)

    for ri, (_, row) in enumerate(wk.iterrows()):
        r = trend_start + 2 + ri
        bg = C_LIGHT_ORG if ri % 2 == 0 else C_ORANGE if ri == len(wk) - 1 else C_WHITE
        fg_c = C_WHITE if ri == len(wk) - 1 else C_BLACK
        for ci, col in enumerate(wk_cols, 1):
            v = row.get(col)
            if isinstance(v, float) and np.isnan(v): v = "—"
            elif isinstance(v, float): v = round(v, 1)
            val(ws, r, ci, v, bg, fg_c, bold=(ri == len(wk) - 1))

    for i, w in enumerate([18, 9, 9, 9, 9, 11, 11, 11, 11, 12], 1):
        set_col_width(ws, i, w)

    _legend_row(ws, trend_start + 2 + len(wk) + 2, start_col=1)
    ws.auto_filter.ref = f"A{trend_start + 1}:J{trend_start + 1}"
    ws.freeze_panes = f"A{trend_start + 2}"


def build_transferred_tracker(wb, data):
    ws = wb.create_sheet("Transferred Tracker")
    ws.sheet_view.showGridLines = False

    tr    = data["transferred_summary"]
    df_tr = data["transferred"]

    merge_hdr(ws, 1, 1, 2, 14,
              "TRANSFERRED REQUESTS TRACKER  —  Out-of-Scope Cases",
              bg=C_ORANGE, fg=C_WHITE, size=14)

    # Summary stats
    stats = [
        ("Total Transferred",   tr["total"],           C_ORANGE),
        ("Completed",           tr["total_completed"],  C_GREEN),
        ("Open / In-Progress",  tr["total_open"],       C_AMBER if tr["total_open"] > 0 else C_GREEN),
        ("Completion Rate",     pct_str(tr["completion_pct"]), C_GREEN if tr["completion_pct"] >= 80 else C_AMBER),
        ("Avg Resolution",      hrs_str(tr["avg_res_hrs"]),    C_ORANGE),
    ]

    for ci, (label, value, color) in enumerate(stats, 1):
        hdr(ws, 4, ci * 2 - 1, label)
        val(ws, 4, ci * 2, str(value), C_LIGHT_ORG, color, bold=True)

    # Open cases table
    open_cases = tr["open_cases"]
    merge_hdr(ws, 7, 1, 7, 12,
              f"OPEN / IN-PROGRESS CASES  ({len(open_cases)} cases)",
              bg=C_RED if len(open_cases) > 0 else C_GREEN, fg=C_WHITE, size=11)

    oc_cols = ["Brand Name", "Week_Label", "Category", "Status",
               "Resolution Time_min", "SLA", "Next Step", "Recent Update / Follow up"]
    oc_hdrs = ["Brand", "Week", "Category", "Status", "Res. Time (min)", "SLA", "Next Step", "Last Update"]

    for ci, h in enumerate(oc_hdrs, 1):
        hdr(ws, 8, ci, h)

    for ri, (_, row) in enumerate(open_cases.iterrows()):
        r = 9 + ri
        bg = C_AMBER_LIGHT
        for ci, col in enumerate(oc_cols, 1):
            v = row.get(col, "")
            if isinstance(v, float) and np.isnan(v): v = "—"
            elif pd.isna(v): v = "—"
            elif isinstance(v, pd.Timestamp): v = v.strftime("%d %b %Y")
            val(ws, r, ci, v, bg, h_align="left" if ci in (1, 3, 7, 8) else "center")

    # Brand summary
    brand_start = 9 + len(open_cases) + 3
    merge_hdr(ws, brand_start, 1, brand_start, 8,
              "TRANSFERRED — BRAND SUMMARY", bg=C_DARK_ORANGE, fg=C_WHITE, size=11)

    bs_hdrs = ["Brand", "Total", "Completed", "Open", "Completion%", "SLA Met%", "Avg Res (hrs)"]
    for ci, h in enumerate(bs_hdrs, 1):
        hdr(ws, brand_start + 1, ci, h)

    brand_tr = tr["brand_summary"]
    for ri, (_, row) in enumerate(brand_tr.iterrows()):
        r = brand_start + 2 + ri
        bg = C_LIGHT_ORG if ri % 2 == 0 else C_WHITE
        comp_pct = row.get("Completion_Pct", 0)
        comp_bg  = C_GREEN_LIGHT if comp_pct == 100 else (C_AMBER_LIGHT if comp_pct >= 70 else C_RED_LIGHT)

        val(ws, r, 1, row["Brand Name"],                  bg, bold=True, h_align="left")
        val(ws, r, 2, int(row["Total"]),                  bg)
        val(ws, r, 3, int(row["Completed"]),              C_GREEN_LIGHT, C_GREEN)
        val(ws, r, 4, int(row["Total"] - row["Completed"]),
            C_RED_LIGHT if (row["Total"] - row["Completed"]) > 0 else bg,
            C_RED if (row["Total"] - row["Completed"]) > 0 else C_BLACK)
        val(ws, r, 5, pct_str(comp_pct),                  comp_bg, bold=True)
        val(ws, r, 6, pct_str(row.get("SLA_Pct")),        bg)
        val(ws, r, 7, hrs_str(row.get("Avg_Res_hrs")),    bg)

    widths = [32, 9, 11, 9, 13, 10, 14, 30, 35]
    for i, w in enumerate(widths, 1):
        set_col_width(ws, i, w)

    # What "transferred" means — guidance note
    guide_row = brand_start + 2 + len(brand_tr) + 2
    merge_hdr(ws, guide_row, 1, guide_row, 8,
              "GUIDE: Understanding Transferred Requests", bg=C_GRAY_LIGHT, fg=C_GRAY_DARK, size=10)
    guide_notes = [
        ("Transferred Request",
         "A contact that falls outside OAM scope and is routed to a specialist team "
         "(e.g., Legal, Compliance, Finance, IT). OAM retains ownership and tracks resolution."),
        ("Status: Open",
         "Case has been sent to the specialist team but is not yet closed. "
         "OAM should follow up per SLA cadence."),
        ("Status: Completed",
         "Specialist team has resolved the issue and confirmed closure. "
         "Supplier has been notified."),
        ("SLA",
         "Agreed turnaround time: '24 hrs' = same/next business day, "
         "'48 hrs' = 2 business days, '3-5 Business Days' = up to 5 working days."),
        ("Completion % ≥ 80%",
         "Healthy — strong follow-through on escalated cases."),
        ("Completion % < 80%",
         "Monitor — review open cases with specialist teams; escalate if SLA breached."),
    ]
    for i, (term, note) in enumerate(guide_notes, guide_row + 1):
        bg = C_GREEN_LIGHT if "≥ 80%" in term else (C_AMBER_LIGHT if "< 80%" in term else C_WHITE)
        val(ws, i, 1, term,  bg, bold=True, h_align="left")
        val(ws, i, 2, note,  bg, h_align="left")
        ws.merge_cells(start_row=i, start_column=2, end_row=i, end_column=8)
        ws.row_dimensions[i].height = 24

    _legend_row(ws, guide_row + len(guide_notes) + 2, start_col=1)
    ws.auto_filter.ref = "A8:H8"
    ws.freeze_panes = "A9"


def build_business_value_kpis(wb, data):
    ws = wb.create_sheet("Business Value KPIs")
    ws.sheet_view.showGridLines = False

    bv   = data["business_value_kpis"]
    snap = data["snapshot"]

    merge_hdr(ws, 1, 1, 2, 12,
              "iOPEX BUSINESS VALUE KPIs  —  Strategic Metrics for The Home Depot",
              bg=C_ORANGE, fg=C_WHITE, size=14)

    merge_hdr(ws, 4, 1, 4, 12,
              "These KPIs go beyond standard productivity — they quantify the strategic value iOPEX delivers to THD",
              bg=C_GRAY_LIGHT, fg=C_GRAY_DARK, size=10)

    kpi_rows = [
        ("1", "Escalation Avoidance Rate",
         "% of requests resolved without escalation",
         pct_str(bv["escalation_avoidance_pct"]),
         "≥ 95%",
         bv["escalation_avoidance_pct"], 95, False,
         "Reflects team capability to handle complex issues in-house"),
        ("2", "First-Touch Resolution Rate",
         "% resolved on first contact — no callbacks",
         pct_str(bv["first_touch_resolution_pct"]),
         "≥ 80%",
         bv["first_touch_resolution_pct"], 80, False,
         "Directly improves supplier experience & reduces repeat contacts"),
        ("3", "Issue Recurrence Rate",
         "% of issues that are repeated from same brand/category",
         pct_str(bv["issue_recurrence_rate_pct"]),
         "≤ 20%",
         bv["issue_recurrence_rate_pct"], 20, True,
         "Low recurrence = root-cause fixes are working"),
        ("4", "Chat Responsiveness Index",
         f"Chat FRT vs {BENCHMARKS['chat_frt_min']}-min benchmark (higher = better)",
         pct_str(bv.get("chat_responsiveness_idx")) if bv.get("chat_responsiveness_idx") else "N/A",
         "≥ 100%",
         bv.get("chat_responsiveness_idx"), 100, False,
         "Measures how far above the 1-min chat target the team is performing"),
        ("5", "Transferred Ticket Resolution Rate",
         "% of out-of-scope tickets brought to completion",
         pct_str(bv["transferred_resolution_pct"]),
         "≥ 80%",
         bv["transferred_resolution_pct"], 80, False,
         "Shows end-to-end ownership even for escalated cases"),
        ("6", "After-Hours Coverage",
         "% of supplier requests handled outside business hours",
         pct_str(bv["after_hours_coverage_pct"]),
         "Info only",
         None, None, None,
         "Demonstrates extended support commitment to THD suppliers"),
        ("7", "Brand Engagement Score",
         "Breadth of brand coverage (unique brands / total requests × 100)",
         pct_str(bv["brand_engagement_score"]),
         "Info only",
         None, None, None,
         "Higher = serving a wider supplier base"),
        ("8", "Operational Efficiency Score",
         "Composite: % of requests meeting both AHT and FRT targets",
         pct_str(bv["operational_efficiency_pct"]),
         "≥ 80%",
         bv["operational_efficiency_pct"], 80, False,
         "Single efficiency index for exec reporting"),
        ("9", "Unique Brands Served",
         "Total distinct brands supported this period",
         num_str(bv["unique_brands_served"]),
         "Info only",
         None, None, None,
         "Demonstrates breadth of the iOPEX support network for THD"),
    ]

    col_hdrs = ["#", "KPI Name", "Definition", "Current Value",
                "Target", "Status", "Business Impact"]
    for ci, h in enumerate(col_hdrs, 1):
        hdr(ws, 6, ci, h)

    for ri, row in enumerate(kpi_rows, 7):
        (num, name, defn, cur_val, target, actual, tgt_num, lower, impact) = row
        bg = C_LIGHT_ORG if ri % 2 == 0 else C_WHITE

        if actual is not None and tgt_num is not None:
            st_bg = kpi_color(actual, tgt_num, lower_is_better=lower)
            st_txt = "✓ On Target" if st_bg == C_GREEN_LIGHT else "⚠ Needs Attention"
        else:
            st_bg = C_GRAY_LIGHT
            st_txt = "ℹ Informational"

        val(ws, ri, 1, num,     bg)
        val(ws, ri, 2, name,    bg, bold=True, h_align="left")
        val(ws, ri, 3, defn,    bg, h_align="left")
        val(ws, ri, 4, cur_val, C_LIGHT_ORG, C_ORANGE, bold=True)
        val(ws, ri, 5, target,  bg)
        val(ws, ri, 6, st_txt,  st_bg, bold=True)
        val(ws, ri, 7, impact,  bg, h_align="left")

    widths = [4, 30, 45, 14, 14, 16, 45]
    for i, w in enumerate(widths, 1):
        set_col_width(ws, i, w)
    for r in range(7, 7 + len(kpi_rows)):
        ws.row_dimensions[r].height = 30


def build_weekly_trends(wb, data):
    ws = wb.create_sheet("Weekly Trends")
    ws.sheet_view.showGridLines = False

    wk = data["weekly_kpis"]

    merge_hdr(ws, 1, 1, 2, len(wk) + 2,
              "WEEK-OVER-WEEK TREND DATA",
              bg=C_ORANGE, fg=C_WHITE, size=14)

    trend_cols = [
        ("Total Volume",     "Total_Volume"),
        ("Mail Volume",      "Mail_Volume"),
        ("Chat Volume",      "Chat_Volume"),
        ("FCR %",            "FCR_Pct"),
        ("Transfer Rate %",  "Transfer_Rate_Pct"),
        ("After-Hours %",    "AfterHours_Pct"),
        ("AHT Mail (min)",   "Avg_AHT_Mail_min"),
        ("AHT Chat (min)",   "Avg_AHT_Chat_min"),
        ("FRT Mail (min)",   "Avg_FRT_Mail_min"),
        ("FRT Chat (min)",   "Avg_FRT_Chat_min"),
        ("Res Mail (min)",   "Avg_Res_Mail_min"),
        ("Res Chat (min)",   "Avg_Res_Chat_min"),
    ]

    # Header row: week labels
    hdr(ws, 4, 1, "KPI / Week")
    for ci, (_, row) in enumerate(wk.iterrows(), 2):
        is_latest = ci == len(wk) + 1
        cell = ws.cell(row=4, column=ci, value=row["Week_Label"])
        cell.fill = fill(C_ORANGE if is_latest else C_DARK_ORANGE)
        cell.font = font(C_WHITE, True, 10)
        cell.alignment = align("center", "center")
        cell.border = border()

    for ri, (label, col) in enumerate(trend_cols, 5):
        bg = C_LIGHT_ORG if ri % 2 == 0 else C_WHITE
        hdr(ws, ri, 1, label, bg=C_GRAY_DARK, fg=C_WHITE)
        for ci, (_, row) in enumerate(wk.iterrows(), 2):
            is_latest = ci == len(wk) + 1
            v = row.get(col)
            v_disp = round(float(v), 1) if v is not None and not (isinstance(v, float) and np.isnan(v)) else "—"
            cell = ws.cell(row=ri, column=ci, value=v_disp)
            cell.fill = fill(C_PALE_ORG if is_latest else bg)
            cell.font = font(C_ORANGE if is_latest else C_BLACK, is_latest, 10)
            cell.alignment = align("center", "center")
            cell.border = border()

    # Benchmark reference rows
    bench_row = 5 + len(trend_cols) + 2
    merge_hdr(ws, bench_row, 1, bench_row, len(wk) + 2,
              "BENCHMARK REFERENCE", bg=C_DARK_ORANGE, fg=C_WHITE, size=11)
    bench_row += 1
    benchmarks_display = [
        ("Chat FRT Target",  f"≤ {BENCHMARKS['chat_frt_min']} min"),
        ("Mail FRT Target",  f"≤ {BENCHMARKS['mail_frt_min']} min"),
        ("AHT Target",       f"≤ {BENCHMARKS['aht_min']} min"),
        ("Resolution Target",f"≤ {BENCHMARKS['resolution_min']} min"),
        ("FCR Target",       f"≥ {BENCHMARKS['fcr_pct']}%"),
        ("Escalation Target",f"≤ {BENCHMARKS['escalation_rate_pct']}%"),
    ]
    for i, (label, value) in enumerate(benchmarks_display):
        r = bench_row + i
        hdr(ws, r, 1, label, bg=C_GRAY_LIGHT, fg=C_GRAY_DARK)
        val(ws, r, 2, value, C_LIGHT_ORG, C_ORANGE, bold=True)

    set_col_width(ws, 1, 20)
    for i in range(2, len(wk) + 2):
        set_col_width(ws, i, 12)


def build_raw_data(wb, data):
    ws = wb.create_sheet("Raw Data (Cleaned)")
    ws.sheet_view.showGridLines = False

    df = data["bau"].copy()
    export_cols = [
        "Week_Label", "Fiscal_Year", "_date", "Analyst Name", "Mode",
        "Brand Name", "Category", "Sub Category", "Issue",
        "First contact resolution", "Transferred_flag",
        "AHT_min", "FRT_min", "Res_min", "After-Hours",
        "Work Flow Stage", "Resolution Provided"
    ]
    export_cols = [c for c in export_cols if c in df.columns]
    disp_names  = {
        "_date": "Request Date", "Transferred_flag": "Transferred",
        "AHT_min": "AHT (min)", "FRT_min": "FRT (min)", "Res_min": "Resolution (min)"
    }
    left_cols = {export_cols.index(c) + 1
                 for c in ("Analyst Name", "Mode", "Brand Name",
                           "Category", "Sub Category", "Issue",
                           "Work Flow Stage", "Resolution Provided")
                 if c in export_cols}

    merge_hdr(ws, 1, 1, 1, len(export_cols),
              "BAU CLEANED DATA — All Weeks", bg=C_ORANGE, fg=C_WHITE, size=12)

    for ci, col in enumerate(export_cols, 1):
        hdr(ws, 2, ci, disp_names.get(col, col))

    # Pre-build the two alternating fill objects and shared font/alignment/border
    f_even  = fill(C_LIGHT_ORG)
    f_odd   = fill(C_WHITE)
    fnt     = font(C_BLACK, False, 9)
    al_ctr  = align("center", "center")
    al_left = align("left", "center")
    brd     = border()

    df_sorted = df.sort_values("Week_Sort", na_position="last")
    for ri, (_, row) in enumerate(df_sorted.iterrows(), 3):
        row_fill = f_even if ri % 2 == 0 else f_odd
        for ci, col in enumerate(export_cols, 1):
            v = row.get(col)
            if isinstance(v, bool):             v = "Yes" if v else "No"
            elif pd.isna(v):                    v = ""
            elif isinstance(v, pd.Timestamp):   v = v.strftime("%Y-%m-%d")
            elif isinstance(v, float):          v = round(v, 1)
            c = ws.cell(row=ri, column=ci, value=v)
            c.fill = row_fill
            c.font = fnt
            c.alignment = al_left if ci in left_cols else al_ctr
            c.border = brd

    ws.freeze_panes = "A3"
    ws.auto_filter.ref = f"A2:{get_column_letter(len(export_cols))}2"
    for i in range(1, len(export_cols) + 1):
        set_col_width(ws, i, 14)


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════════
def generate_report(output_path=None):
    print("Loading data from Productivity_Sheet.xlsx …")
    data = load_all()

    snap = data["snapshot"]
    week_label = snap.get("week_label", "latest").replace(" ", "_")

    if output_path is None:
        out_dir = Path(r"c:\Users\2243377\OneDrive - Cognizant\Documents\Personal\Illaya")
        output_path = out_dir / f"THD_OAM_Weekly_Report_{week_label}.xlsx"

    print("Building workbook …")
    wb = Workbook()

    build_cover(wb, data)
    build_weekly_scorecard(wb, data)
    build_brand_analysis(wb, data)
    build_channel_analysis(wb, data)
    build_transferred_tracker(wb, data)
    build_business_value_kpis(wb, data)
    build_weekly_trends(wb, data)
    build_raw_data(wb, data)

    # Tab colors
    tab_colors = {
        "Cover":                C_ORANGE,
        "Weekly Scorecard":     C_DARK_ORANGE,
        "Brand Analysis":       "1E8449",
        "Channel Performance":  "2471A3",
        "Transferred Tracker":  "922B21",
        "Business Value KPIs":  C_ORANGE,
        "Weekly Trends":        "117A65",
        "Raw Data (Cleaned)":   C_GRAY_MID,
    }
    for ws in wb.worksheets:
        if ws.title in tab_colors:
            ws.sheet_properties.tabColor = tab_colors[ws.title]

    wb.save(output_path)
    print(f"\nReport saved: {output_path}")
    print(f"  Sheets: {[ws.title for ws in wb.worksheets]}")
    return str(output_path)


if __name__ == "__main__":
    generate_report()
