THD OAM Analytics
Supplier Analytics Portal
Handover Document
Complete Setup, Operations & KPI Reference Guide
Prepared for: Incoming Operations Administrator

System: THD OAM Supplier Analytics Portal

Document Date: June 01, 2026

Contact: illayapallavan.g@gmail.com

Confidentiality: Internal Use Only

Table of Contents
System Overview
Folder & File Structure
Prerequisites — What You Need Installed
One-Time Setup: Python Virtual Environment
Running the Web Dashboard (Daily Use)
Running the Data Cleaner
Running the Brand KPI Chart
Exporting Reports (Excel / PowerPoint / PDF)
How to Update the Source Data
KPIs & Metrics — Definitions & Formulas
Benchmark Reference Table
Understanding the Dashboard Sections
Troubleshooting Guide
1. System Overview
The THD OAM Supplier Analytics Portal is a Python-based reporting system that reads data from a single Excel workbook (Productivity_Sheet.xlsx), processes it, and presents it through an interactive web dashboard and multiple export formats.

What this system does: It tracks how efficiently the OAM (Online Advertising Management) team handles supplier inquiries — measuring response times, resolution rates, and issue patterns across all supplier brands.
Components at a Glance
Component	What It Does	When to Run
Web Dashboard
thd_portal/app.py	Interactive browser-based analytics portal with charts, KPI cards, and filters	Every time you want to view reports
Data Cleaner
clean_data.py	Standardises and fixes inconsistencies in Productivity_Sheet.xlsx	After manual data entry into the Excel file
Brand KPI Charts
run_brand_kpis.py	Generates a PNG chart image showing brand-level performance	When you need a standalone chart image
Data Processor
thd_portal/data_processor.py	Core logic engine — reads Excel, computes all KPIs. Used by all other components. Do not run directly.	Runs automatically
Data Flow
Productivity_Sheet.xlsx (source data)
   → clean_data.py (standardise & fix)
   → data_processor.py (compute KPIs)
   → Web Dashboard / Excel Export / PPT Export / PDF Export
2. Folder & File Structure
All files live in one parent folder:

C:\Users\2243377\OneDrive - Cognizant\Documents\Personal\Illaya\
│
├── Productivity_Sheet.xlsx        ← SOURCE DATA (do not rename)
├── clean_data.py                  ← Data cleaner script
├── run_brand_kpis.py              ← Brand KPI chart generator
├── generate_handover_doc.py       ← This document generator
│
└── thd_portal\                   ← Web Dashboard folder
    ├── app.py                     ← Flask web server (START HERE)
    ├── data_processor.py          ← KPI calculation engine
    ├── export_ppt.py              ← PowerPoint export
    ├── export_pdf.py              ← PDF export
    ├── requirements.txt           ← Python packages list
    ├── run_portal.bat             ← Double-click shortcut to launch
    └── templates\
        └── dashboard.html         ← Dashboard web page
Important: The file Productivity_Sheet.xlsx is the single source of truth. All charts, KPIs, and exports are generated from this file. Never rename or move it.
Productivity_Sheet.xlsx — Sheet Structure
The workbook has two sheets that this system reads:

Sheet 1: BAU (Business As Usual)
Contains all day-to-day supplier interactions handled by the OAM team.

Column	What It Means	Expected Values
Week	Week number within the fiscal year	e.g., Week 1, Week 2 …
Request Received Date	Date the supplier request came in	Date format (DD/MM/YYYY)
Mode	Communication channel	Mail, Chat
Brand Name	Supplier / advertiser brand	Text (e.g., "NIKE", "SAMSUNG")
Category	Request type	Campaign Setup Guidance, OA Platform Access/Login Issues, Reporting/Data Requests, Other
Sub Category	More specific topic	Free text
Analyst Name	Team member who handled it	Full name
AHT	Average Handling Time	HH:MM:SS format
First Response Time	Time to first reply	HH:MM:SS format
Resolution	Time to fully resolve	HH:MM:SS format
First contact resolution	Was it resolved in one touch?	Yes / No
After-Hours	Handled outside business hours?	Yes / No
Transfered	Was the case transferred?	Yes / No
Work Flow Stage	Current processing stage	Free text
Sheet 2: Transferred
Contains cases that required escalation or transfer to a specialist team.

Column	What It Means	Expected Values
Week	Week number	Same as BAU
Request Received Date	Date received	Date format
Brand Name	Supplier brand	Text
Mode	Communication channel	Mail, Chat
Category / Sub Category	Issue classification	Same as BAU categories
Status	Current case status	Completed, Working, Waiting for Supplier to Reply, Kept Supplier on HOLD
SLA	Response time target	24 hrs, 48 hrs, 24-48 hrs, 3-5 Business Days
AHT	Handling time	HH:MM:SS format
Resolution Time	Time to resolve	HH:MM:SS format
First Response Time	Time to first reply	HH:MM:SS format
Next Step	Planned action	Free text
Recent Update / Follow up	Latest note on the case	Free text
Analyst Name	Assigned analyst	Full name
After-Hours	Handled after hours?	Yes / No
3. Prerequisites — What You Need Installed
A. Python 3.9 or Higher
1
Check if Python is already installed
Open PowerShell (press Windows key, type PowerShell, press Enter) and run:
python --version
If you see Python 3.x.x, Python is installed. If you get an error, download Python from
https://www.python.org/downloads/
— during installation, tick the box "Add Python to PATH".
B. Required Python Packages
The following packages are needed. They are installed in Section 4 (virtual environment setup).

Package	Purpose
flask	Runs the web server for the dashboard
pandas	Reads and processes Excel data
openpyxl	Opens and writes .xlsx Excel files
numpy	Mathematical calculations
matplotlib	Generates the Brand KPI chart image
Good news: You only need to install these packages once. After setup, you use the same virtual environment every time.
4. One-Time Setup: Python Virtual Environment
What is a Virtual Environment? Think of it as a clean, isolated workspace for Python. It keeps all the packages for this project separate from other Python programs on your computer. You only do this ONCE.
Open PowerShell and follow these steps exactly, one at a time:

1
Navigate to the project folder
cd "C:\Users\2243377\OneDrive - Cognizant\Documents\Personal\Illaya"
2
Create the virtual environment
(creates a folder called venv)
python -m venv venv
Wait until the command prompt reappears (takes 10–30 seconds).
3
Activate the virtual environment
.\venv\Scripts\Activate.ps1
You should now see (venv) at the start of your prompt, like this:
(venv) PS C:\Users\2243377\...
If you get a security error about running scripts:
Run this command first, then try again:
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
Type
Y
and press Enter.
4
Install all required packages
pip install flask pandas openpyxl numpy matplotlib
This downloads and installs everything. It may take 2–5 minutes. You will see lots of text — this is normal.
5
Confirm installation worked
pip list
You should see flask, pandas, openpyxl, numpy, matplotlib in the list.
Setup complete! You never need to repeat steps 2–5. The venv folder is now permanently set up. Each time you open a new PowerShell window, you only need to re-run step 1 and step 3 (navigate + activate).
5. Running the Web Dashboard (Daily Use)
The web dashboard is the main way to view all reports and KPIs. It runs locally on your computer — no internet connection needed.

Method A — Using the Batch File (Easiest)
Navigate to the thd_portal folder in File Explorer and double-click run_portal.bat. A black terminal window will open. When you see:

  Data ready.  Open: http://localhost:5000
Open your web browser (Chrome or Edge) and go to: http://localhost:5000

Method B — Using PowerShell
1
Open PowerShell
(Windows key → type PowerShell → Enter)
2
Navigate to the portal folder
cd "C:\Users\2243377\OneDrive - Cognizant\Documents\Personal\Illaya\thd_portal"
3
Activate the virtual environment
..\venv\Scripts\Activate.ps1
4
Start the server
python app.py
5
Open the dashboard in your browser

Go to:
http://localhost:5000
How to Stop the Server
Go back to the PowerShell window and press Ctrl + C. The server will stop. Always stop the server before shutting down your computer.

Refreshing the Data
If you updated Productivity_Sheet.xlsx while the server is running:

Stop the server (Ctrl + C)
Start the server again (python app.py)
In the browser, press Ctrl + Shift + R (hard refresh) to force the browser to load fresh data
Common mistake: The server must stay running in the PowerShell window while you use the dashboard. If you close the PowerShell window, the dashboard stops working.
6. Running the Data Cleaner
Run clean_data.py after you or your team enters new data into Productivity_Sheet.xlsx. It fixes common data entry errors automatically.

What the Cleaner Fixes
Field	Problem Fixed	Example
Mode	Normalises spelling variations	"Email" → "Mail", "chat" → "Chat"
First Contact Resolution	Fixes capitalisation	"yes" → "Yes", "YES" → "Yes"
After-Hours	Normalises Yes/No values	"Select" → "No", "YES" → "Yes"
Transferred	Normalises Yes/No values	"NO" → "No"
Brand Name	Removes extra spaces, fixes special labels	"Multiple Brands" → "(Multi-Brand Case)"
Category	Standardises category names	"others" → "Other"
Transferred — Week	Corrects Week column based on actual date	Fixes mismatches between Week field and date
How to Run
1
Open PowerShell and navigate to the project folder
cd "C:\Users\2243377\OneDrive - Cognizant\Documents\Personal\Illaya"
2
Activate the virtual environment
.\venv\Scripts\Activate.ps1
3
Run the cleaner
python clean_data.py
The script will print a report of every change it made. A timestamped backup of your original file is created automatically before any changes are applied (e.g., Productivity_Sheet_BACKUP_20260601_120000.xlsx).

Safe to run multiple times: Running the cleaner on already-clean data causes no harm — it simply reports "No issues found."
7. Running the Brand KPI Chart
run_brand_kpis.py generates a detailed PNG image showing brand performance across multiple KPIs, and an Excel workbook with the full brand data breakdown.

Output Files
chart_brand_kpi.png — PNG chart image (for presentations or emails)
Brand_KPI_Report.xlsx — Excel workbook with 5 sheets of brand data
How to Run
cd "C:\Users\2243377\OneDrive - Cognizant\Documents\Personal\Illaya"
.\venv\Scripts\Activate.ps1
python run_brand_kpis.py
What the Excel Report Contains
Sheet Name	Contents
Brand KPI Scorecard	One row per brand: total requests, completion rate, AHT, resolution time, SLA compliance, after-hours count
Weekly Volume by Brand	Pivot table — brands as rows, weeks as columns, request count as values
Open Cases Tracker	All currently open transferred cases with status and next steps
Weekly Summary	Week-by-week totals: active brands, requests, completion rate, AHT
All Transferred Data	Full dataset with all computed fields (SLA met, hours, completion flag)
8. Exporting Reports from the Dashboard
While the web dashboard is running, you can export reports directly from the browser.

Available Export Formats
Format	How to Access	Contents
Excel (.xlsx)	Click "Export Excel" button in the dashboard, or go to http://localhost:5000/export/excel	Multi-sheet workbook with all KPIs and data tables
PowerPoint (.pptx)	Click "Export PPT" button, or go to http://localhost:5000/export/ppt	Ready-to-present slide deck with charts and KPI slides
PDF (.pdf)	Click "Export PDF" button, or go to http://localhost:5000/export/pdf	Formatted PDF report
The server must be running for exports to work. Exports are always based on the latest data in Productivity_Sheet.xlsx.
9. How to Update the Source Data
The weekly workflow for keeping the system current:

1
Open Productivity_Sheet.xlsx
in Microsoft Excel
2
Add new rows to the BAU sheet
for the current week's cases. Fill in all columns — especially Week, Request Received Date, Mode, Brand Name, Category, AHT, FRT, First contact resolution, After-Hours, and Transfered.
3
Add new rows to the Transferred sheet
for any cases escalated this week
4
Save and close
the Excel file
5
Run the data cleaner
python clean_data.py
6
Restart the web server
to load the new data
python thd_portal\app.py
Then press Ctrl+Shift+R in the browser.
Data Entry Rules
Week: Always enter as Week 1, Week 2, etc. — not just a number
Mode: Type exactly Mail or Chat (the cleaner will fix Email → Mail)
AHT / FRT / Resolution Time: Enter in HH:MM:SS format (e.g., 00:25:00 for 25 minutes)
First contact resolution: Type exactly Yes or No
Brand Name: Be consistent — check existing entries to avoid creating duplicates with different spellings
Multi-brand cases: Enter (Multi-Brand Case) as the Brand Name
10. KPIs & Metrics — Definitions & Formulas
All KPIs are calculated from the BAU and Transferred sheets in Productivity_Sheet.xlsx. Here is every metric in plain language with its exact formula.

A. Volume Metrics
Total Volume
Total number of supplier interactions handled in a given period (week, month, or YTD).
Total Volume = COUNT(all rows in BAU)
Mail Volume
Number of interactions handled via email/mail channel.
Mail Volume = COUNT(rows where Mode = "Mail")
Chat Volume
Number of interactions handled via live chat.
Chat Volume = COUNT(rows where Mode = "Chat")
After-Hours Coverage %
No benchmark — higher = more extended support
Percentage of interactions handled outside standard business hours. Shows extended support availability.
After-Hours % = (COUNT(After-Hours = "Yes") / Total Volume) × 100
B. Quality KPIs
FCR — First Contact Resolution %
Benchmark: ≥ 80%
Percentage of cases fully resolved without the supplier needing to follow up. High FCR means the team resolves issues completely the first time.
FCR % = (COUNT(First contact resolution = "Yes") / Total Volume) × 100
Transfer Rate %
Benchmark: ≤ 5%
Percentage of cases that had to be escalated (transferred) to another team. Lower is better — it means the frontline team can handle more independently.
Transfer Rate % = (COUNT(Transfered = "Yes") / Total Volume) × 100
C. Time-Based KPIs
All time fields in the Excel are entered as HH:MM:SS. The system converts these to minutes for calculation.

AHT — Average Handling Time
Benchmark: ≤ 30 minutes
Average time spent actively working on a case (per interaction). Calculated separately for Mail and Chat. Lower is better — means the team works efficiently.
Avg AHT (Mail) = AVERAGE(AHT column, Mail rows only) in minutes Avg AHT (Chat) = AVERAGE(AHT column, Chat rows only) in minutes
FRT — First Response Time
Mail: ≤ 60 min | Chat: ≤ 1 min
Average time from when a supplier sends a request to when the team first responds. Chat has a strict 1-minute benchmark because it is a real-time channel.
Avg FRT (Mail) = AVERAGE(First Response Time, Mail rows) in minutes Avg FRT (Chat) = AVERAGE(First Response Time, Chat rows) in minutes
Resolution Time
Benchmark: ≤ 30 minutes (BAU)
Total time from receiving a request to fully resolving it. Different from AHT — includes wait time, not just active work time.
Avg Resolution (Mail) = AVERAGE(Resolution column, Mail rows) in minutes Avg Resolution (Chat) = AVERAGE(Resolution column, Chat rows) in minutes
Transferred SLA Compliance %
Benchmark: ≤ 48 hours
For escalated cases: what percentage were resolved within the agreed SLA target. The SLA target varies per case (24 hrs, 48 hrs, 3-5 business days).
SLA % = (COUNT(Resolution Time ≤ SLA Target) / Total tracked) × 100
D. Brand Issue Analysis KPIs
These KPIs analyse patterns in supplier requests to identify recurring problems.

How New vs. Repeated is determined: The system looks at all cases (BAU + Transferred) combined, sorted by date. For each unique combination of Brand Name + Category, the very first occurrence is labelled New. Every subsequent occurrence of the same Brand + Category combination is labelled Repeated. This tells you which brands keep running into the same issues.
Total Issues
Total count of all cases across both BAU and Transferred sheets.
Total Issues = COUNT(BAU rows) + COUNT(Transferred rows)
New Issues %
Percentage of cases where the brand encountered this category for the first time. High new-issue rate may indicate a growing number of brands or new product launches causing new types of problems.
New % = (COUNT(New issues) / Total Issues) × 100
Repeated Issues %
Percentage of cases that are repeat occurrences. A high repeated-issue rate for a brand signals an unresolved systemic problem that needs root-cause analysis.
Repeated % = (COUNT(Repeated issues) / Total Issues) × 100
Issue Recurrence Rate
Same as Repeated Issues % — used in the Business Value KPI section as a standalone performance indicator. Target: keep this low.
= Repeated Issues %
E. Transferred Cases KPIs
Completion Rate %
Target: as close to 100% as possible
Percentage of transferred cases that have been fully resolved (Status = "Completed").
Completion % = (COUNT(Status = "Completed") / Total Transferred) × 100
Open Cases
Cases that are still in progress (Status = Working, Waiting for Supplier to Reply, or Kept Supplier on HOLD). These require active follow-up.
Open = Total Transferred - COUNT(Status = "Completed")
Avg Resolution Time (Transferred)
Benchmark: ≤ 48 hours
Average time to resolve transferred cases, in hours. Transferred cases take longer than BAU because they require specialist input or supplier cooperation.
Avg Res Hrs = AVERAGE(Resolution Time column) ÷ 60
Transferred Resolution %
Used in the Business Value section. Identical to Completion Rate — the percentage of all transferred tickets that have been closed out.
= Completion Rate %
F. Business Value KPIs
These are composite or derived metrics that go beyond simple counts and averages to show the business impact of the OAM team's work.

Escalation Avoidance Rate %
Target: ≥ 95%
The flip side of Transfer Rate. Shows what percentage of cases the frontline team resolved WITHOUT escalating. High rate = team is highly capable.
Escalation Avoidance = 100% − Transfer Rate %
First-Touch Resolution Rate %
Target: ≥ 80%
Same as FCR. Branded as a "Business Value" KPI to emphasise its strategic importance — each first-touch resolution avoids a follow-up interaction and saves time for both team and supplier.
= FCR %
Chat Responsiveness Index
Target: ≥ 100 (at or better than benchmark)
Measures how fast chat responses are relative to the 1-minute benchmark. A score of 100 means exactly at benchmark; above 100 means faster than target.
Chat Resp. Index = (1 minute ÷ Actual Avg Chat FRT) × 100
Operational Efficiency Score %
A composite score measuring how consistently the team meets time benchmarks. Combines the percentage of cases meeting AHT target, Mail FRT target, and Chat FRT target.
Ops Efficiency = (% AHT within target + % Mail FRT within target + % Chat FRT within target) ÷ 3
Brand Engagement Score %
Measures how many unique brands are being served relative to total interaction volume. High score means the team is handling a diverse portfolio of brands.
Brand Engagement = (Unique Brands Served ÷ Total Interactions) × 100
After-Hours Coverage %
Percentage of interactions handled outside standard hours. Used as a Business Value KPI to demonstrate the team's extended service commitment to suppliers.
= After-Hours % (same as Volume Metric)
G. Analyst-Level KPIs
The dashboard's Analyst Performance section shows individual analyst metrics calculated from the BAU sheet.

Metric	Formula
Total Cases	COUNT(rows assigned to this analyst)
FCR %	COUNT(FCR = "Yes" for this analyst) / analyst total × 100
Avg AHT (min)	AVERAGE(AHT_min for this analyst)
Avg FRT (min)	AVERAGE(FRT_min for this analyst)
Transfer Rate %	COUNT(Transferred = "Yes" for this analyst) / analyst total × 100
11. Benchmark Reference Table
Benchmarks are the performance targets the team is measured against. They are built into the system and used to colour-code KPI cards (green = meeting target, red = below target).

KPI	Channel	Target	Direction	Meaning
First Response Time (FRT)	Chat	≤ 1 minute	Lower is better	Chat is real-time — suppliers expect near-instant replies
First Response Time (FRT)	Mail	≤ 60 minutes	Lower is better	Email allows slightly more time but must be responded within 1 hour
Average Handling Time (AHT)	Both	≤ 30 minutes	Lower is better	Cases taking longer than 30 minutes indicate complexity or inefficiency
Resolution Time	Both	≤ 30 minutes	Lower is better	BAU cases should be resolved quickly; complex ones move to Transferred
First Contact Resolution (FCR)	Both	≥ 80%	Higher is better	At least 8 in 10 cases should be fully resolved without follow-up
Supplier Satisfaction (SSAT)	Both	≥ 4.5 / 5.0	Higher is better	Satisfaction score target (if collected)
Escalation / Transfer Rate	Both	≤ 5%	Lower is better	No more than 5 in 100 cases should need escalation
Transferred Case SLA	Transferred	≤ 48 hours	Lower is better	Escalated cases must be resolved within 48 hours by default
Fiscal Year Structure
Period	Weeks	Calendar Months
FY25	Week 38 – Week 53	September – December 2025
FY26	Week 1 – Week 37	January – September 2026
The system automatically assigns each row to the correct fiscal year based on the Request Received Date.

12. Understanding the Dashboard Sections
Top Row — Snapshot KPI Cards
Shows the current week's headline numbers at a glance: Total Volume, Mail Volume, Chat Volume, FCR %, Transfer Rate %, After-Hours %, and Transferred case counts (Total / Open / Resolved).

Weekly Trends
Line and bar charts showing how each KPI has changed week by week. Use the Fiscal Year selector to switch between FY25 and FY26. The View toggle switches between Total Volume, FCR, AHT, and FRT trend charts.

YTD Summary
Year-to-date aggregate figures for the current fiscal year — total interactions, average KPIs across all weeks.

Category Distribution
Bar chart showing the volume breakdown by request category (Campaign Setup Guidance, OA Platform Access/Login Issues, Reporting/Data Requests, Other), split by Mail vs. Chat.

Brand Issue Analysis
The most strategic section. Shows per-brand breakdown of New vs. Repeated issues. Brands with a high Repeated % are candidates for proactive root-cause resolution or self-service documentation.

(Multi-Brand Case): Cases where a single interaction covered multiple brands — counted separately, not attributed to one brand.
Transferred Cases
Two sub-sections:

Brand Summary: Per-brand table showing total transferred, completion rate, SLA %, and average resolution hours.
Open Cases Tracker: Live list of all currently open transferred cases — updated every time you restart the server. Shows brand, week, category, status, SLA, and analyst assigned.
Business Value KPIs
Eight composite metrics (described in Section 10F) shown as gauge/score cards, giving leadership a single-page view of the team's strategic performance.

Analyst Performance
Table showing individual analyst metrics — useful for identifying coaching opportunities or recognising top performers.

13. Troubleshooting Guide
Problem	Likely Cause	Solution
Dashboard shows "This site can't be reached"	The Flask server is not running	Open PowerShell, navigate to thd_portal, activate venv, and run python app.py. Keep the window open.
Dashboard loads but shows old data	Browser or server has cached old data	Stop the server (Ctrl+C), restart it (python app.py), then press Ctrl+Shift+R in the browser.
Error: "No module named flask" (or pandas, etc.)	Virtual environment is not activated, or packages not installed	Run .\venv\Scripts\Activate.ps1 first. If that fails, run pip install flask pandas openpyxl numpy matplotlib.
Error: "can't open file ... app.py: No such file"	You are in the wrong directory	Make sure you cd into the thd_portal folder before running python app.py. Do not add thd_portal\ prefix when you are already inside it.
Script cannot open Productivity_Sheet.xlsx	File is open in Excel, or file was moved/renamed	Close Excel completely, then re-run the script. Never rename or move the file.
clean_data.py runs but shows no fixes	Data was already clean	This is expected and fine — the script reports "No issues found" when data is already clean.
PowerShell says "running scripts is disabled"	Windows security policy blocks script execution	Run: Set-ExecutionPolicy -Scope CurrentUser RemoteSigned, type Y, press Enter. Then try again.
Charts show "MULTIPLE BRANDS" instead of "(Multi-Brand Case)"	Source data in Excel still has old values	Run python clean_data.py to fix source data, then restart the server.
Server starts but immediately crashes with an error	Usually a missing column in the Excel sheet, or a column name has a typo	Read the error message carefully — it usually names the column. Check Productivity_Sheet.xlsx to ensure all column headers exactly match the names in Section 2.
Export buttons do nothing	Browser blocked the download, or server error	Check browser's download bar. If server shows an error in PowerShell, note the error text and check column names in the Excel file.
Quick Reference: All Commands
# Navigate to project root
cd "C:\Users\2243377\OneDrive - Cognizant\Documents\Personal\Illaya"

# Activate virtual environment (do this every new PowerShell session)
.\venv\Scripts\Activate.ps1

# Run the data cleaner (after updating Productivity_Sheet.xlsx)
python clean_data.py

# Start the web dashboard
cd thd_portal
python app.py
# → Open browser: http://localhost:5000
# → Stop server: Ctrl+C

# Generate Brand KPI chart + Excel report
cd "C:\Users\2243377\OneDrive - Cognizant\Documents\Personal\Illaya"
python run_brand_kpis.py
When to Run Each Script
Frequency	Action
Every session (when you open PowerShell)	Activate venv: .\venv\Scripts\Activate.ps1
After any data entry in Productivity_Sheet.xlsx	Run python clean_data.py
Whenever you want to view the dashboard	Run python app.py in thd_portal
Weekly (for reporting)	Run python run_brand_kpis.py + export from dashboard
One time only	Virtual environment setup (Section 4)
THD OAM Supplier Analytics Portal — Internal Handover Document  |  Generated: June 01, 2026 at 13:10  |  For support: illayapallavan.g@gmail.com
