"""
Generate THD OAM Analytics Handover Document as a styled HTML file.
Open the output file in Chrome/Edge and press Ctrl+P → Save as PDF.

Run:  python generate_handover_doc.py
"""
from pathlib import Path
from datetime import datetime

OUT = Path(r"c:\Users\2243377\OneDrive - Cognizant\Documents\Personal\Illaya\THD_OAM_Handover_Document.html")

HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>THD OAM Analytics Portal — Handover Document</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    font-family: 'Inter', Arial, sans-serif;
    font-size: 10.5pt;
    line-height: 1.65;
    color: #1a1a2e;
    background: #fff;
    max-width: 900px;
    margin: 0 auto;
    padding: 40px 50px;
  }
  /* ---------- COVER ---------- */
  .cover {
    text-align: center;
    padding: 80px 40px 60px;
    border-bottom: 4px solid #f96302;
    margin-bottom: 60px;
    page-break-after: always;
  }
  .cover .logo-line {
    font-size: 13pt;
    font-weight: 700;
    color: #f96302;
    letter-spacing: 3px;
    text-transform: uppercase;
    margin-bottom: 8px;
  }
  .cover h1 {
    font-size: 26pt;
    font-weight: 700;
    color: #1a1a2e;
    margin: 16px 0 8px;
    line-height: 1.2;
  }
  .cover .subtitle {
    font-size: 13pt;
    color: #555;
    margin-bottom: 40px;
  }
  .cover .meta-table {
    display: inline-block;
    text-align: left;
    background: #f8f9fc;
    border: 1px solid #e2e6f0;
    border-radius: 8px;
    padding: 20px 32px;
    margin-top: 20px;
  }
  .cover .meta-table p { margin: 4px 0; font-size: 10pt; }
  .cover .meta-table strong { color: #f96302; }
  /* ---------- TOC ---------- */
  .toc {
    background: #f8f9fc;
    border-left: 4px solid #f96302;
    border-radius: 0 8px 8px 0;
    padding: 24px 32px;
    margin-bottom: 50px;
    page-break-after: always;
  }
  .toc h2 { font-size: 14pt; margin-bottom: 14px; color: #f96302; }
  .toc ol { padding-left: 20px; }
  .toc li { margin: 5px 0; font-size: 10pt; }
  .toc li a { color: #1a1a2e; text-decoration: none; }
  /* ---------- SECTION HEADINGS ---------- */
  h1 { font-size: 20pt; color: #f96302; margin: 0 0 6px; }
  h2 {
    font-size: 15pt; font-weight: 700; color: #1a1a2e;
    margin: 40px 0 12px;
    padding-bottom: 6px;
    border-bottom: 2px solid #f96302;
  }
  h3 {
    font-size: 11.5pt; font-weight: 600; color: #2c3e70;
    margin: 24px 0 8px;
  }
  h4 { font-size: 10.5pt; font-weight: 600; color: #555; margin: 16px 0 6px; }
  /* ---------- SECTION DIVIDER ---------- */
  .section { margin-bottom: 36px; }
  .page-break { page-break-before: always; }
  /* ---------- CALLOUT BOXES ---------- */
  .box {
    border-radius: 6px;
    padding: 14px 18px;
    margin: 16px 0;
    font-size: 10pt;
  }
  .box-orange { background: #fff4ec; border-left: 4px solid #f96302; }
  .box-blue   { background: #eef4ff; border-left: 4px solid #3b6cce; }
  .box-green  { background: #edfaf1; border-left: 4px solid #27ae60; }
  .box-red    { background: #fdf0f0; border-left: 4px solid #e74c3c; }
  .box-gray   { background: #f5f6f8; border-left: 4px solid #7f8c8d; }
  .box strong { color: inherit; }
  /* ---------- CODE BLOCKS ---------- */
  pre, code {
    font-family: 'Courier New', Courier, monospace;
    font-size: 9pt;
  }
  pre {
    background: #1e1e2e;
    color: #cdd6f4;
    border-radius: 6px;
    padding: 14px 18px;
    overflow-x: auto;
    margin: 10px 0 16px;
    white-space: pre-wrap;
    word-break: break-word;
    line-height: 1.5;
  }
  code {
    background: #f0f0f5;
    color: #c0392b;
    padding: 1px 5px;
    border-radius: 3px;
  }
  /* ---------- TABLES ---------- */
  table {
    width: 100%;
    border-collapse: collapse;
    margin: 14px 0 22px;
    font-size: 9.5pt;
  }
  thead tr { background: #f96302; color: #fff; }
  thead th { padding: 9px 12px; text-align: left; font-weight: 600; }
  tbody tr:nth-child(even) { background: #f8f9fc; }
  tbody td { padding: 8px 12px; border-bottom: 1px solid #e2e6f0; vertical-align: top; }
  /* ---------- LISTS ---------- */
  ul, ol { padding-left: 22px; margin: 8px 0 14px; }
  li { margin: 4px 0; }
  /* ---------- STEP BOXES ---------- */
  .step {
    display: flex;
    gap: 14px;
    align-items: flex-start;
    margin: 12px 0;
    padding: 12px 16px;
    background: #f8f9fc;
    border-radius: 6px;
    border: 1px solid #e2e6f0;
  }
  .step-num {
    background: #f96302;
    color: #fff;
    font-weight: 700;
    font-size: 10pt;
    min-width: 28px;
    height: 28px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
  }
  .step-body { flex: 1; }
  .step-body strong { display: block; margin-bottom: 4px; }
  /* ---------- KPI CARDS ---------- */
  .kpi-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 14px;
    margin: 14px 0;
  }
  .kpi-card {
    background: #f8f9fc;
    border: 1px solid #e2e6f0;
    border-top: 3px solid #f96302;
    border-radius: 6px;
    padding: 14px 16px;
  }
  .kpi-card .kpi-name { font-weight: 700; font-size: 10.5pt; color: #1a1a2e; margin-bottom: 4px; }
  .kpi-card .kpi-bench { font-size: 9pt; color: #f96302; font-weight: 600; }
  .kpi-card .kpi-desc { font-size: 9.5pt; color: #444; margin: 6px 0; }
  .kpi-card .kpi-formula {
    font-family: 'Courier New', monospace;
    font-size: 8.5pt;
    background: #1e1e2e;
    color: #a6e3a1;
    padding: 6px 10px;
    border-radius: 4px;
    margin-top: 8px;
  }
  /* ---------- FOOTER ---------- */
  .footer {
    margin-top: 60px;
    padding-top: 16px;
    border-top: 2px solid #f96302;
    font-size: 8.5pt;
    color: #888;
    text-align: center;
  }
  /* ---------- PRINT ---------- */
  @media print {
    body { padding: 20px 30px; font-size: 9.5pt; }
    .page-break { page-break-before: always; }
    pre { font-size: 8pt; }
    .kpi-grid { grid-template-columns: repeat(2, 1fr); }
    a { color: inherit; text-decoration: none; }
  }
</style>
</head>
<body>

<!-- ═══════════════════ COVER ═══════════════════ -->
<div class="cover">
  <div class="logo-line">THD OAM Analytics</div>
  <h1>Supplier Analytics Portal<br>Handover Document</h1>
  <div class="subtitle">Complete Setup, Operations &amp; KPI Reference Guide</div>
  <div class="meta-table">
    <p><strong>Prepared for:</strong> Incoming Operations Administrator</p>
    <p><strong>System:</strong> THD OAM Supplier Analytics Portal</p>
    <p><strong>Document Date:</strong> """ + datetime.now().strftime("%B %d, %Y") + """</p>
    <p><strong>Contact:</strong> illayapallavan.g@gmail.com</p>
    <p><strong>Confidentiality:</strong> Internal Use Only</p>
  </div>
</div>

<!-- ═══════════════════ TABLE OF CONTENTS ═══════════════════ -->
<div class="toc">
  <h2>Table of Contents</h2>
  <ol>
    <li><a href="#s1">System Overview</a></li>
    <li><a href="#s2">Folder &amp; File Structure</a></li>
    <li><a href="#s3">Prerequisites — What You Need Installed</a></li>
    <li><a href="#s4">One-Time Setup: Python Virtual Environment</a></li>
    <li><a href="#s5">Running the Web Dashboard (Daily Use)</a></li>
    <li><a href="#s6">Running the Data Cleaner</a></li>
    <li><a href="#s7">Running the Brand KPI Chart</a></li>
    <li><a href="#s8">Exporting Reports (Excel / PowerPoint / PDF)</a></li>
    <li><a href="#s9">How to Update the Source Data</a></li>
    <li><a href="#s10">KPIs &amp; Metrics — Definitions &amp; Formulas</a></li>
    <li><a href="#s11">Benchmark Reference Table</a></li>
    <li><a href="#s12">Understanding the Dashboard Sections</a></li>
    <li><a href="#s13">Troubleshooting Guide</a></li>
  </ol>
</div>

<!-- ═══════════════════ SECTION 1 ═══════════════════ -->
<div class="section" id="s1">
<h2>1. System Overview</h2>
<p>The <strong>THD OAM Supplier Analytics Portal</strong> is a Python-based reporting system that reads data from a single Excel workbook (<code>Productivity_Sheet.xlsx</code>), processes it, and presents it through an interactive web dashboard and multiple export formats.</p>

<div class="box box-orange">
<strong>What this system does:</strong> It tracks how efficiently the OAM (Online Advertising Management) team handles supplier inquiries — measuring response times, resolution rates, and issue patterns across all supplier brands.
</div>

<h3>Components at a Glance</h3>
<table>
  <thead><tr><th>Component</th><th>What It Does</th><th>When to Run</th></tr></thead>
  <tbody>
    <tr><td><strong>Web Dashboard</strong><br><code>thd_portal/app.py</code></td><td>Interactive browser-based analytics portal with charts, KPI cards, and filters</td><td>Every time you want to view reports</td></tr>
    <tr><td><strong>Data Cleaner</strong><br><code>clean_data.py</code></td><td>Standardises and fixes inconsistencies in <code>Productivity_Sheet.xlsx</code></td><td>After manual data entry into the Excel file</td></tr>
    <tr><td><strong>Brand KPI Charts</strong><br><code>run_brand_kpis.py</code></td><td>Generates a PNG chart image showing brand-level performance</td><td>When you need a standalone chart image</td></tr>
    <tr><td><strong>Data Processor</strong><br><code>thd_portal/data_processor.py</code></td><td>Core logic engine — reads Excel, computes all KPIs. Used by all other components. <em>Do not run directly.</em></td><td>Runs automatically</td></tr>
  </tbody>
</table>

<h3>Data Flow</h3>
<div class="box box-gray">
<strong>Productivity_Sheet.xlsx</strong> (source data)<br>
&nbsp;&nbsp;&nbsp;→ <strong>clean_data.py</strong> (standardise &amp; fix)<br>
&nbsp;&nbsp;&nbsp;→ <strong>data_processor.py</strong> (compute KPIs)<br>
&nbsp;&nbsp;&nbsp;→ <strong>Web Dashboard / Excel Export / PPT Export / PDF Export</strong>
</div>
</div>

<!-- ═══════════════════ SECTION 2 ═══════════════════ -->
<div class="section page-break" id="s2">
<h2>2. Folder &amp; File Structure</h2>
<p>All files live in one parent folder:</p>
<pre>C:\\Users\\2243377\\OneDrive - Cognizant\\Documents\\Personal\\Illaya\\
│
├── Productivity_Sheet.xlsx        ← SOURCE DATA (do not rename)
├── clean_data.py                  ← Data cleaner script
├── run_brand_kpis.py              ← Brand KPI chart generator
├── generate_handover_doc.py       ← This document generator
│
└── thd_portal\\                   ← Web Dashboard folder
    ├── app.py                     ← Flask web server (START HERE)
    ├── data_processor.py          ← KPI calculation engine
    ├── export_ppt.py              ← PowerPoint export
    ├── export_pdf.py              ← PDF export
    ├── requirements.txt           ← Python packages list
    ├── run_portal.bat             ← Double-click shortcut to launch
    └── templates\\
        └── dashboard.html         ← Dashboard web page</pre>

<div class="box box-blue">
<strong>Important:</strong> The file <code>Productivity_Sheet.xlsx</code> is the single source of truth. All charts, KPIs, and exports are generated from this file. Never rename or move it.
</div>

<h3>Productivity_Sheet.xlsx — Sheet Structure</h3>
<p>The workbook has two sheets that this system reads:</p>

<h4>Sheet 1: BAU (Business As Usual)</h4>
<p>Contains all day-to-day supplier interactions handled by the OAM team.</p>
<table>
  <thead><tr><th>Column</th><th>What It Means</th><th>Expected Values</th></tr></thead>
  <tbody>
    <tr><td>Week</td><td>Week number within the fiscal year</td><td>e.g., Week 1, Week 2 …</td></tr>
    <tr><td>Request Received Date</td><td>Date the supplier request came in</td><td>Date format (DD/MM/YYYY)</td></tr>
    <tr><td>Mode</td><td>Communication channel</td><td>Mail, Chat</td></tr>
    <tr><td>Brand Name</td><td>Supplier / advertiser brand</td><td>Text (e.g., "NIKE", "SAMSUNG")</td></tr>
    <tr><td>Category</td><td>Request type</td><td>Campaign Setup Guidance, OA Platform Access/Login Issues, Reporting/Data Requests, Other</td></tr>
    <tr><td>Sub Category</td><td>More specific topic</td><td>Free text</td></tr>
    <tr><td>Analyst Name</td><td>Team member who handled it</td><td>Full name</td></tr>
    <tr><td>AHT</td><td>Average Handling Time</td><td>HH:MM:SS format</td></tr>
    <tr><td>First Response Time</td><td>Time to first reply</td><td>HH:MM:SS format</td></tr>
    <tr><td>Resolution</td><td>Time to fully resolve</td><td>HH:MM:SS format</td></tr>
    <tr><td>First contact resolution</td><td>Was it resolved in one touch?</td><td>Yes / No</td></tr>
    <tr><td>After-Hours</td><td>Handled outside business hours?</td><td>Yes / No</td></tr>
    <tr><td>Transfered</td><td>Was the case transferred?</td><td>Yes / No</td></tr>
    <tr><td>Work Flow Stage</td><td>Current processing stage</td><td>Free text</td></tr>
  </tbody>
</table>

<h4>Sheet 2: Transferred</h4>
<p>Contains cases that required escalation or transfer to a specialist team.</p>
<table>
  <thead><tr><th>Column</th><th>What It Means</th><th>Expected Values</th></tr></thead>
  <tbody>
    <tr><td>Week</td><td>Week number</td><td>Same as BAU</td></tr>
    <tr><td>Request Received Date</td><td>Date received</td><td>Date format</td></tr>
    <tr><td>Brand Name</td><td>Supplier brand</td><td>Text</td></tr>
    <tr><td>Mode</td><td>Communication channel</td><td>Mail, Chat</td></tr>
    <tr><td>Category / Sub Category</td><td>Issue classification</td><td>Same as BAU categories</td></tr>
    <tr><td>Status</td><td>Current case status</td><td>Completed, Working, Waiting for Supplier to Reply, Kept Supplier on HOLD</td></tr>
    <tr><td>SLA</td><td>Response time target</td><td>24 hrs, 48 hrs, 24-48 hrs, 3-5 Business Days</td></tr>
    <tr><td>AHT</td><td>Handling time</td><td>HH:MM:SS format</td></tr>
    <tr><td>Resolution Time</td><td>Time to resolve</td><td>HH:MM:SS format</td></tr>
    <tr><td>First Response Time</td><td>Time to first reply</td><td>HH:MM:SS format</td></tr>
    <tr><td>Next Step</td><td>Planned action</td><td>Free text</td></tr>
    <tr><td>Recent Update / Follow up</td><td>Latest note on the case</td><td>Free text</td></tr>
    <tr><td>Analyst Name</td><td>Assigned analyst</td><td>Full name</td></tr>
    <tr><td>After-Hours</td><td>Handled after hours?</td><td>Yes / No</td></tr>
  </tbody>
</table>
</div>

<!-- ═══════════════════ SECTION 3 ═══════════════════ -->
<div class="section page-break" id="s3">
<h2>3. Prerequisites — What You Need Installed</h2>

<h3>A. Python 3.9 or Higher</h3>
<div class="step">
  <div class="step-num">1</div>
  <div class="step-body">
    <strong>Check if Python is already installed</strong>
    Open PowerShell (press Windows key, type <em>PowerShell</em>, press Enter) and run:
    <pre>python --version</pre>
    If you see <code>Python 3.x.x</code>, Python is installed. If you get an error, download Python from <strong>https://www.python.org/downloads/</strong> — during installation, tick the box <em>"Add Python to PATH"</em>.
  </div>
</div>

<h3>B. Required Python Packages</h3>
<p>The following packages are needed. They are installed in Section 4 (virtual environment setup).</p>
<table>
  <thead><tr><th>Package</th><th>Purpose</th></tr></thead>
  <tbody>
    <tr><td><code>flask</code></td><td>Runs the web server for the dashboard</td></tr>
    <tr><td><code>pandas</code></td><td>Reads and processes Excel data</td></tr>
    <tr><td><code>openpyxl</code></td><td>Opens and writes .xlsx Excel files</td></tr>
    <tr><td><code>numpy</code></td><td>Mathematical calculations</td></tr>
    <tr><td><code>matplotlib</code></td><td>Generates the Brand KPI chart image</td></tr>
  </tbody>
</table>

<div class="box box-green">
<strong>Good news:</strong> You only need to install these packages once. After setup, you use the same virtual environment every time.
</div>
</div>

<!-- ═══════════════════ SECTION 4 ═══════════════════ -->
<div class="section" id="s4">
<h2>4. One-Time Setup: Python Virtual Environment</h2>

<div class="box box-blue">
<strong>What is a Virtual Environment?</strong> Think of it as a clean, isolated workspace for Python. It keeps all the packages for this project separate from other Python programs on your computer. You only do this ONCE.
</div>

<p>Open <strong>PowerShell</strong> and follow these steps exactly, one at a time:</p>

<div class="step">
  <div class="step-num">1</div>
  <div class="step-body">
    <strong>Navigate to the project folder</strong>
    <pre>cd "C:\\Users\\2243377\\OneDrive - Cognizant\\Documents\\Personal\\Illaya"</pre>
  </div>
</div>

<div class="step">
  <div class="step-num">2</div>
  <div class="step-body">
    <strong>Create the virtual environment</strong> (creates a folder called <code>venv</code>)
    <pre>python -m venv venv</pre>
    Wait until the command prompt reappears (takes 10–30 seconds).
  </div>
</div>

<div class="step">
  <div class="step-num">3</div>
  <div class="step-body">
    <strong>Activate the virtual environment</strong>
    <pre>.\\venv\\Scripts\\Activate.ps1</pre>
    You should now see <code>(venv)</code> at the start of your prompt, like this:
    <pre>(venv) PS C:\\Users\\2243377\\...</pre>
    <div class="box box-red" style="margin-top:8px">
    <strong>If you get a security error about running scripts:</strong> Run this command first, then try again:<br>
    <code>Set-ExecutionPolicy -Scope CurrentUser RemoteSigned</code><br>
    Type <strong>Y</strong> and press Enter.
    </div>
  </div>
</div>

<div class="step">
  <div class="step-num">4</div>
  <div class="step-body">
    <strong>Install all required packages</strong>
    <pre>pip install flask pandas openpyxl numpy matplotlib</pre>
    This downloads and installs everything. It may take 2–5 minutes. You will see lots of text — this is normal.
  </div>
</div>

<div class="step">
  <div class="step-num">5</div>
  <div class="step-body">
    <strong>Confirm installation worked</strong>
    <pre>pip list</pre>
    You should see flask, pandas, openpyxl, numpy, matplotlib in the list.
  </div>
</div>

<div class="box box-green">
<strong>Setup complete!</strong> You never need to repeat steps 2–5. The <code>venv</code> folder is now permanently set up. Each time you open a new PowerShell window, you only need to re-run step 1 and step 3 (navigate + activate).
</div>
</div>

<!-- ═══════════════════ SECTION 5 ═══════════════════ -->
<div class="section page-break" id="s5">
<h2>5. Running the Web Dashboard (Daily Use)</h2>

<p>The web dashboard is the main way to view all reports and KPIs. It runs locally on your computer — no internet connection needed.</p>

<h3>Method A — Using the Batch File (Easiest)</h3>
<p>Navigate to the <code>thd_portal</code> folder in File Explorer and <strong>double-click</strong> <code>run_portal.bat</code>. A black terminal window will open. When you see:</p>
<pre>  Data ready.  Open: http://localhost:5000</pre>
<p>Open your web browser (Chrome or Edge) and go to: <strong>http://localhost:5000</strong></p>

<h3>Method B — Using PowerShell</h3>

<div class="step">
  <div class="step-num">1</div>
  <div class="step-body">
    <strong>Open PowerShell</strong> (Windows key → type PowerShell → Enter)
  </div>
</div>

<div class="step">
  <div class="step-num">2</div>
  <div class="step-body">
    <strong>Navigate to the portal folder</strong>
    <pre>cd "C:\\Users\\2243377\\OneDrive - Cognizant\\Documents\\Personal\\Illaya\\thd_portal"</pre>
  </div>
</div>

<div class="step">
  <div class="step-num">3</div>
  <div class="step-body">
    <strong>Activate the virtual environment</strong>
    <pre>..\\venv\\Scripts\\Activate.ps1</pre>
  </div>
</div>

<div class="step">
  <div class="step-num">4</div>
  <div class="step-body">
    <strong>Start the server</strong>
    <pre>python app.py</pre>
  </div>
</div>

<div class="step">
  <div class="step-num">5</div>
  <div class="step-body">
    <strong>Open the dashboard in your browser</strong><br>
    Go to: <strong>http://localhost:5000</strong>
  </div>
</div>

<h3>How to Stop the Server</h3>
<p>Go back to the PowerShell window and press <strong>Ctrl + C</strong>. The server will stop. Always stop the server before shutting down your computer.</p>

<h3>Refreshing the Data</h3>
<p>If you updated <code>Productivity_Sheet.xlsx</code> while the server is running:</p>
<ol>
  <li>Stop the server (Ctrl + C)</li>
  <li>Start the server again (<code>python app.py</code>)</li>
  <li>In the browser, press <strong>Ctrl + Shift + R</strong> (hard refresh) to force the browser to load fresh data</li>
</ol>

<div class="box box-orange">
<strong>Common mistake:</strong> The server must stay running in the PowerShell window while you use the dashboard. If you close the PowerShell window, the dashboard stops working.
</div>
</div>

<!-- ═══════════════════ SECTION 6 ═══════════════════ -->
<div class="section" id="s6">
<h2>6. Running the Data Cleaner</h2>

<p>Run <code>clean_data.py</code> after you or your team enters new data into <code>Productivity_Sheet.xlsx</code>. It fixes common data entry errors automatically.</p>

<h3>What the Cleaner Fixes</h3>
<table>
  <thead><tr><th>Field</th><th>Problem Fixed</th><th>Example</th></tr></thead>
  <tbody>
    <tr><td>Mode</td><td>Normalises spelling variations</td><td>"Email" → "Mail", "chat" → "Chat"</td></tr>
    <tr><td>First Contact Resolution</td><td>Fixes capitalisation</td><td>"yes" → "Yes", "YES" → "Yes"</td></tr>
    <tr><td>After-Hours</td><td>Normalises Yes/No values</td><td>"Select" → "No", "YES" → "Yes"</td></tr>
    <tr><td>Transferred</td><td>Normalises Yes/No values</td><td>"NO" → "No"</td></tr>
    <tr><td>Brand Name</td><td>Removes extra spaces, fixes special labels</td><td>"Multiple Brands" → "(Multi-Brand Case)"</td></tr>
    <tr><td>Category</td><td>Standardises category names</td><td>"others" → "Other"</td></tr>
    <tr><td>Transferred — Week</td><td>Corrects Week column based on actual date</td><td>Fixes mismatches between Week field and date</td></tr>
  </tbody>
</table>

<h3>How to Run</h3>
<div class="step">
  <div class="step-num">1</div>
  <div class="step-body">
    <strong>Open PowerShell and navigate to the project folder</strong>
    <pre>cd "C:\\Users\\2243377\\OneDrive - Cognizant\\Documents\\Personal\\Illaya"</pre>
  </div>
</div>
<div class="step">
  <div class="step-num">2</div>
  <div class="step-body">
    <strong>Activate the virtual environment</strong>
    <pre>.\\venv\\Scripts\\Activate.ps1</pre>
  </div>
</div>
<div class="step">
  <div class="step-num">3</div>
  <div class="step-body">
    <strong>Run the cleaner</strong>
    <pre>python clean_data.py</pre>
  </div>
</div>

<p>The script will print a report of every change it made. A timestamped backup of your original file is created automatically before any changes are applied (e.g., <code>Productivity_Sheet_BACKUP_20260601_120000.xlsx</code>).</p>

<div class="box box-green">
<strong>Safe to run multiple times:</strong> Running the cleaner on already-clean data causes no harm — it simply reports "No issues found."
</div>
</div>

<!-- ═══════════════════ SECTION 7 ═══════════════════ -->
<div class="section page-break" id="s7">
<h2>7. Running the Brand KPI Chart</h2>

<p><code>run_brand_kpis.py</code> generates a detailed PNG image showing brand performance across multiple KPIs, and an Excel workbook with the full brand data breakdown.</p>

<h3>Output Files</h3>
<ul>
  <li><code>chart_brand_kpi.png</code> — PNG chart image (for presentations or emails)</li>
  <li><code>Brand_KPI_Report.xlsx</code> — Excel workbook with 5 sheets of brand data</li>
</ul>

<h3>How to Run</h3>
<pre>cd "C:\\Users\\2243377\\OneDrive - Cognizant\\Documents\\Personal\\Illaya"
.\\venv\\Scripts\\Activate.ps1
python run_brand_kpis.py</pre>

<h3>What the Excel Report Contains</h3>
<table>
  <thead><tr><th>Sheet Name</th><th>Contents</th></tr></thead>
  <tbody>
    <tr><td>Brand KPI Scorecard</td><td>One row per brand: total requests, completion rate, AHT, resolution time, SLA compliance, after-hours count</td></tr>
    <tr><td>Weekly Volume by Brand</td><td>Pivot table — brands as rows, weeks as columns, request count as values</td></tr>
    <tr><td>Open Cases Tracker</td><td>All currently open transferred cases with status and next steps</td></tr>
    <tr><td>Weekly Summary</td><td>Week-by-week totals: active brands, requests, completion rate, AHT</td></tr>
    <tr><td>All Transferred Data</td><td>Full dataset with all computed fields (SLA met, hours, completion flag)</td></tr>
  </tbody>
</table>
</div>

<!-- ═══════════════════ SECTION 8 ═══════════════════ -->
<div class="section" id="s8">
<h2>8. Exporting Reports from the Dashboard</h2>

<p>While the web dashboard is running, you can export reports directly from the browser.</p>

<h3>Available Export Formats</h3>
<table>
  <thead><tr><th>Format</th><th>How to Access</th><th>Contents</th></tr></thead>
  <tbody>
    <tr><td><strong>Excel (.xlsx)</strong></td><td>Click "Export Excel" button in the dashboard, or go to <code>http://localhost:5000/export/excel</code></td><td>Multi-sheet workbook with all KPIs and data tables</td></tr>
    <tr><td><strong>PowerPoint (.pptx)</strong></td><td>Click "Export PPT" button, or go to <code>http://localhost:5000/export/ppt</code></td><td>Ready-to-present slide deck with charts and KPI slides</td></tr>
    <tr><td><strong>PDF (.pdf)</strong></td><td>Click "Export PDF" button, or go to <code>http://localhost:5000/export/pdf</code></td><td>Formatted PDF report</td></tr>
  </tbody>
</table>

<div class="box box-orange">
<strong>The server must be running</strong> for exports to work. Exports are always based on the latest data in <code>Productivity_Sheet.xlsx</code>.
</div>
</div>

<!-- ═══════════════════ SECTION 9 ═══════════════════ -->
<div class="section page-break" id="s9">
<h2>9. How to Update the Source Data</h2>

<p>The weekly workflow for keeping the system current:</p>

<div class="step">
  <div class="step-num">1</div>
  <div class="step-body">
    <strong>Open Productivity_Sheet.xlsx</strong> in Microsoft Excel
  </div>
</div>
<div class="step">
  <div class="step-num">2</div>
  <div class="step-body">
    <strong>Add new rows to the BAU sheet</strong> for the current week's cases. Fill in all columns — especially Week, Request Received Date, Mode, Brand Name, Category, AHT, FRT, First contact resolution, After-Hours, and Transfered.
  </div>
</div>
<div class="step">
  <div class="step-num">3</div>
  <div class="step-body">
    <strong>Add new rows to the Transferred sheet</strong> for any cases escalated this week
  </div>
</div>
<div class="step">
  <div class="step-num">4</div>
  <div class="step-body">
    <strong>Save and close</strong> the Excel file
  </div>
</div>
<div class="step">
  <div class="step-num">5</div>
  <div class="step-body">
    <strong>Run the data cleaner</strong>
    <pre>python clean_data.py</pre>
  </div>
</div>
<div class="step">
  <div class="step-num">6</div>
  <div class="step-body">
    <strong>Restart the web server</strong> to load the new data
    <pre>python thd_portal\\app.py</pre>
    Then press Ctrl+Shift+R in the browser.
  </div>
</div>

<h3>Data Entry Rules</h3>
<div class="box box-blue">
<ul>
  <li><strong>Week:</strong> Always enter as <em>Week 1</em>, <em>Week 2</em>, etc. — not just a number</li>
  <li><strong>Mode:</strong> Type exactly <em>Mail</em> or <em>Chat</em> (the cleaner will fix Email → Mail)</li>
  <li><strong>AHT / FRT / Resolution Time:</strong> Enter in <em>HH:MM:SS</em> format (e.g., 00:25:00 for 25 minutes)</li>
  <li><strong>First contact resolution:</strong> Type exactly <em>Yes</em> or <em>No</em></li>
  <li><strong>Brand Name:</strong> Be consistent — check existing entries to avoid creating duplicates with different spellings</li>
  <li><strong>Multi-brand cases:</strong> Enter <em>(Multi-Brand Case)</em> as the Brand Name</li>
</ul>
</div>
</div>

<!-- ═══════════════════ SECTION 10 ═══════════════════ -->
<div class="section page-break" id="s10">
<h2>10. KPIs &amp; Metrics — Definitions &amp; Formulas</h2>

<p>All KPIs are calculated from the BAU and Transferred sheets in <code>Productivity_Sheet.xlsx</code>. Here is every metric in plain language with its exact formula.</p>

<h3>A. Volume Metrics</h3>
<div class="kpi-grid">
  <div class="kpi-card">
    <div class="kpi-name">Total Volume</div>
    <div class="kpi-desc">Total number of supplier interactions handled in a given period (week, month, or YTD).</div>
    <div class="kpi-formula">Total Volume = COUNT(all rows in BAU)</div>
  </div>
  <div class="kpi-card">
    <div class="kpi-name">Mail Volume</div>
    <div class="kpi-desc">Number of interactions handled via email/mail channel.</div>
    <div class="kpi-formula">Mail Volume = COUNT(rows where Mode = "Mail")</div>
  </div>
  <div class="kpi-card">
    <div class="kpi-name">Chat Volume</div>
    <div class="kpi-desc">Number of interactions handled via live chat.</div>
    <div class="kpi-formula">Chat Volume = COUNT(rows where Mode = "Chat")</div>
  </div>
  <div class="kpi-card">
    <div class="kpi-name">After-Hours Coverage %</div>
    <div class="kpi-bench">No benchmark — higher = more extended support</div>
    <div class="kpi-desc">Percentage of interactions handled outside standard business hours. Shows extended support availability.</div>
    <div class="kpi-formula">After-Hours % = (COUNT(After-Hours = "Yes") / Total Volume) × 100</div>
  </div>
</div>

<h3>B. Quality KPIs</h3>
<div class="kpi-grid">
  <div class="kpi-card">
    <div class="kpi-name">FCR — First Contact Resolution %</div>
    <div class="kpi-bench">Benchmark: ≥ 80%</div>
    <div class="kpi-desc">Percentage of cases fully resolved without the supplier needing to follow up. High FCR means the team resolves issues completely the first time.</div>
    <div class="kpi-formula">FCR % = (COUNT(First contact resolution = "Yes") / Total Volume) × 100</div>
  </div>
  <div class="kpi-card">
    <div class="kpi-name">Transfer Rate %</div>
    <div class="kpi-bench">Benchmark: ≤ 5%</div>
    <div class="kpi-desc">Percentage of cases that had to be escalated (transferred) to another team. Lower is better — it means the frontline team can handle more independently.</div>
    <div class="kpi-formula">Transfer Rate % = (COUNT(Transfered = "Yes") / Total Volume) × 100</div>
  </div>
</div>

<h3>C. Time-Based KPIs</h3>
<p>All time fields in the Excel are entered as HH:MM:SS. The system converts these to <strong>minutes</strong> for calculation.</p>
<div class="kpi-grid">
  <div class="kpi-card">
    <div class="kpi-name">AHT — Average Handling Time</div>
    <div class="kpi-bench">Benchmark: ≤ 30 minutes</div>
    <div class="kpi-desc">Average time spent actively working on a case (per interaction). Calculated separately for Mail and Chat. Lower is better — means the team works efficiently.</div>
    <div class="kpi-formula">Avg AHT (Mail) = AVERAGE(AHT column, Mail rows only) in minutes
Avg AHT (Chat) = AVERAGE(AHT column, Chat rows only) in minutes</div>
  </div>
  <div class="kpi-card">
    <div class="kpi-name">FRT — First Response Time</div>
    <div class="kpi-bench">Mail: ≤ 60 min | Chat: ≤ 1 min</div>
    <div class="kpi-desc">Average time from when a supplier sends a request to when the team first responds. Chat has a strict 1-minute benchmark because it is a real-time channel.</div>
    <div class="kpi-formula">Avg FRT (Mail) = AVERAGE(First Response Time, Mail rows) in minutes
Avg FRT (Chat) = AVERAGE(First Response Time, Chat rows) in minutes</div>
  </div>
  <div class="kpi-card">
    <div class="kpi-name">Resolution Time</div>
    <div class="kpi-bench">Benchmark: ≤ 30 minutes (BAU)</div>
    <div class="kpi-desc">Total time from receiving a request to fully resolving it. Different from AHT — includes wait time, not just active work time.</div>
    <div class="kpi-formula">Avg Resolution (Mail) = AVERAGE(Resolution column, Mail rows) in minutes
Avg Resolution (Chat) = AVERAGE(Resolution column, Chat rows) in minutes</div>
  </div>
  <div class="kpi-card">
    <div class="kpi-name">Transferred SLA Compliance %</div>
    <div class="kpi-bench">Benchmark: ≤ 48 hours</div>
    <div class="kpi-desc">For escalated cases: what percentage were resolved within the agreed SLA target. The SLA target varies per case (24 hrs, 48 hrs, 3-5 business days).</div>
    <div class="kpi-formula">SLA % = (COUNT(Resolution Time ≤ SLA Target) / Total tracked) × 100</div>
  </div>
</div>

<h3>D. Brand Issue Analysis KPIs</h3>
<p>These KPIs analyse patterns in supplier requests to identify recurring problems.</p>

<div class="box box-gray">
<strong>How New vs. Repeated is determined:</strong> The system looks at all cases (BAU + Transferred) combined, sorted by date. For each unique combination of Brand Name + Category, the very first occurrence is labelled <strong>New</strong>. Every subsequent occurrence of the same Brand + Category combination is labelled <strong>Repeated</strong>. This tells you which brands keep running into the same issues.
</div>

<div class="kpi-grid">
  <div class="kpi-card">
    <div class="kpi-name">Total Issues</div>
    <div class="kpi-desc">Total count of all cases across both BAU and Transferred sheets.</div>
    <div class="kpi-formula">Total Issues = COUNT(BAU rows) + COUNT(Transferred rows)</div>
  </div>
  <div class="kpi-card">
    <div class="kpi-name">New Issues %</div>
    <div class="kpi-desc">Percentage of cases where the brand encountered this category for the first time. High new-issue rate may indicate a growing number of brands or new product launches causing new types of problems.</div>
    <div class="kpi-formula">New % = (COUNT(New issues) / Total Issues) × 100</div>
  </div>
  <div class="kpi-card">
    <div class="kpi-name">Repeated Issues %</div>
    <div class="kpi-desc">Percentage of cases that are repeat occurrences. A high repeated-issue rate for a brand signals an unresolved systemic problem that needs root-cause analysis.</div>
    <div class="kpi-formula">Repeated % = (COUNT(Repeated issues) / Total Issues) × 100</div>
  </div>
  <div class="kpi-card">
    <div class="kpi-name">Issue Recurrence Rate</div>
    <div class="kpi-desc">Same as Repeated Issues % — used in the Business Value KPI section as a standalone performance indicator. Target: keep this low.</div>
    <div class="kpi-formula">= Repeated Issues %</div>
  </div>
</div>

<h3>E. Transferred Cases KPIs</h3>
<div class="kpi-grid">
  <div class="kpi-card">
    <div class="kpi-name">Completion Rate %</div>
    <div class="kpi-bench">Target: as close to 100% as possible</div>
    <div class="kpi-desc">Percentage of transferred cases that have been fully resolved (Status = "Completed").</div>
    <div class="kpi-formula">Completion % = (COUNT(Status = "Completed") / Total Transferred) × 100</div>
  </div>
  <div class="kpi-card">
    <div class="kpi-name">Open Cases</div>
    <div class="kpi-desc">Cases that are still in progress (Status = Working, Waiting for Supplier to Reply, or Kept Supplier on HOLD). These require active follow-up.</div>
    <div class="kpi-formula">Open = Total Transferred - COUNT(Status = "Completed")</div>
  </div>
  <div class="kpi-card">
    <div class="kpi-name">Avg Resolution Time (Transferred)</div>
    <div class="kpi-bench">Benchmark: ≤ 48 hours</div>
    <div class="kpi-desc">Average time to resolve transferred cases, in hours. Transferred cases take longer than BAU because they require specialist input or supplier cooperation.</div>
    <div class="kpi-formula">Avg Res Hrs = AVERAGE(Resolution Time column) ÷ 60</div>
  </div>
  <div class="kpi-card">
    <div class="kpi-name">Transferred Resolution %</div>
    <div class="kpi-desc">Used in the Business Value section. Identical to Completion Rate — the percentage of all transferred tickets that have been closed out.</div>
    <div class="kpi-formula">= Completion Rate %</div>
  </div>
</div>

<h3>F. Business Value KPIs</h3>
<p>These are composite or derived metrics that go beyond simple counts and averages to show the business impact of the OAM team's work.</p>

<div class="kpi-grid">
  <div class="kpi-card">
    <div class="kpi-name">Escalation Avoidance Rate %</div>
    <div class="kpi-bench">Target: ≥ 95%</div>
    <div class="kpi-desc">The flip side of Transfer Rate. Shows what percentage of cases the frontline team resolved WITHOUT escalating. High rate = team is highly capable.</div>
    <div class="kpi-formula">Escalation Avoidance = 100% − Transfer Rate %</div>
  </div>
  <div class="kpi-card">
    <div class="kpi-name">First-Touch Resolution Rate %</div>
    <div class="kpi-bench">Target: ≥ 80%</div>
    <div class="kpi-desc">Same as FCR. Branded as a "Business Value" KPI to emphasise its strategic importance — each first-touch resolution avoids a follow-up interaction and saves time for both team and supplier.</div>
    <div class="kpi-formula">= FCR %</div>
  </div>
  <div class="kpi-card">
    <div class="kpi-name">Chat Responsiveness Index</div>
    <div class="kpi-bench">Target: ≥ 100 (at or better than benchmark)</div>
    <div class="kpi-desc">Measures how fast chat responses are relative to the 1-minute benchmark. A score of 100 means exactly at benchmark; above 100 means faster than target.</div>
    <div class="kpi-formula">Chat Resp. Index = (1 minute ÷ Actual Avg Chat FRT) × 100</div>
  </div>
  <div class="kpi-card">
    <div class="kpi-name">Operational Efficiency Score %</div>
    <div class="kpi-desc">A composite score measuring how consistently the team meets time benchmarks. Combines the percentage of cases meeting AHT target, Mail FRT target, and Chat FRT target.</div>
    <div class="kpi-formula">Ops Efficiency = (% AHT within target + % Mail FRT within target + % Chat FRT within target) ÷ 3</div>
  </div>
  <div class="kpi-card">
    <div class="kpi-name">Brand Engagement Score %</div>
    <div class="kpi-desc">Measures how many unique brands are being served relative to total interaction volume. High score means the team is handling a diverse portfolio of brands.</div>
    <div class="kpi-formula">Brand Engagement = (Unique Brands Served ÷ Total Interactions) × 100</div>
  </div>
  <div class="kpi-card">
    <div class="kpi-name">After-Hours Coverage %</div>
    <div class="kpi-desc">Percentage of interactions handled outside standard hours. Used as a Business Value KPI to demonstrate the team's extended service commitment to suppliers.</div>
    <div class="kpi-formula">= After-Hours % (same as Volume Metric)</div>
  </div>
</div>

<h3>G. Analyst-Level KPIs</h3>
<p>The dashboard's Analyst Performance section shows individual analyst metrics calculated from the BAU sheet.</p>
<table>
  <thead><tr><th>Metric</th><th>Formula</th></tr></thead>
  <tbody>
    <tr><td>Total Cases</td><td>COUNT(rows assigned to this analyst)</td></tr>
    <tr><td>FCR %</td><td>COUNT(FCR = "Yes" for this analyst) / analyst total × 100</td></tr>
    <tr><td>Avg AHT (min)</td><td>AVERAGE(AHT_min for this analyst)</td></tr>
    <tr><td>Avg FRT (min)</td><td>AVERAGE(FRT_min for this analyst)</td></tr>
    <tr><td>Transfer Rate %</td><td>COUNT(Transferred = "Yes" for this analyst) / analyst total × 100</td></tr>
  </tbody>
</table>
</div>

<!-- ═══════════════════ SECTION 11 ═══════════════════ -->
<div class="section page-break" id="s11">
<h2>11. Benchmark Reference Table</h2>

<p>Benchmarks are the performance targets the team is measured against. They are built into the system and used to colour-code KPI cards (green = meeting target, red = below target).</p>

<table>
  <thead><tr><th>KPI</th><th>Channel</th><th>Target</th><th>Direction</th><th>Meaning</th></tr></thead>
  <tbody>
    <tr><td>First Response Time (FRT)</td><td>Chat</td><td>≤ 1 minute</td><td>Lower is better</td><td>Chat is real-time — suppliers expect near-instant replies</td></tr>
    <tr><td>First Response Time (FRT)</td><td>Mail</td><td>≤ 60 minutes</td><td>Lower is better</td><td>Email allows slightly more time but must be responded within 1 hour</td></tr>
    <tr><td>Average Handling Time (AHT)</td><td>Both</td><td>≤ 30 minutes</td><td>Lower is better</td><td>Cases taking longer than 30 minutes indicate complexity or inefficiency</td></tr>
    <tr><td>Resolution Time</td><td>Both</td><td>≤ 30 minutes</td><td>Lower is better</td><td>BAU cases should be resolved quickly; complex ones move to Transferred</td></tr>
    <tr><td>First Contact Resolution (FCR)</td><td>Both</td><td>≥ 80%</td><td>Higher is better</td><td>At least 8 in 10 cases should be fully resolved without follow-up</td></tr>
    <tr><td>Supplier Satisfaction (SSAT)</td><td>Both</td><td>≥ 4.5 / 5.0</td><td>Higher is better</td><td>Satisfaction score target (if collected)</td></tr>
    <tr><td>Escalation / Transfer Rate</td><td>Both</td><td>≤ 5%</td><td>Lower is better</td><td>No more than 5 in 100 cases should need escalation</td></tr>
    <tr><td>Transferred Case SLA</td><td>Transferred</td><td>≤ 48 hours</td><td>Lower is better</td><td>Escalated cases must be resolved within 48 hours by default</td></tr>
  </tbody>
</table>

<h3>Fiscal Year Structure</h3>
<table>
  <thead><tr><th>Period</th><th>Weeks</th><th>Calendar Months</th></tr></thead>
  <tbody>
    <tr><td>FY25</td><td>Week 38 – Week 53</td><td>September – December 2025</td></tr>
    <tr><td>FY26</td><td>Week 1 – Week 37</td><td>January – September 2026</td></tr>
  </tbody>
</table>
<p>The system automatically assigns each row to the correct fiscal year based on the <em>Request Received Date</em>.</p>
</div>

<!-- ═══════════════════ SECTION 12 ═══════════════════ -->
<div class="section page-break" id="s12">
<h2>12. Understanding the Dashboard Sections</h2>

<h3>Top Row — Snapshot KPI Cards</h3>
<p>Shows the current week's headline numbers at a glance: Total Volume, Mail Volume, Chat Volume, FCR %, Transfer Rate %, After-Hours %, and Transferred case counts (Total / Open / Resolved).</p>

<h3>Weekly Trends</h3>
<p>Line and bar charts showing how each KPI has changed week by week. Use the <strong>Fiscal Year selector</strong> to switch between FY25 and FY26. The <strong>View</strong> toggle switches between Total Volume, FCR, AHT, and FRT trend charts.</p>

<h3>YTD Summary</h3>
<p>Year-to-date aggregate figures for the current fiscal year — total interactions, average KPIs across all weeks.</p>

<h3>Category Distribution</h3>
<p>Bar chart showing the volume breakdown by request category (Campaign Setup Guidance, OA Platform Access/Login Issues, Reporting/Data Requests, Other), split by Mail vs. Chat.</p>

<h3>Brand Issue Analysis</h3>
<p>The most strategic section. Shows per-brand breakdown of New vs. Repeated issues. Brands with a high Repeated % are candidates for proactive root-cause resolution or self-service documentation.</p>
<ul>
  <li><strong>(Multi-Brand Case):</strong> Cases where a single interaction covered multiple brands — counted separately, not attributed to one brand.</li>
</ul>

<h3>Transferred Cases</h3>
<p>Two sub-sections:</p>
<ul>
  <li><strong>Brand Summary:</strong> Per-brand table showing total transferred, completion rate, SLA %, and average resolution hours.</li>
  <li><strong>Open Cases Tracker:</strong> Live list of all currently open transferred cases — updated every time you restart the server. Shows brand, week, category, status, SLA, and analyst assigned.</li>
</ul>

<h3>Business Value KPIs</h3>
<p>Eight composite metrics (described in Section 10F) shown as gauge/score cards, giving leadership a single-page view of the team's strategic performance.</p>

<h3>Analyst Performance</h3>
<p>Table showing individual analyst metrics — useful for identifying coaching opportunities or recognising top performers.</p>
</div>

<!-- ═══════════════════ SECTION 13 ═══════════════════ -->
<div class="section page-break" id="s13">
<h2>13. Troubleshooting Guide</h2>

<table>
  <thead><tr><th>Problem</th><th>Likely Cause</th><th>Solution</th></tr></thead>
  <tbody>
    <tr>
      <td><strong>Dashboard shows "This site can't be reached"</strong></td>
      <td>The Flask server is not running</td>
      <td>Open PowerShell, navigate to <code>thd_portal</code>, activate venv, and run <code>python app.py</code>. Keep the window open.</td>
    </tr>
    <tr>
      <td><strong>Dashboard loads but shows old data</strong></td>
      <td>Browser or server has cached old data</td>
      <td>Stop the server (Ctrl+C), restart it (<code>python app.py</code>), then press <strong>Ctrl+Shift+R</strong> in the browser.</td>
    </tr>
    <tr>
      <td><strong>Error: "No module named flask" (or pandas, etc.)</strong></td>
      <td>Virtual environment is not activated, or packages not installed</td>
      <td>Run <code>.\\venv\\Scripts\\Activate.ps1</code> first. If that fails, run <code>pip install flask pandas openpyxl numpy matplotlib</code>.</td>
    </tr>
    <tr>
      <td><strong>Error: "can't open file ... app.py: No such file"</strong></td>
      <td>You are in the wrong directory</td>
      <td>Make sure you <code>cd</code> into the <code>thd_portal</code> folder before running <code>python app.py</code>. Do not add <code>thd_portal\\</code> prefix when you are already inside it.</td>
    </tr>
    <tr>
      <td><strong>Script cannot open Productivity_Sheet.xlsx</strong></td>
      <td>File is open in Excel, or file was moved/renamed</td>
      <td>Close Excel completely, then re-run the script. Never rename or move the file.</td>
    </tr>
    <tr>
      <td><strong>clean_data.py runs but shows no fixes</strong></td>
      <td>Data was already clean</td>
      <td>This is expected and fine — the script reports "No issues found" when data is already clean.</td>
    </tr>
    <tr>
      <td><strong>PowerShell says "running scripts is disabled"</strong></td>
      <td>Windows security policy blocks script execution</td>
      <td>Run: <code>Set-ExecutionPolicy -Scope CurrentUser RemoteSigned</code>, type Y, press Enter. Then try again.</td>
    </tr>
    <tr>
      <td><strong>Charts show "MULTIPLE BRANDS" instead of "(Multi-Brand Case)"</strong></td>
      <td>Source data in Excel still has old values</td>
      <td>Run <code>python clean_data.py</code> to fix source data, then restart the server.</td>
    </tr>
    <tr>
      <td><strong>Server starts but immediately crashes with an error</strong></td>
      <td>Usually a missing column in the Excel sheet, or a column name has a typo</td>
      <td>Read the error message carefully — it usually names the column. Check <code>Productivity_Sheet.xlsx</code> to ensure all column headers exactly match the names in Section 2.</td>
    </tr>
    <tr>
      <td><strong>Export buttons do nothing</strong></td>
      <td>Browser blocked the download, or server error</td>
      <td>Check browser's download bar. If server shows an error in PowerShell, note the error text and check column names in the Excel file.</td>
    </tr>
  </tbody>
</table>

<h3>Quick Reference: All Commands</h3>
<pre># Navigate to project root
cd "C:\\Users\\2243377\\OneDrive - Cognizant\\Documents\\Personal\\Illaya"

# Activate virtual environment (do this every new PowerShell session)
.\\venv\\Scripts\\Activate.ps1

# Run the data cleaner (after updating Productivity_Sheet.xlsx)
python clean_data.py

# Start the web dashboard
cd thd_portal
python app.py
# → Open browser: http://localhost:5000
# → Stop server: Ctrl+C

# Generate Brand KPI chart + Excel report
cd "C:\\Users\\2243377\\OneDrive - Cognizant\\Documents\\Personal\\Illaya"
python run_brand_kpis.py</pre>

<h3>When to Run Each Script</h3>
<table>
  <thead><tr><th>Frequency</th><th>Action</th></tr></thead>
  <tbody>
    <tr><td>Every session (when you open PowerShell)</td><td>Activate venv: <code>.\\venv\\Scripts\\Activate.ps1</code></td></tr>
    <tr><td>After any data entry in Productivity_Sheet.xlsx</td><td>Run <code>python clean_data.py</code></td></tr>
    <tr><td>Whenever you want to view the dashboard</td><td>Run <code>python app.py</code> in thd_portal</td></tr>
    <tr><td>Weekly (for reporting)</td><td>Run <code>python run_brand_kpis.py</code> + export from dashboard</td></tr>
    <tr><td>One time only</td><td>Virtual environment setup (Section 4)</td></tr>
  </tbody>
</table>
</div>

<div class="footer">
  THD OAM Supplier Analytics Portal — Internal Handover Document &nbsp;|&nbsp;
  Generated: """ + datetime.now().strftime("%B %d, %Y at %H:%M") + """ &nbsp;|&nbsp;
  For support: <a href="mailto:illayapallavan.g@gmail.com">illayapallavan.g@gmail.com</a>
</div>

</body>
</html>"""

OUT.write_text(HTML, encoding="utf-8")
print(f"\nHandover document created successfully!")
print(f"File: {OUT}")
print(f"\nTo save as PDF:")
print(f"  1. Open the file in Chrome or Edge")
print(f"  2. Press Ctrl+P (Print)")
print(f"  3. Change 'Destination' to 'Save as PDF'")
print(f"  4. Set Margins to 'None' or 'Minimum'")
print(f"  5. Tick 'Background graphics'")
print(f"  6. Click Save")
