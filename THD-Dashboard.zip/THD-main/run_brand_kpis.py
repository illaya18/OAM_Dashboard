import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.colors import LinearSegmentedColormap
import warnings
warnings.filterwarnings('ignore')

from pathlib import Path as _Path
FILE = str(_Path(__file__).resolve().parent / "Productivity_Sheet.xlsx")

df_t = pd.read_excel(FILE, sheet_name='Transferred')

# Clean brand names
df_t['Brand Name'] = (
    df_t['Brand Name'].astype(str)
    .str.strip().str.upper()
    .str.replace(r'\s+', ' ', regex=True)
)
df_t['Brand Name'] = df_t['Brand Name'].replace('MULTIPLE BRANDS', '(Multi-Brand Case)')
df_t = df_t[df_t['Brand Name'].notna() & (df_t['Brand Name'] != 'NAN')]

# Time -> hours
for col in ['AHT', 'Resolution Time', 'First Response Time']:
    df_t[col + '_hrs'] = pd.to_timedelta(df_t[col], errors='coerce').dt.total_seconds() / 3600

df_t['Week_Num'] = df_t['Week'].str.extract(r'(\d+)').astype(float)

sla_map = {'24 hrs': 24, '24-48 hrs': 48, '48 hrs': 48, '3-5 business': 120}
df_t['SLA_target_hrs'] = df_t['SLA'].map(sla_map)
df_t['SLA_Met'] = df_t['Resolution Time_hrs'] <= df_t['SLA_target_hrs']
df_t['Is_Completed'] = df_t['Status'].str.strip().str.lower() == 'completed'

# Brand KPI
brand_kpi = df_t.groupby('Brand Name').agg(
    Total_Requests     =('Brand Name', 'count'),
    Completed          =('Is_Completed', 'sum'),
    Avg_AHT_hrs        =('AHT_hrs', 'mean'),
    Avg_Resolution_hrs =('Resolution Time_hrs', 'mean'),
    Avg_FRT_hrs        =('First Response Time_hrs', 'mean'),
    SLA_Met            =('SLA_Met', 'sum'),
    SLA_Tracked        =('SLA_target_hrs', lambda x: x.notna().sum()),
    After_Hours        =('After-Hours', lambda x: (x.astype(str).str.strip().str.lower() == 'yes').sum())
).reset_index()

brand_kpi['Completion_Rate_%']  = (brand_kpi['Completed']  / brand_kpi['Total_Requests'] * 100).round(1)
brand_kpi['SLA_Compliance_%']   = (brand_kpi['SLA_Met'] / brand_kpi['SLA_Tracked'].replace(0, np.nan) * 100).round(1)
brand_kpi['Avg_AHT_hrs']        = brand_kpi['Avg_AHT_hrs'].round(2)
brand_kpi['Avg_Resolution_hrs'] = brand_kpi['Avg_Resolution_hrs'].round(2)
brand_kpi['Avg_FRT_hrs']        = brand_kpi['Avg_FRT_hrs'].round(2)
brand_kpi = brand_kpi.sort_values('Total_Requests', ascending=False).reset_index(drop=True)

# Weekly volume pivot
weekly_brand_vol = (
    df_t.groupby(['Week_Num', 'Brand Name'])
    .size().reset_index(name='Requests')
    .sort_values(['Week_Num', 'Requests'], ascending=[True, False])
)
brand_week_pivot = weekly_brand_vol.pivot_table(
    index='Brand Name', columns='Week_Num', values='Requests', fill_value=0)
brand_week_pivot.columns = [f'Wk {int(c)}' for c in brand_week_pivot.columns]
brand_week_pivot['Total'] = brand_week_pivot.sum(axis=1)
brand_week_pivot = brand_week_pivot.sort_values('Total', ascending=False)

# Open cases
open_statuses = ['Waiting for Supplier to Reply', 'Kept Supplier on HOLD', 'Working']
df_open = df_t[df_t['Status'].isin(open_statuses)].copy()

# Weekly summary
weekly_summary = df_t.groupby(['Week', 'Week_Num']).agg(
    Brands_Active  =('Brand Name', 'nunique'),
    Total_Requests =('Brand Name', 'count'),
    Completed      =('Is_Completed', 'sum'),
    Avg_AHT_hrs    =('AHT_hrs', 'mean'),
    Avg_FRT_hrs    =('First Response Time_hrs', 'mean')
).reset_index().sort_values('Week_Num')
weekly_summary['Completion_%'] = (weekly_summary['Completed'] / weekly_summary['Total_Requests'] * 100).round(1)
weekly_summary['Avg_AHT_hrs']  = weekly_summary['Avg_AHT_hrs'].round(1)
weekly_summary['Avg_FRT_hrs']  = weekly_summary['Avg_FRT_hrs'].round(1)

# ───────────────────────── CHART ─────────────────────────────────────────────
TOP_N = 15
top_brands = brand_kpi.head(TOP_N)
top_brand_names = top_brands['Brand Name'].tolist()

plt.style.use('seaborn-v0_8-whitegrid')
fig = plt.figure(figsize=(22, 30))
fig.suptitle(
    'Brand Business Value KPI Dashboard\n(Transferred Cases - Weekly Client Report)',
    fontsize=18, fontweight='bold', y=0.99)

# 1 – Total Requests
ax1 = fig.add_subplot(4, 2, 1)
bars = ax1.barh(top_brands['Brand Name'][::-1], top_brands['Total_Requests'][::-1], color='#1f77b4')
ax1.set_xlabel('Number of Requests', fontsize=10)
ax1.set_title('Total Requests by Brand', fontsize=12, fontweight='bold')
for bar, val in zip(bars, top_brands['Total_Requests'][::-1]):
    ax1.text(val + 0.05, bar.get_y() + bar.get_height() / 2, str(int(val)), va='center', fontsize=9)

# 2 – Completion Rate
ax2 = fig.add_subplot(4, 2, 2)
cr = top_brands.sort_values('Completion_Rate_%')
cr_colors = ['#2ecc71' if v == 100 else '#f39c12' if v >= 80 else '#e74c3c'
             for v in cr['Completion_Rate_%']]
bars2 = ax2.barh(cr['Brand Name'], cr['Completion_Rate_%'], color=cr_colors)
ax2.axvline(x=100, color='green', linestyle='--', alpha=0.5)
ax2.set_xlabel('Completion Rate (%)', fontsize=10)
ax2.set_title('Resolution Completion Rate by Brand', fontsize=12, fontweight='bold')
ax2.set_xlim(0, 115)
for bar, val in zip(bars2, cr['Completion_Rate_%']):
    ax2.text(val + 0.5, bar.get_y() + bar.get_height() / 2, f'{val:.0f}%', va='center', fontsize=9)
ax2.legend(handles=[
    mpatches.Patch(color='#2ecc71', label='100% Complete'),
    mpatches.Patch(color='#f39c12', label='80-99%'),
    mpatches.Patch(color='#e74c3c', label='<80%'),
], fontsize=8, loc='lower right')

# 3 – Avg Resolution Time
ax3 = fig.add_subplot(4, 2, 3)
res_data = top_brands.dropna(subset=['Avg_Resolution_hrs']).sort_values('Avg_Resolution_hrs')
res_colors = ['#2ecc71' if v <= 48 else '#f39c12' if v <= 120 else '#e74c3c'
              for v in res_data['Avg_Resolution_hrs']]
bars3 = ax3.barh(res_data['Brand Name'], res_data['Avg_Resolution_hrs'], color=res_colors)
ax3.axvline(x=48, color='orange', linestyle='--', alpha=0.7, label='48-hr SLA')
ax3.set_xlabel('Avg Resolution Time (hours)', fontsize=10)
ax3.set_title('Avg Resolution Time by Brand', fontsize=12, fontweight='bold')
ax3.legend(fontsize=8)
for bar, val in zip(bars3, res_data['Avg_Resolution_hrs']):
    ax3.text(val + 0.3, bar.get_y() + bar.get_height() / 2, f'{val:.1f}h', va='center', fontsize=9)

# 4 – SLA Compliance
ax4 = fig.add_subplot(4, 2, 4)
sla_data = top_brands.dropna(subset=['SLA_Compliance_%']).sort_values('SLA_Compliance_%')
sla_colors = ['#2ecc71' if v >= 90 else '#f39c12' if v >= 70 else '#e74c3c'
              for v in sla_data['SLA_Compliance_%']]
bars4 = ax4.barh(sla_data['Brand Name'], sla_data['SLA_Compliance_%'], color=sla_colors)
ax4.axvline(x=90, color='red', linestyle='--', alpha=0.7, label='90% SLA target')
ax4.set_xlabel('SLA Compliance (%)', fontsize=10)
ax4.set_title('SLA Compliance by Brand', fontsize=12, fontweight='bold')
ax4.set_xlim(0, 115)
ax4.legend(fontsize=8)
for bar, val in zip(bars4, sla_data['SLA_Compliance_%']):
    ax4.text(val + 0.5, bar.get_y() + bar.get_height() / 2, f'{val:.0f}%', va='center', fontsize=9)

# 5 – Weekly Brand Activity Heatmap
ax5 = fig.add_subplot(4, 1, 3)
week_cols = [c for c in brand_week_pivot.columns if c != 'Total']
heatmap_data = brand_week_pivot.loc[
    [b for b in top_brand_names if b in brand_week_pivot.index], week_cols]
cmap = LinearSegmentedColormap.from_list('brand_heat', ['#f7fbff', '#2171b5'])
im = ax5.imshow(heatmap_data.values, cmap=cmap, aspect='auto')
ax5.set_xticks(range(len(heatmap_data.columns)))
ax5.set_xticklabels(heatmap_data.columns, fontsize=10)
ax5.set_yticks(range(len(heatmap_data.index)))
ax5.set_yticklabels(heatmap_data.index, fontsize=9)
ax5.set_title('Weekly Brand Activity Heatmap (Transferred Cases)', fontsize=13, fontweight='bold')
plt.colorbar(im, ax=ax5, label='# Requests', shrink=0.8)
for i in range(len(heatmap_data.index)):
    for j in range(len(heatmap_data.columns)):
        val = int(heatmap_data.values[i, j])
        if val > 0:
            ax5.text(j, i, str(val), ha='center', va='center', fontsize=9,
                     color='white' if val > 1 else 'black', fontweight='bold')

# 6 – Category Mix by Brand
ax6 = fig.add_subplot(4, 1, 4)
cat_clean = df_t['Category'].astype(str).str.strip().str.replace(r'\s+', ' ', regex=True)
top_cats = cat_clean.value_counts().head(4).index.tolist()
df_t['Category_Clean'] = cat_clean.where(cat_clean.isin(top_cats), other='Other')
cat_brand = (
    df_t[df_t['Brand Name'].isin(top_brand_names)]
    .groupby(['Brand Name', 'Category_Clean'])
    .size().unstack(fill_value=0)
)
cat_brand = cat_brand.loc[[b for b in top_brand_names if b in cat_brand.index]]
cat_colors = ['#3498db', '#e74c3c', '#2ecc71', '#f39c12', '#9b59b6']
cat_brand.plot(kind='bar', stacked=True, ax=ax6,
               color=cat_colors[:len(cat_brand.columns)], width=0.7)
ax6.set_xlabel('Brand', fontsize=10)
ax6.set_ylabel('Requests', fontsize=10)
ax6.set_title('Request Category Mix by Brand', fontsize=13, fontweight='bold')
ax6.tick_params(axis='x', rotation=40)
ax6.legend(title='Category', bbox_to_anchor=(1.01, 1), loc='upper left', fontsize=9)

plt.tight_layout(rect=[0, 0, 1, 0.98])
CHART = str(_Path(__file__).resolve().parent / "chart_brand_kpi.png")
plt.savefig(CHART, dpi=200, bbox_inches='tight', facecolor='white')
plt.close()
print(f"Chart saved: {CHART}")

# ─────────────────────────── EXCEL EXPORT ────────────────────────────────────
REPORT = str(_Path(__file__).resolve().parent / "Brand_KPI_Report.xlsx")
with pd.ExcelWriter(REPORT, engine='openpyxl') as writer:
    export_cols = ['Brand Name', 'Total_Requests', 'Completion_Rate_%',
                   'Avg_AHT_hrs', 'Avg_Resolution_hrs', 'Avg_FRT_hrs',
                   'SLA_Compliance_%', 'After_Hours']
    brand_kpi[export_cols].to_excel(writer, sheet_name='Brand KPI Scorecard', index=False)

    brand_week_pivot.to_excel(writer, sheet_name='Weekly Volume by Brand')

    open_cols = ['Brand Name', 'Week', 'Mode', 'Category', 'Sub Category', 'Status',
                 'AHT_hrs', 'Resolution Time_hrs', 'Executed Actions',
                 'Next Step', 'Recent Update / Follow up', 'Analyst Name']
    df_open[[c for c in open_cols if c in df_open.columns]].to_excel(
        writer, sheet_name='Open Cases Tracker', index=False)

    weekly_summary.drop(columns='Week_Num', errors='ignore').to_excel(
        writer, sheet_name='Weekly Summary', index=False)

    keep_cols = ['S. No', 'Mode', 'Week', 'Request Received Date', 'Process Date',
                 'Analyst Name', 'Brand Name', 'Category', 'Sub Category',
                 'Status', 'SLA', 'SLA_Met', 'AHT_hrs', 'Resolution Time_hrs',
                 'First Response Time_hrs', 'Is_Completed', 'After-Hours',
                 'Executed Actions', 'Next Step', 'Recent Update / Follow up']
    df_t[[c for c in keep_cols if c in df_t.columns]].to_excel(
        writer, sheet_name='All Transferred Data', index=False)

print(f"Excel report saved: {REPORT}")
print("\nSheets:")
for s in ['Brand KPI Scorecard', 'Weekly Volume by Brand', 'Open Cases Tracker',
          'Weekly Summary', 'All Transferred Data']:
    print(f"  - {s}")
