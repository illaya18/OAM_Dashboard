Attribute VB_Name = "THD_OAM_Macros"
Option Explicit

' ============================================================
'  THD OAM Supplier Support - Report Automation Macros
'  After importing this .bas file, run AddButtons() ONCE to
'  replace the styled-cell placeholders with real clickable
'  Form Control buttons wired to the three macros below.
' ============================================================

Private Const RPT_SHEET    As String = "Report"
Private Const BAU_SHEET    As String = "BAU_Data"
Private Const TR_SHEET     As String = "Transfer_Data"
Private Const OUT_START    As Long   = 15

Private Const C_FY    As String = "C4"
Private Const C_WEEK  As String = "C5"
Private Const C_BRAND As String = "C6"
Private Const C_CHAN  As String = "C7"
Private Const C_CAT   As String = "C8"
Private Const C_STAT  As String = "C9"
Private Const C_SRC   As String = "C10"

' THD color constants (BGR order for VBA)
Private Const CLR_ORANGE      As Long = &H0262F9
Private Const CLR_DARK_ORANGE As Long = &H004ECC
Private Const CLR_WHITE       As Long = &HFFFFFF
Private Const CLR_BLACK       As Long = &H000000
Private Const CLR_LIGHT_ORG   As Long = &HEBF3FF
Private Const CLR_GRAY_DARK   As Long = &H333333
Private Const CLR_GRAY_LIGHT  As Long = &HF5F5F5
Private Const CLR_GREEN_LIGHT As Long = &HE3F5D5
Private Const CLR_AMBER_LIGHT As Long = &HD0EBFD
Private Const CLR_RED_LIGHT   As Long = &HD8DBFA


' ── AddButtons - run ONCE after importing this .bas file ─────────────────────
Public Sub AddButtons()
    Dim ws As Worksheet: Set ws = ThisWorkbook.Sheets("Report")

    ' Remove existing styled-cell placeholders on row 12
    Dim s As Shape
    For Each s In ws.Shapes
        If s.TopLeftCell.Row = 12 Then s.Delete
    Next s
    ws.Rows(12).ClearContents
    ws.Rows(12).RowHeight = 28

    ' Add real Form Control buttons anchored to their cell ranges
    Dim btn As Button
    Dim rng As Range

    Set rng = ws.Range("A12:C12")
    Set btn = ws.Buttons.Add(rng.Left, rng.Top, rng.Width, rng.Height)
    With btn
        .Caption  = ChrW(9654) & "  GENERATE REPORT"
        .OnAction = "GenerateReport"
        .Font.Bold = True: .Font.Size = 11: .Font.Name = "Calibri"
    End With

    Set rng = ws.Range("E12:G12")
    Set btn = ws.Buttons.Add(rng.Left, rng.Top, rng.Width, rng.Height)
    With btn
        .Caption  = ChrW(10005) & "  CLEAR FILTERS"
        .OnAction = "ClearFilters"
        .Font.Bold = True: .Font.Size = 11: .Font.Name = "Calibri"
    End With

    Set rng = ws.Range("I12:K12")
    Set btn = ws.Buttons.Add(rng.Left, rng.Top, rng.Width, rng.Height)
    With btn
        .Caption  = ChrW(8635) & "  REFRESH DROPDOWNS"
        .OnAction = "RefreshDropdowns"
        .Font.Bold = True: .Font.Size = 11: .Font.Name = "Calibri"
    End With

    MsgBox "Buttons are now active! Save the file as .xlsm to keep macros.", _
           vbInformation, "THD OAM Report"
End Sub


' ── Public entry points ───────────────────────────────────────────────────────

Public Sub GenerateReport()
    Application.ScreenUpdating = False
    Application.Calculation = xlCalculationManual
    On Error GoTo ErrHandler

    Dim wsR As Worksheet: Set wsR = ThisWorkbook.Sheets(RPT_SHEET)
    Dim wsB As Worksheet: Set wsB = ThisWorkbook.Sheets(BAU_SHEET)
    Dim wsT As Worksheet: Set wsT = ThisWorkbook.Sheets(TR_SHEET)

    Dim fFY   As String: fFY   = NormVal(wsR.Range(C_FY).Value)
    Dim fWeek As String: fWeek = NormVal(wsR.Range(C_WEEK).Value)
    Dim fBrnd As String: fBrnd = NormVal(wsR.Range(C_BRAND).Value)
    Dim fChan As String: fChan = NormVal(wsR.Range(C_CHAN).Value)
    Dim fCat  As String: fCat  = NormVal(wsR.Range(C_CAT).Value)
    Dim fStat As String: fStat = NormVal(wsR.Range(C_STAT).Value)
    Dim fSrc  As String: fSrc  = NormVal(wsR.Range(C_SRC).Value)

    Dim doBAU As Boolean: doBAU = (fSrc = "ALL" Or fSrc = "BAU" Or fSrc = "")
    Dim doTR  As Boolean: doTR  = (fSrc = "ALL" Or fSrc = "TRANSFERRED" Or fSrc = "")

    ClearOutput wsR

    Dim outRow As Long: outRow = OUT_START
    Dim bauCnt As Long: bauCnt = 0
    Dim trCnt  As Long: trCnt  = 0

    ' -- Title -----------------------------------------------------------------
    WriteTitle wsR, outRow, fFY, fWeek, fBrnd, fChan, fCat, fStat, fSrc
    outRow = outRow + 2

    ' -- BAU section -----------------------------------------------------------
    If doBAU Then
        Dim bauRows() As Long
        bauRows = CollectRows(wsB, fFY, fWeek, fBrnd, fChan, fCat, "")
        bauCnt = UBound(bauRows) + 1
        WriteSection wsR, wsB, bauRows, outRow, "BAU CONTACTS", True
        outRow = outRow + bauCnt + 4
        If bauCnt > 0 Then
            WriteSummary wsR, wsB, bauRows, outRow
            outRow = outRow + 7
        End If
    End If

    ' -- Transferred section ---------------------------------------------------
    If doTR Then
        Dim trRows() As Long
        trRows = CollectRows(wsT, fFY, fWeek, fBrnd, fChan, fCat, fStat)
        trCnt  = UBound(trRows) + 1
        WriteSection wsR, wsT, trRows, outRow, "TRANSFERRED REQUESTS", False
        outRow = outRow + trCnt + 4
    End If

    wsR.Columns.AutoFit
    wsR.Activate: wsR.Range("A1").Select

    MsgBox "Report ready!  BAU: " & bauCnt & " rows   Transferred: " & trCnt & " rows.", _
           vbInformation, "THD OAM Report"
    GoTo Cleanup

ErrHandler:
    MsgBox "Error " & Err.Number & ": " & Err.Description, vbCritical, "Report Error"
Cleanup:
    Application.ScreenUpdating = True
    Application.Calculation = xlCalculationAutomatic
End Sub


Public Sub ClearFilters()
    Dim wsR As Worksheet: Set wsR = ThisWorkbook.Sheets(RPT_SHEET)
    wsR.Range(C_FY).Value    = ""
    wsR.Range(C_WEEK).Value  = ""
    wsR.Range(C_BRAND).Value = ""
    wsR.Range(C_CHAN).Value  = ""
    wsR.Range(C_CAT).Value   = ""
    wsR.Range(C_STAT).Value  = ""
    wsR.Range(C_SRC).Value   = "All"
    ClearOutput wsR
    MsgBox "Filters cleared.", vbInformation, "THD OAM Report"
End Sub


Public Sub RefreshDropdowns()
    Dim wsB As Worksheet: Set wsB = ThisWorkbook.Sheets(BAU_SHEET)
    Dim wsT As Worksheet: Set wsT = ThisWorkbook.Sheets(TR_SHEET)
    Dim wsR As Worksheet: Set wsR = ThisWorkbook.Sheets(RPT_SHEET)

    Dim lastB As Long: lastB = wsB.Cells(wsB.Rows.Count, 1).End(xlUp).Row
    Dim lastT As Long: lastT = wsT.Cells(wsT.Rows.Count, 1).End(xlUp).Row

    RebuildDropdown wsR.Range(C_FY),    MergeUniq(wsB, "Fiscal_Year", lastB, wsT, "Fiscal_Year", lastT)
    RebuildDropdown wsR.Range(C_WEEK),  MergeUniq(wsB, "Week_Label",  lastB, wsT, "Week_Label",  lastT)
    RebuildDropdown wsR.Range(C_BRAND), MergeUniq(wsB, "Brand Name",  lastB, wsT, "Brand Name",  lastT)
    RebuildDropdown wsR.Range(C_CHAN),  MergeUniq(wsB, "Mode",        lastB, Nothing, "",         0)
    RebuildDropdown wsR.Range(C_CAT),   MergeUniq(wsB, "Category",    lastB, wsT, "Category",    lastT)
    RebuildDropdown wsR.Range(C_STAT),  MergeUniq(Nothing, "",        0,     wsT, "Status",      lastT)
    MsgBox "Dropdowns refreshed.", vbInformation, "THD OAM Report"
End Sub


' ── Private helpers ───────────────────────────────────────────────────────────

Private Function NormVal(v As Variant) As String
    Dim s As String: s = UCase(Trim(CStr(v)))
    If s = "" Or s = "ALL" Then NormVal = "ALL" Else NormVal = s
End Function


Private Function ColIdx(ws As Worksheet, colName As String) As Long
    Dim c As Long
    For c = 1 To ws.UsedRange.Columns.Count
        If LCase(Trim(CStr(ws.Cells(1, c).Value))) = LCase(colName) Then
            ColIdx = c: Exit Function
        End If
    Next c
    ColIdx = 0
End Function


Private Function CollectRows(ws As Worksheet, fFY As String, fWeek As String, _
                              fBrnd As String, fChan As String, fCat As String, _
                              fStat As String) As Long()
    Dim last As Long: last = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    Dim buf() As Long: ReDim buf(last - 2)
    Dim cnt As Long: cnt = 0
    Dim cFY   As Long: cFY   = ColIdx(ws, "Fiscal_Year")
    Dim cWeek As Long: cWeek = ColIdx(ws, "Week_Label")
    Dim cBrnd As Long: cBrnd = ColIdx(ws, "Brand Name")
    Dim cChan As Long: cChan = ColIdx(ws, "Mode")
    Dim cCat  As Long: cCat  = ColIdx(ws, "Category")
    Dim cStat As Long: cStat = ColIdx(ws, "Status")

    Dim i As Long
    For i = 2 To last
        Dim ok As Boolean: ok = True
        If fFY   <> "ALL" And cFY   > 0 Then ok = ok And (UCase(Trim(CStr(ws.Cells(i, cFY).Value)))   = fFY)
        If fWeek <> "ALL" And cWeek > 0 Then ok = ok And (UCase(Trim(CStr(ws.Cells(i, cWeek).Value))) = UCase(fWeek))
        If fBrnd <> "ALL" And cBrnd > 0 Then ok = ok And (UCase(Trim(CStr(ws.Cells(i, cBrnd).Value))) = fBrnd)
        If fChan <> "ALL" And cChan > 0 Then ok = ok And (UCase(Trim(CStr(ws.Cells(i, cChan).Value))) = fChan)
        If fCat  <> "ALL" And cCat  > 0 Then ok = ok And (UCase(Trim(CStr(ws.Cells(i, cCat).Value)))  = fCat)
        If fStat <> "ALL" And cStat > 0 Then ok = ok And (UCase(Trim(CStr(ws.Cells(i, cStat).Value))) = fStat)
        If ok Then buf(cnt) = i: cnt = cnt + 1
    Next i
    If cnt = 0 Then ReDim buf(-1) Else ReDim Preserve buf(cnt - 1)
    CollectRows = buf
End Function


Private Sub WriteTitle(wsR As Worksheet, outRow As Long, _
                        fFY As String, fWeek As String, fBrnd As String, _
                        fChan As String, fCat As String, fStat As String, fSrc As String)
    Dim summary As String
    If fFY   <> "ALL" Then summary = summary & "FY=" & fFY & "  "
    If fWeek <> "ALL" Then summary = summary & "Week=" & fWeek & "  "
    If fBrnd <> "ALL" Then summary = summary & "Brand=" & fBrnd & "  "
    If fChan <> "ALL" Then summary = summary & "Chan=" & fChan & "  "
    If fCat  <> "ALL" Then summary = summary & "Cat=" & fCat & "  "
    If fStat <> "ALL" Then summary = summary & "Status=" & fStat & "  "
    If summary = "" Then summary = "All Data (no filters)"
    summary = Trim(summary) & "  |  Source: " & IIf(fSrc = "ALL" Or fSrc = "", "BAU + Transferred", fSrc)

    With wsR.Range("A" & outRow & ":K" & outRow)
        .Merge: .Value = "THE HOME DEPOT  |  OAM  -- " & summary
        .Interior.Color = CLR_ORANGE
        .Font.Color = CLR_WHITE: .Font.Bold = True: .Font.Size = 12
        .HorizontalAlignment = xlCenter: .RowHeight = 24
    End With
End Sub


Private Sub WriteSection(wsR As Worksheet, wsSrc As Worksheet, rows() As Long, _
                          outRow As Long, title As String, isBAU As Boolean)
    Dim cnt As Long: cnt = UBound(rows) + 1
    With wsR.Range("A" & outRow & ":K" & outRow)
        .Merge: .Value = title & "  (" & cnt & " rows)"
        .Interior.Color = IIf(isBAU, CLR_DARK_ORANGE, &H922B21)
        .Font.Color = CLR_WHITE: .Font.Bold = True: .Font.Size = 11
        .HorizontalAlignment = xlCenter: .RowHeight = 22
    End With
    outRow = outRow + 1

    If cnt = 0 Then
        wsR.Cells(outRow, 1).Value = "(No rows matched the selected filters)"
        Exit Sub
    End If

    Dim showCols() As String, dispNames() As String
    If isBAU Then
        showCols  = Split("Week_Label,Fiscal_Year,Brand Name,Mode,Category,Sub Category,First contact resolution,Transfered,AHT,Resolution,After-Hours,Analyst Name", ",")
        dispNames = Split("Week,FY,Brand,Channel,Category,Sub-Cat,FCR,Transferred,AHT,Resolution,After-Hrs,Analyst", ",")
    Else
        showCols  = Split("Week_Label,Fiscal_Year,Brand Name,Mode,Category,Status,SLA,Next Step,Recent Update / Follow up,Analyst Name", ",")
        dispNames = Split("Week,FY,Brand,Channel,Category,Status,SLA,Next Step,Last Update,Analyst", ",")
    End If

    Dim ci As Long
    For ci = 0 To UBound(showCols)
        With wsR.Cells(outRow, ci + 1)
            .Value = dispNames(ci)
            .Interior.Color = CLR_ORANGE: .Font.Color = CLR_WHITE
            .Font.Bold = True: .Font.Size = 10
            .HorizontalAlignment = xlCenter
            .Borders.LineStyle = xlContinuous
        End With
    Next ci
    outRow = outRow + 1

    Dim srcCols() As Long: ReDim srcCols(UBound(showCols))
    For ci = 0 To UBound(showCols)
        srcCols(ci) = ColIdx(wsSrc, showCols(ci))
    Next ci

    Dim ri As Long
    For ri = 0 To UBound(rows)
        Dim bg As Long: bg = IIf(ri Mod 2 = 0, CLR_LIGHT_ORG, CLR_WHITE)
        For ci = 0 To UBound(showCols)
            Dim v As Variant
            v = IIf(srcCols(ci) > 0, wsSrc.Cells(rows(ri), srcCols(ci)).Value, "")
            With wsR.Cells(outRow + ri, ci + 1)
                .Value = v: .Interior.Color = bg
                .Font.Size = 9: .Borders.LineStyle = xlContinuous
                .Borders.Color = &H666666
            End With
        Next ci
    Next ri
End Sub


Private Sub WriteSummary(wsR As Worksheet, wsB As Worksheet, _
                          rows() As Long, outRow As Long)
    With wsR.Range("A" & outRow & ":K" & outRow)
        .Merge: .Value = "BAU SUMMARY -- filtered selection"
        .Interior.Color = CLR_GRAY_DARK: .Font.Color = CLR_WHITE
        .Font.Bold = True: .Font.Size = 11: .HorizontalAlignment = xlCenter
    End With
    outRow = outRow + 1

    Dim cFCR  As Long: cFCR  = ColIdx(wsB, "First contact resolution")
    Dim cMode As Long: cMode = ColIdx(wsB, "Mode")
    Dim cTR   As Long: cTR   = ColIdx(wsB, "Transfered")

    Dim total As Long: total = UBound(rows) + 1
    Dim fcr As Long, mail As Long, chat As Long, trans As Long
    Dim i As Long
    For i = 0 To UBound(rows)
        If UCase(Trim(CStr(wsB.Cells(rows(i), cFCR).Value)))  = "YES"  Then fcr   = fcr + 1
        If UCase(Trim(CStr(wsB.Cells(rows(i), cMode).Value))) = "MAIL" Then mail  = mail + 1 Else chat = chat + 1
        If UCase(Trim(CStr(wsB.Cells(rows(i), cTR).Value)))   = "YES"  Then trans = trans + 1
    Next i

    Dim stats(3, 1) As Variant
    stats(0, 0) = "Total Contacts":  stats(0, 1) = total
    stats(1, 0) = "FCR Rate":        stats(1, 1) = Format(fcr / total * 100, "0.0") & "%"
    stats(2, 0) = "Mail / Chat":     stats(2, 1) = mail & " / " & chat
    stats(3, 0) = "Transfer Rate":   stats(3, 1) = Format(trans / total * 100, "0.0") & "%"

    Dim si As Long
    For si = 0 To 3
        Dim col As Long: col = si * 2 + 1
        With wsR.Cells(outRow, col)
            .Value = stats(si, 0): .Interior.Color = CLR_ORANGE
            .Font.Color = CLR_WHITE: .Font.Bold = True: .Font.Size = 9
            .Borders.LineStyle = xlContinuous
        End With
        With wsR.Cells(outRow, col + 1)
            .Value = stats(si, 1): .Interior.Color = CLR_LIGHT_ORG
            .Font.Bold = True: .Font.Size = 10: .Borders.LineStyle = xlContinuous
        End With
    Next si
End Sub


Private Sub ClearOutput(wsR As Worksheet)
    Dim last As Long: last = wsR.Cells(wsR.Rows.Count, 1).End(xlUp).Row
    If last >= OUT_START Then wsR.Rows(OUT_START & ":" & last).Delete
End Sub


Private Function MergeUniq(ws1 As Object, col1 As String, last1 As Long, _
                             ws2 As Object, col2 As String, last2 As Long) As String
    Dim d As Object: Set d = CreateObject("Scripting.Dictionary")
    Dim i As Long, ci As Long, v As String
    If Not ws1 Is Nothing And last1 > 1 Then
        ci = ColIdx(ws1, col1)
        If ci > 0 Then
            For i = 2 To last1
                v = Trim(CStr(ws1.Cells(i, ci).Value))
                If Len(v) > 0 And v <> "nan" Then d(v) = 1
            Next i
        End If
    End If
    If Not ws2 Is Nothing And last2 > 1 Then
        ci = ColIdx(ws2, col2)
        If ci > 0 Then
            For i = 2 To last2
                v = Trim(CStr(ws2.Cells(i, ci).Value))
                If Len(v) > 0 And v <> "nan" Then d(v) = 1
            Next i
        End If
    End If
    Dim keys() As String: ReDim keys(d.Count - 1)
    Dim k As Long: k = 0
    Dim key As Variant
    For Each key In d.Keys: keys(k) = CStr(key): k = k + 1: Next key
    ' Sort
    Dim j As Long, tmp As String
    For i = 0 To UBound(keys) - 1
        For j = 0 To UBound(keys) - 1 - i
            If keys(j) > keys(j + 1) Then tmp = keys(j): keys(j) = keys(j + 1): keys(j + 1) = tmp
        Next j
    Next i
    MergeUniq = "All," & Join(keys, ",")
End Function


Private Sub RebuildDropdown(rng As Range, listStr As String)
    With rng.Validation
        .Delete
        If Len(listStr) > 0 Then
            .Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, _
                 Operator:=xlBetween, Formula1:="""" & listStr & """"
            .IgnoreBlank = True: .InCellDropdown = True
        End If
    End With
End Sub
