"""
THD OAM — Source Data Cleaner
Reads Productivity_Sheet.xlsx, cleans BAU and Transferred sheets,
writes cleaned data back to the same file.
A dated backup is created before any changes are made.
"""
import shutil
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime
from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# Resolve paths relative to this script so it works on any machine.
BASE    = Path(__file__).resolve().parent
SRC     = BASE / "Productivity_Sheet.xlsx"
BACKUP  = BASE / f"Productivity_Sheet_BACKUP_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"


# ─── Week inference from date ─────────────────────────────────────────────────
def infer_week_from_date(date_val, existing_week_map):
    """
    Return best week label for a given date, using the BAU week-date map
    as ground truth.  Falls back to the original value if no match.
    """
    if pd.isna(date_val):
        return None
    d = pd.Timestamp(date_val).normalize()
    best_label, best_dist = None, 999
    for (label, min_d, max_d) in existing_week_map:
        if min_d <= d <= max_d:
            return label
        dist = min(abs((d - min_d).days), abs((d - max_d).days))
        if dist < best_dist:
            best_dist, best_label = dist, label
    return best_label


def build_bau_week_map(df_bau):
    """Build list of (week_label, min_date, max_date) from BAU sheet."""
    df_bau["_date"] = pd.to_datetime(df_bau["Request Received Date"], errors="coerce")
    df_bau["_wnum"] = df_bau["Week"].astype(str).str.extract(r"(\d+)")[0].astype(float)
    df_bau["_fy"]   = df_bau["_date"].apply(lambda d: 2026 if pd.notna(d) and d.year >= 2026 else 2025)

    result = []
    for week_raw, grp in df_bau.groupby("Week"):
        dates = grp["_date"].dropna()
        if len(dates) == 0:
            continue
        fy    = int(grp["_fy"].iloc[0])
        wnum  = grp["_wnum"].iloc[0]
        label = f"FY{str(fy)[2:]} W{int(wnum):02d}" if not pd.isna(wnum) else week_raw
        result.append((week_raw, label, dates.min(), dates.max()))
    return result   # (raw_week, label, min_date, max_date)


# ─── Clean BAU ────────────────────────────────────────────────────────────────
def clean_bau(df):
    report = []

    # 1. Normalize Mode
    mode_fixes = df["Mode"].astype(str).str.strip().replace(
        {"Email": "Mail", "email": "Mail", "chat": "Chat", "mail": "Mail"})
    changed = (mode_fixes != df["Mode"].astype(str).str.strip()).sum()
    if changed:
        report.append(f"  Mode: normalized {changed} value(s) → 'Mail'/'Chat'")
    df["Mode"] = mode_fixes

    # 2. Normalize FCR
    fcr_orig = df["First contact resolution"].astype(str).str.strip()
    fcr_fixed = fcr_orig.str.capitalize()
    changed = (fcr_fixed != fcr_orig).sum()
    if changed:
        report.append(f"  FCR: fixed capitalization in {changed} row(s)")
    df["First contact resolution"] = fcr_fixed

    # 3. Normalize After-Hours
    ah = df["After-Hours"].astype(str).str.strip()
    ah_fixed = ah.replace({"Select": "No", "select": "No", "YES": "Yes", "NO": "No", "yes": "Yes", "no": "No"})
    changed = (ah_fixed != ah).sum()
    if changed:
        report.append(f"  After-Hours: normalized {changed} value(s)")
    df["After-Hours"] = ah_fixed

    # 4. Normalize Transferred flag
    tr = df["Transfered"].astype(str).str.strip()
    tr_fixed = tr.replace({"YES": "Yes", "NO": "No", "yes": "Yes", "no": "No"}).str.capitalize()
    changed = (tr_fixed != tr).sum()
    if changed:
        report.append(f"  Transfered: normalized {changed} value(s)")
    df["Transfered"] = tr_fixed

    # 5. Normalize Brand Name (strip whitespace, collapse spaces; preserve original case
    #    since data_processor uppercases on load)
    bn = df["Brand Name"].astype(str).str.strip().str.replace(r"\s+", " ", regex=True)
    bn = bn.replace({"nan": "", "NaN": "", "-": "",
                     "Multiple Brands": "(Multi-Brand Case)",
                     "MULTIPLE BRANDS": "(Multi-Brand Case)",
                     "multiple brands": "(Multi-Brand Case)"})
    changed = (bn != df["Brand Name"].astype(str)).sum()
    if changed:
        report.append(f"  Brand Name: cleaned {changed} value(s)")
    df["Brand Name"] = bn

    # 6. Strip whitespace from key text columns
    for col in ["Category", "Sub Category", "Analyst Name", "Work Flow Stage"]:
        if col in df.columns:
            df[col] = df[col].astype(str).str.strip().replace({"nan": "", "NaN": ""})

    # 7. Normalize Category
    cat_map = {
        "campaign setup guidance":        "Campaign Setup Guidance",
        "oa platform access/login issue": "OA Platform Access/Login Issues",
        "reporting/data requests":        "Reporting/Data Requests",
        "others":                         "Other",
    }
    df["Category"] = df["Category"].str.strip().replace(
        {k: v for k, v in cat_map.items()}, regex=False)

    return df, report


# ─── Clean Transferred ────────────────────────────────────────────────────────
def clean_transferred(df, bau_week_map):
    report = []

    # 1. Normalize Mode
    df["Mode"] = df["Mode"].astype(str).str.strip().replace(
        {"Email": "Mail", "email": "Mail", "chat": "Chat"})

    # 2. Normalize Status
    status = df["Status"].astype(str).str.strip()
    status_map = {
        "completed":                        "Completed",
        "COMPLETED":                        "Completed",
        "working":                          "Working",
        "WORKING":                          "Working",
        "waiting for supplier to reply":    "Waiting for Supplier to Reply",
        "kept supplier on hold":            "Kept Supplier on HOLD",
    }
    status_fixed = status.replace(status_map)
    changed = (status_fixed != status).sum()
    if changed:
        report.append(f"  Status: normalized {changed} value(s)")
    df["Status"] = status_fixed

    # 3. Normalize SLA
    sla = df["SLA"].astype(str).str.strip()
    sla_map = {
        "3-5 business": "3-5 Business Days",
        "3-5 Business Days": "3-5 Business Days",
        "48 hrs":  "48 hrs",
        "24 hrs":  "24 hrs",
        "24-48 hrs": "24-48 hrs",
        "-": "48 hrs",   # default SLA
        "nan": "48 hrs",
    }
    sla_fixed = sla.replace(sla_map)
    changed = (sla_fixed != sla).sum()
    if changed:
        report.append(f"  SLA: normalized {changed} value(s)")
    df["SLA"] = sla_fixed

    # 4. Fix Week mismatches using date as ground truth
    df["_date"] = pd.to_datetime(df.get("Request Received Date"), errors="coerce")
    df["_wnum_orig"] = df["Week"].astype(str).str.extract(r"(\d+)")[0].astype(float)
    df["_fy_orig"] = df["_date"].apply(lambda d: 2026 if pd.notna(d) and d.year >= 2026 else 2025)
    df["_correct_fy"] = df["_date"].apply(lambda d: 2026 if pd.notna(d) and d.year >= 2026 else 2025)

    # Build date→week lookup from BAU
    date_to_week = {}
    for (raw_week, label, min_d, max_d) in bau_week_map:
        cur = min_d
        while cur <= max_d:
            date_to_week[cur] = raw_week
            cur += pd.Timedelta(days=1)

    fixes = 0
    for idx, row in df.iterrows():
        d = row["_date"]
        if pd.isna(d):
            continue
        d_norm = pd.Timestamp(d).normalize()
        correct_week = date_to_week.get(d_norm)
        if correct_week and correct_week != row["Week"]:
            old_wk = row["Week"]
            df.at[idx, "Week"] = correct_week
            report.append(f"  Row {idx}: Week '{old_wk}' -> '{correct_week}' "
                          f"(date: {d_norm.strftime('%Y-%m-%d')})")
            fixes += 1

    if fixes:
        report.append(f"  Total week fixes in Transferred: {fixes} row(s)")

    # 5. Normalize Brand Name
    bn = df["Brand Name"].astype(str).str.strip().str.replace(r"\s+", " ", regex=True)
    bn = bn.replace({"nan": "", "NaN": "", "-": "",
                     "Multiple Brands": "(Multi-Brand Case)",
                     "MULTIPLE BRANDS": "(Multi-Brand Case)",
                     "multiple brands": "(Multi-Brand Case)"})
    df["Brand Name"] = bn

    # 6. Strip whitespace from text columns
    for col in ["Category", "Sub Category", "Analyst Name", "Next Step",
                "Recent Update / Follow up", "Work Flow Stage"]:
        if col in df.columns:
            df[col] = df[col].astype(str).str.strip().replace({"nan": "", "NaN": ""})

    # Drop temp columns
    df.drop(columns=["_date", "_wnum_orig", "_fy_orig", "_correct_fy"], errors="ignore", inplace=True)

    return df, report


# ─── Write cleaned data back to Excel (preserve other sheets) ────────────────
def write_sheet_back(wb, sheet_name, df_clean, original_df_cols):
    """Overwrite sheet_name in wb with df_clean, preserving original column order."""
    ws = wb[sheet_name]

    # Read existing header row to get column order
    header = [ws.cell(row=1, column=c).value for c in range(1, ws.max_column + 1)]
    header = [h for h in header if h is not None]

    # Map df columns to header positions
    col_map = {h: i + 1 for i, h in enumerate(header)}

    # Write data rows (start at row 2, preserve row 1 header)
    for ri, (_, row) in enumerate(df_clean.iterrows(), 2):
        for col_name in header:
            ci = col_map.get(col_name)
            if ci is None:
                continue
            # Only overwrite columns we actually touched
            if col_name in df_clean.columns:
                v = row.get(col_name)
                if isinstance(v, float) and np.isnan(v):
                    v = None
                elif isinstance(v, bool):
                    v = "Yes" if v else "No"
                elif isinstance(v, pd.Timestamp):
                    v = v.to_pydatetime()
                ws.cell(row=ri, column=ci).value = v


# ─── Main ─────────────────────────────────────────────────────────────────────
def main():
    print(f"Backing up: {BACKUP.name}")
    shutil.copy2(SRC, BACKUP)
    print("Backup created.")

    # Load for analysis
    df_bau = pd.read_excel(SRC, sheet_name="BAU")
    df_bau.columns = [c.strip() for c in df_bau.columns]
    df_tr  = pd.read_excel(SRC, sheet_name="Transferred")
    df_tr.columns  = [c.strip() for c in df_tr.columns]

    # Build week map from BAU (authoritative)
    bau_week_map = build_bau_week_map(df_bau.copy())

    print("\nCleaning BAU sheet …")
    df_bau_clean, bau_report = clean_bau(df_bau.copy())
    for r in bau_report:
        print(r)
    if not bau_report:
        print("  No issues found in BAU.")

    print("\nCleaning Transferred sheet …")
    df_tr_clean, tr_report = clean_transferred(df_tr.copy(), bau_week_map)
    for r in tr_report:
        print(r)
    if not tr_report:
        print("  No issues found in Transferred.")

    print("\nWriting cleaned data back to Excel …")
    wb = load_workbook(SRC)

    # Only overwrite the columns we changed (don't touch formulas, formatting, etc.)
    bau_cols_changed = ["Mode", "First contact resolution", "After-Hours",
                        "Transfered", "Brand Name", "Category", "Sub Category",
                        "Analyst Name", "Work Flow Stage"]
    tr_cols_changed  = ["Mode", "Status", "SLA", "Week", "Brand Name",
                        "Category", "Sub Category", "Analyst Name",
                        "Next Step", "Recent Update / Follow up", "Work Flow Stage"]

    write_sheet_back(wb, "BAU",         df_bau_clean, bau_cols_changed)
    write_sheet_back(wb, "Transferred", df_tr_clean,  tr_cols_changed)

    wb.save(SRC)
    print(f"\nCleaned file saved: {SRC.name}")
    print("Done.")


if __name__ == "__main__":
    main()
