@echo off
cd /d "%~dp0"
echo.
echo =====================================================
echo  THD OAM Analytics Portal
echo  Open browser at: http://localhost:5000
echo =====================================================
echo.
python app.py
pause
