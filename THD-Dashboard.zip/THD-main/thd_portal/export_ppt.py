"""
THD OAM Analytics Portal — PowerPoint Export
Generates a fully formatted, self-explanatory THD-themed presentation.
Uses native pptx tables for alignment and embedded matplotlib charts.
"""
import io
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
from datetime import date

from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.oxml.ns import qn
from lxml import etree

# ── THD Colour Palette ────────────────────────────────────────────────────────
C_ORANGE = RGBColor(0xF9, 0x63, 0x02)
C_DARK   = RGBColor(0xCC, 0x4E, 0x00)
C_BLACK  = RGBColor(0x1A, 0x1A, 0x1A)
C_WHITE  = RGBColor(0xFF, 0xFF, 0xFF)
C_LGRAY  = RGBColor(0xF5, 0xF5, 0xF5)
C_GRAY   = RGBColor(0xCC, 0xCC, 0xCC)
C_GREEN  = RGBColor(0x2E, 0x7D, 0x32)
C_RED    = RGBColor(0xC6, 0x28, 0x28)
C_AMBER  = RGBColor(0xE6, 0x5C, 0x00)
C_LBLUE  = RGBColor(0xE3, 0xF2, 0xFD)

SLIDE_W = Inches(13.33)
SLIDE_H = Inches(7.5)


# ── Low-level helpers ─────────────────────────────────────────────────────────

def _rect(slide, l, t, w, h, fill_rgb=None):
    from pptx.util import Emu
    shape = slide.shapes.add_shape(1, l, t, w, h)
    shape.line.fill.background()
    if fill_rgb:
        shape.fill.solid()
        shape.fill.fore_color.rgb = fill_rgb
    else:
        shape.fill.background()
    return shape


def _txb(slide, text, l, t, w, h, size=Pt(10), bold=False,
         color=C_BLACK, align=PP_ALIGN.LEFT, italic=False):
    txb = slide.shapes.add_textbox(l, t, w, h)
    txb.word_wrap = True
    tf = txb.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.alignment = align
    run = p.add_run()
    run.text = str(text)
    run.font.size = size
    run.font.bold = bold
    run.font.italic = italic
    run.font.color.rgb = color
    return txb


def _add_para(txb, text, size=Pt(9), bold=False, color=C_BLACK,
              align=PP_ALIGN.LEFT, space_before=Pt(3)):
    tf = txb.text_frame
    p = tf.add_paragraph()
    p.alignment = align
    p.space_before = space_before
    run = p.add_run()
    run.text = str(text)
    run.font.size = size
    run.font.bold = bold
    run.font.color.rgb = color
    return p


def _header(slide, title, subtitle=""):
    _rect(slide, 0, 0, SLIDE_W, Inches(1.05), C_ORANGE)
    _txb(slide, title, Inches(0.3), Inches(0.08), Inches(12.5), Inches(0.55),
         size=Pt(22), bold=True, color=C_WHITE, align=PP_ALIGN.LEFT)
    if subtitle:
        _txb(slide, subtitle, Inches(0.3), Inches(0.62), Inches(12.5), Inches(0.38),
             size=Pt(11), color=C_WHITE, align=PP_ALIGN.LEFT)


def _footer(slide, label):
    _rect(slide, 0, Inches(7.18), SLIDE_W, Inches(0.32), C_BLACK)
    _txb(slide, f"THD OAM Analytics  |  {label}  |  Confidential — iOPEX Technologies",
         Inches(0.3), Inches(7.20), Inches(12.5), Inches(0.26),
         size=Pt(7.5), color=C_WHITE, align=PP_ALIGN.LEFT)
    _txb(slide, f"{date.today():%d %b %Y}",
         Inches(11.5), Inches(7.20), Inches(1.5), Inches(0.26),
         size=Pt(7.5), color=C_GRAY, align=PP_ALIGN.RIGHT)


def _note_box(slide, text, l, t, w, h, bg=C_LGRAY, fg=C_BLACK, size=Pt(8.5)):
    _rect(slide, l, t, w, h, bg)
    _txb(slide, text, l + Inches(0.12), t + Inches(0.08),
         w - Inches(0.24), h - Inches(0.16),
         size=size, color=fg, align=PP_ALIGN.LEFT)


def _kpi_card(slide, label, value, sub, l, t, w=Inches(2.3), h=Inches(1.3),
              bg=C_ORANGE):
    _rect(slide, l, t, w, h, bg)
    # label
    _txb(slide, label, l + Inches(0.1), t + Inches(0.07),
         w - Inches(0.2), Inches(0.32),
         size=Pt(8.5), color=C_WHITE, align=PP_ALIGN.CENTER, bold=False)
    # value
    _txb(slide, str(value), l + Inches(0.1), t + Inches(0.35),
         w - Inches(0.2), Inches(0.60),
         size=Pt(24), bold=True, color=C_WHITE, align=PP_ALIGN.CENTER)
    # sub-label
    if sub:
        _txb(slide, str(sub), l + Inches(0.1), t + Inches(0.95),
             w - Inches(0.2), Inches(0.28),
             size=Pt(7.5), color=C_WHITE, align=PP_ALIGN.CENTER, italic=True)


# ── Native PPTX table ─────────────────────────────────────────────────────────

def _table(slide, headers, rows, l, t, w, h,
           hdr_bg=C_ORANGE, alt_bg=C_LGRAY,
           col_widths=None, hdr_size=Pt(8.5), cell_size=Pt(8),
           col_aligns=None):
    if not rows:
        return
    n_rows = len(rows) + 1
    n_cols = len(headers)
    tbl_shape = slide.shapes.add_table(n_rows, n_cols, l, t, w, h)
    tbl = tbl_shape.table

    if col_widths:
        total = sum(col_widths)
        scale = w / total
        for i, cw in enumerate(col_widths):
            tbl.columns[i].width = int(cw * scale)

    row_h = int(h / n_rows)
    for r in range(n_rows):
        tbl.rows[r].height = row_h

    def _style_cell(cell, text, fg, bg, bold=False, size=Pt(8.5),
                    h_align=PP_ALIGN.CENTER, v_center=True):
        cell.text = str(text) if text is not None else ""
        cell.fill.solid()
        cell.fill.fore_color.rgb = bg
        # Vertical centring + tight, symmetric margins so columns line up cleanly.
        cell.vertical_anchor = MSO_ANCHOR.MIDDLE
        cell.margin_left   = Pt(4)
        cell.margin_right  = Pt(4)
        cell.margin_top    = Pt(1)
        cell.margin_bottom = Pt(1)
        tf = cell.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        p.alignment = h_align
        if p.runs:
            run = p.runs[0]
        else:
            run = p.add_run()
            run.text = str(text) if text is not None else ""
        run.font.bold = bold
        run.font.size = size
        run.font.color.rgb = fg

    default_aligns = col_aligns or ([PP_ALIGN.LEFT] + [PP_ALIGN.CENTER] * (n_cols - 1))

    for ci, hd in enumerate(headers):
        _style_cell(tbl.cell(0, ci), hd, C_WHITE, hdr_bg,
                    bold=True, size=hdr_size, h_align=PP_ALIGN.CENTER)

    for ri, row in enumerate(rows):
        bg = alt_bg if ri % 2 == 0 else C_WHITE
        for ci, val in enumerate(row):
            ha = default_aligns[ci] if ci < len(default_aligns) else PP_ALIGN.CENTER
            _style_cell(tbl.cell(ri + 1, ci), val, C_BLACK, bg,
                        size=cell_size, h_align=ha)

    return tbl


# ── Chart helpers ─────────────────────────────────────────────────────────────

def _chart_to_buf(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format='png', dpi=150, bbox_inches='tight',
                facecolor=fig.get_facecolor())
    buf.seek(0)
    plt.close(fig)
    return buf


def _bar_chart(labels, mail_vals, chat_vals, title="Weekly Volume"):
    fig, ax = plt.subplots(figsize=(6.5, 2.8))
    fig.patch.set_facecolor('#FAFAFA')
    ax.set_facecolor('#FAFAFA')
    x = np.arange(len(labels))
    b1 = ax.bar(x - 0.2, mail_vals, 0.38, label='Mail', color='#F96302', alpha=0.9)
    b2 = ax.bar(x + 0.2, chat_vals, 0.38, label='Chat', color='#CC4E00', alpha=0.9)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=30, fontsize=7, ha='right')
    ax.tick_params(axis='y', labelsize=7)
    ax.set_title(title, fontsize=9, color='#1A1A1A', pad=4)
    ax.legend(fontsize=7.5, framealpha=0.7)
    ax.spines[['top', 'right']].set_visible(False)
    ax.yaxis.grid(True, alpha=0.3)
    ax.set_axisbelow(True)
    fig.tight_layout(pad=0.5)
    return _chart_to_buf(fig)


def _line_chart(labels, series_dict, benchmarks=None, title="Trend"):
    colours = ['#F96302', '#CC4E00', '#2E7D32', '#C62828', '#1565C0']
    fig, ax = plt.subplots(figsize=(6.5, 2.8))
    fig.patch.set_facecolor('#FAFAFA')
    ax.set_facecolor('#FAFAFA')
    x = np.arange(len(labels))
    for i, (name, vals) in enumerate(series_dict.items()):
        ax.plot(x, vals, '-o', color=colours[i % len(colours)],
                linewidth=1.8, markersize=4, label=name)
    if benchmarks:
        for bname, bval, bcol in benchmarks:
            ax.axhline(bval, color=bcol, linestyle='--', linewidth=1, alpha=0.6, label=bname)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=30, fontsize=7, ha='right')
    ax.tick_params(axis='y', labelsize=7)
    ax.set_title(title, fontsize=9, color='#1A1A1A', pad=4)
    ax.legend(fontsize=7, framealpha=0.7, ncol=2)
    ax.spines[['top', 'right']].set_visible(False)
    ax.yaxis.grid(True, alpha=0.3)
    ax.set_axisbelow(True)
    fig.tight_layout(pad=0.5)
    return _chart_to_buf(fig)


def _hbar_chart(labels, vals, title="", color='#F96302'):
    fig, ax = plt.subplots(figsize=(4.5, max(2.5, len(labels) * 0.35)))
    fig.patch.set_facecolor('#FAFAFA')
    ax.set_facecolor('#FAFAFA')
    y = np.arange(len(labels))
    bars = ax.barh(y, vals, color=color, alpha=0.85)
    ax.set_yticks(y)
    ax.set_yticklabels(labels, fontsize=7.5)
    ax.tick_params(axis='x', labelsize=7)
    ax.set_title(title, fontsize=9, color='#1A1A1A', pad=4)
    ax.spines[['top', 'right']].set_visible(False)
    ax.xaxis.grid(True, alpha=0.3)
    ax.set_axisbelow(True)
    for bar, v in zip(bars, vals):
        ax.text(bar.get_width() + max(vals) * 0.01, bar.get_y() + bar.get_height() / 2,
                str(int(v)), va='center', fontsize=7)
    fig.tight_layout(pad=0.5)
    return _chart_to_buf(fig)


def _donut_chart(labels, vals, colours, title=""):
    fig, ax = plt.subplots(figsize=(3.2, 2.8))
    fig.patch.set_facecolor('#FAFAFA')
    wedges, texts, autos = ax.pie(vals, labels=None, colors=colours,
                                  autopct='%1.0f%%', startangle=90,
                                  wedgeprops={'width': 0.55},
                                  textprops={'fontsize': 8})
    ax.legend(wedges, labels, loc='lower center', fontsize=7.5,
              ncol=len(labels), bbox_to_anchor=(0.5, -0.08), framealpha=0.6)
    ax.set_title(title, fontsize=9, color='#1A1A1A', pad=6)
    fig.tight_layout(pad=0.4)
    return _chart_to_buf(fig)


# ── Slide 1 — Cover ───────────────────────────────────────────────────────────

def _slide_cover(prs, snap, ytd):
    sl = prs.slides.add_slide(prs.slide_layouts[6])
    _rect(sl, 0, 0, SLIDE_W, SLIDE_H, C_BLACK)
    _rect(sl, 0, 0, Inches(0.55), SLIDE_H, C_ORANGE)
    _rect(sl, Inches(0.55), 0, SLIDE_W - Inches(0.55), SLIDE_H, C_WHITE)

    wk = snap.get("week_label", "Latest")
    fy = snap.get("fiscal_year", "")

    _txb(sl, "THE HOME DEPOT", Inches(1.1), Inches(0.9), Inches(11), Inches(0.5),
         size=Pt(13), bold=True, color=C_ORANGE)
    _txb(sl, "OAM Supplier Support", Inches(1.1), Inches(1.4), Inches(11), Inches(0.8),
         size=Pt(34), bold=True, color=C_BLACK)
    _txb(sl, "Analytics Report Card", Inches(1.1), Inches(2.1), Inches(11), Inches(0.8),
         size=Pt(34), bold=True, color=C_DARK)
    _rect(sl, Inches(1.1), Inches(3.0), Inches(5.5), Inches(0.06), C_ORANGE)
    _txb(sl, f"{fy}  |  {wk}", Inches(1.1), Inches(3.1), Inches(11), Inches(0.5),
         size=Pt(18), color=C_DARK)
    _txb(sl, "Prepared by: iOPEX Technologies", Inches(1.1), Inches(3.75),
         Inches(11), Inches(0.4), size=Pt(11), color=C_BLACK)
    _txb(sl, f"Report Date: {date.today():%B %d, %Y}", Inches(1.1), Inches(4.15),
         Inches(11), Inches(0.4), size=Pt(11), color=C_BLACK)

    # YTD highlight strip
    if ytd:
        _rect(sl, Inches(1.1), Inches(4.85), Inches(11.5), Inches(1.55), C_LGRAY)
        _txb(sl, "YEAR-TO-DATE SNAPSHOT", Inches(1.2), Inches(4.95),
             Inches(11), Inches(0.32), size=Pt(9), bold=True, color=C_ORANGE)
        items = [
            ("Total Volume", f"{ytd.get('total_volume', 0):,}"),
            ("FCR Rate",     f"{ytd.get('fcr_pct', 0)}%"),
            ("Transfer Rate",f"{ytd.get('transfer_rate_pct', 0)}%"),
            ("After-Hours",  f"{ytd.get('after_hours_pct', 0)}%"),
            ("Weeks Covered",str(ytd.get('weeks_count', 0))),
        ]
        for i, (lbl, val) in enumerate(items):
            x = Inches(1.2 + i * 2.28)
            _txb(sl, lbl, x, Inches(5.3), Inches(2.1), Inches(0.28),
                 size=Pt(8), color=C_BLACK, align=PP_ALIGN.CENTER)
            _txb(sl, val, x, Inches(5.58), Inches(2.1), Inches(0.5),
                 size=Pt(18), bold=True, color=C_ORANGE, align=PP_ALIGN.CENTER)

    # Slide index
    _txb(sl, "Contents: Executive Summary  ·  Brand Analysis  ·  Channel Performance  ·  "
             "Transferred Requests  ·  Business Value KPIs  ·  Analyst Performance",
         Inches(1.1), Inches(6.75), Inches(11.5), Inches(0.4),
         size=Pt(8), color=C_GRAY, align=PP_ALIGN.LEFT)


# ── Slide 2 — Executive Summary ───────────────────────────────────────────────

def _slide_exec(prs, snap, ytd, benchmarks):
    sl = prs.slides.add_slide(prs.slide_layouts[6])
    _rect(sl, 0, 0, SLIDE_W, SLIDE_H, C_WHITE)
    _header(sl, "Executive Summary",
            f"{snap.get('week_label','Latest')}  —  Current Week KPI Snapshot")
    _footer(sl, snap.get("week_label", ""))

    def _fmt(v, fmt=".1f", suffix=""):
        if v is None: return "—"
        try: return f"{v:{fmt}}{suffix}"
        except: return str(v)

    # Row 1 — Volume cards
    vol_cards = [
        ("Total Volume",   f"{snap.get('total_volume', 0):,}",  "contacts this week",   C_ORANGE),
        ("Mail Contacts",  f"{snap.get('mail_volume', 0):,}",   "OAM inbox emails",     C_DARK),
        ("Chat Contacts",  f"{snap.get('chat_volume', 0):,}",   "live chat sessions",   C_DARK),
        ("FCR Rate",       _fmt(snap.get('fcr_pct'), ".1f", "%"),
         f"Benchmark ≥ {benchmarks.get('fcr_pct', 80)}%",       C_GREEN),
        ("Transfer Rate",  _fmt(snap.get('transfer_rate_pct'), ".1f", "%"),
         f"Benchmark ≤ {benchmarks.get('escalation_rate_pct', 5)}%", C_RED),
    ]
    cw, ch, gap, sx, ry1 = Inches(2.38), Inches(1.28), Inches(0.18), Inches(0.3), Inches(1.15)
    for i, (lbl, val, sub, bg) in enumerate(vol_cards):
        _kpi_card(sl, lbl, val, sub, sx + i * (cw + gap), ry1, cw, ch, bg)

    # Row 2 — Timing cards
    timing_cards = [
        ("After-Hours %",  _fmt(snap.get('after_hours_pct'), ".1f", "%"),
         "contacts after 6 pm",                                  C_DARK),
        ("AHT — Mail",     _fmt(snap.get('aht_mail'), ".1f", " min"),
         f"Benchmark ≤ {benchmarks.get('aht_min', 30)} min",    C_ORANGE),
        ("AHT — Chat",     _fmt(snap.get('aht_chat'), ".1f", " min"),
         f"Benchmark ≤ {benchmarks.get('aht_min', 30)} min",    C_DARK),
        ("FRT — Mail",     _fmt(snap.get('frt_mail'), ".1f", " min"),
         f"Benchmark ≤ {benchmarks.get('mail_frt_min', 60)} min", C_ORANGE),
        ("FRT — Chat",     _fmt(snap.get('frt_chat'), ".1f", " min"),
         f"Benchmark ≤ {benchmarks.get('chat_frt_min', 1)} min", C_GREEN),
    ]
    ry2 = Inches(2.58)
    for i, (lbl, val, sub, bg) in enumerate(timing_cards):
        _kpi_card(sl, lbl, val, sub, sx + i * (cw + gap), ry2, cw, ch, bg)

    # KPI definitions note
    _note_box(sl,
        "FCR (First Contact Resolution): % of contacts resolved without a callback or follow-up. "
        "AHT (Average Handling Time): Average time from contact start to close. "
        "FRT (First Response Time): Time taken to send the first reply after contact received. "
        "Transfer Rate: % of contacts escalated out-of-scope.",
        Inches(0.3), Inches(3.98), Inches(8.5), Inches(0.72),
        bg=C_LGRAY, fg=RGBColor(0x55, 0x55, 0x55))

    # YTD strip
    if ytd:
        _rect(sl, Inches(0.3), Inches(4.82), Inches(12.7), Inches(0.66), RGBColor(0xFF, 0xF3, 0xEB))
        ytd_txt = (f"YTD ({ytd.get('fiscal_year', '')}  ·  {ytd.get('weeks_count', 0)} weeks)     "
                   f"Total Volume: {ytd.get('total_volume', 0):,}     "
                   f"FCR: {ytd.get('fcr_pct', 0)}%     "
                   f"Transfer Rate: {ytd.get('transfer_rate_pct', 0)}%     "
                   f"After-Hours: {ytd.get('after_hours_pct', 0)}%     "
                   f"AHT Mail: {ytd.get('avg_aht_mail', 0)} min     "
                   f"FRT Chat: {ytd.get('avg_frt_chat', 0)} min")
        _txb(sl, "YEAR-TO-DATE", Inches(0.45), Inches(4.88), Inches(1.5), Inches(0.24),
             size=Pt(7.5), bold=True, color=C_ORANGE)
        _txb(sl, ytd_txt, Inches(0.45), Inches(5.1), Inches(12.3), Inches(0.28),
             size=Pt(8.5), color=C_BLACK, align=PP_ALIGN.LEFT)

    # Benchmark table
    _txb(sl, "BENCHMARK REFERENCE", Inches(9.1), Inches(3.98), Inches(3.9), Inches(0.28),
         size=Pt(8.5), bold=True, color=C_ORANGE)
    bm_rows = [
        ["Chat FRT",    f"≤ {benchmarks.get('chat_frt_min', 1)} min"],
        ["Mail FRT",    f"≤ {benchmarks.get('mail_frt_min', 60)} min"],
        ["AHT",         f"≤ {benchmarks.get('aht_min', 30)} min"],
        ["FCR",         f"≥ {benchmarks.get('fcr_pct', 80)}%"],
        ["Escalation",  f"≤ {benchmarks.get('escalation_rate_pct', 5)}%"],
    ]
    _table(sl, ["KPI", "Target"], bm_rows,
           Inches(9.1), Inches(4.28), Inches(3.9), Inches(1.3),
           hdr_bg=C_DARK, col_widths=[2, 1.5],
           col_aligns=[PP_ALIGN.LEFT, PP_ALIGN.CENTER])

    # Insight note
    fcr = snap.get('fcr_pct', 0) or 0
    tr  = snap.get('transfer_rate_pct', 0) or 0
    insight = []
    if fcr >= 80:
        insight.append(f"FCR at {fcr:.1f}% — meeting the ≥80% benchmark.")
    else:
        insight.append(f"FCR at {fcr:.1f}% — below the ≥80% benchmark, review unresolved cases.")
    if tr <= 5:
        insight.append(f"Transfer rate {tr:.1f}% — within the ≤5% target.")
    else:
        insight.append(f"Transfer rate {tr:.1f}% — above the ≤5% target, escalation review recommended.")
    _note_box(sl, "  ".join(insight),
              Inches(0.3), Inches(5.6), Inches(8.5), Inches(0.52),
              bg=RGBColor(0xFF, 0xF3, 0xEB), fg=C_BLACK)


# ── Slide 3 — Brand Analysis ──────────────────────────────────────────────────

def _slide_brands(prs, snap, brand_analysis):
    sl = prs.slides.add_slide(prs.slide_layouts[6])
    _rect(sl, 0, 0, SLIDE_W, SLIDE_H, C_WHITE)
    _header(sl, "Brand Issue Analysis",
            "Identifies which brands report new vs repeated issues — drives targeted root-cause action")
    _footer(sl, snap.get("week_label", ""))

    summary = brand_analysis.get("summary", {})
    total = summary.get("total_issues", 0)
    new_p = summary.get("new_pct", 0) or 0
    rep_p = summary.get("repeated_pct", 0) or 0
    new_n = summary.get("new_issues", 0)
    rep_n = summary.get("repeated_issues", 0)

    _kpi_card(sl, "Total Issues",    str(total), "all brands combined",
              Inches(0.3), Inches(1.15), Inches(2.2), Inches(1.15))
    _kpi_card(sl, "New Issues",      f"{new_p:.1f}%", f"{new_n} brand-category combos",
              Inches(2.65), Inches(1.15), Inches(2.2), Inches(1.15), C_GREEN)
    _kpi_card(sl, "Repeated Issues", f"{rep_p:.1f}%", f"{rep_n} recurring patterns",
              Inches(5.0),  Inches(1.15), Inches(2.2), Inches(1.15), C_RED)

    # What this means note
    _note_box(sl,
        "New Issue: first time this Brand + Category combination is seen in the reporting period.  "
        "Repeated Issue: same Brand + Category appeared in a prior week, indicating an unresolved "
        "root cause. High repetition rates signal opportunities for proactive supplier coaching.",
        Inches(7.4), Inches(1.15), Inches(5.6), Inches(1.15),
        bg=C_LGRAY)

    # Brand table (left side)
    brands = brand_analysis.get("brands", [])[:14]
    if brands:
        hdrs = ["Brand", "Total", "New", "Repeat", "Repeat%", "Top Category"]
        rows = [[
            b.get("Brand Name", ""),
            b.get("Total_Issues", b.get("Total", 0)),
            b.get("New_Issues",   b.get("New", 0)),
            b.get("Repeated_Issues", b.get("Repeated", 0)),
            f"{b.get('Repeated_Pct', 0):.1f}%",
            str(b.get("Top_Category", ""))[:22],
        ] for b in brands]
        _table(sl, hdrs, rows,
               Inches(0.3), Inches(2.48), Inches(8.6), Inches(4.7),
               hdr_bg=C_ORANGE,
               col_widths=[3.0, 1.0, 1.0, 1.0, 1.1, 2.8],
               col_aligns=[PP_ALIGN.LEFT, PP_ALIGN.CENTER, PP_ALIGN.CENTER,
                           PP_ALIGN.CENTER, PP_ALIGN.CENTER, PP_ALIGN.LEFT])

    # Donut chart (right side)
    if total > 0:
        buf = _donut_chart(
            ["New", "Repeated"],
            [new_n or 1, rep_n or 1],
            ['#2E7D32', '#C62828'],
            title="New vs Repeated")
        sl.shapes.add_picture(buf, Inches(9.1), Inches(2.48), Inches(3.9), Inches(2.5))

    # Top repeated categories
    cats = brand_analysis.get("categories", [])[:6]
    if cats:
        cat_hdrs = ["Category", "Brand", "Repeated"]
        cat_rows = [[c.get("Category", ""), c.get("Brand Name", ""), c.get("Repeated", 0)]
                    for c in cats]
        _txb(sl, "TOP REPEATED CATEGORIES", Inches(9.1), Inches(5.1),
             Inches(3.9), Inches(0.3), size=Pt(8.5), bold=True, color=C_ORANGE)
        _table(sl, cat_hdrs, cat_rows,
               Inches(9.1), Inches(5.42), Inches(3.9), Inches(1.7),
               hdr_bg=C_DARK,
               col_widths=[2.2, 1.5, 0.9],
               col_aligns=[PP_ALIGN.LEFT, PP_ALIGN.LEFT, PP_ALIGN.CENTER])


# ── Slide 4 — Channel Performance ─────────────────────────────────────────────

def _slide_channels(prs, snap, weekly_kpis, benchmarks):
    sl = prs.slides.add_slide(prs.slide_layouts[6])
    _rect(sl, 0, 0, SLIDE_W, SLIDE_H, C_WHITE)
    _header(sl, "Channel Performance — Mail vs Chat",
            "Week-over-week volume, speed, and quality metrics across both support channels")
    _footer(sl, snap.get("week_label", ""))

    recent = weekly_kpis[-10:] if len(weekly_kpis) >= 10 else weekly_kpis

    # Volume bar chart
    if recent:
        labels = [w.get("Week_Label", "") for w in recent]
        mail_v = [w.get("Mail_Volume", 0) or 0 for w in recent]
        chat_v = [w.get("Chat_Volume", 0) or 0 for w in recent]
        buf = _bar_chart(labels, mail_v, chat_v, "Weekly Volume — Mail vs Chat")
        sl.shapes.add_picture(buf, Inches(0.3), Inches(1.15), Inches(6.3), Inches(3.0))

    # FRT trend line chart
    if recent:
        frt_mail = [w.get("Avg_FRT_Mail_min", 0) or 0 for w in recent]
        frt_chat = [w.get("Avg_FRT_Chat_min", 0) or 0 for w in recent]
        buf2 = _line_chart(
            labels,
            {"FRT Mail (min)": frt_mail, "FRT Chat (min)": frt_chat},
            benchmarks=[
                (f"Mail BM {benchmarks.get('mail_frt_min', 60)}m",
                 benchmarks.get('mail_frt_min', 60), '#CC4E00'),
                (f"Chat BM {benchmarks.get('chat_frt_min', 1)}m",
                 benchmarks.get('chat_frt_min', 1), '#2E7D32'),
            ],
            title="First Response Time Trend")
        sl.shapes.add_picture(buf2, Inches(6.8), Inches(1.15), Inches(6.2), Inches(3.0))

    # Weekly detail table
    if recent:
        hdrs = ["Week", "Mail", "Chat", "FCR%", "AHT Mail", "AHT Chat",
                "FRT Mail", "FRT Chat", "Transfer%"]
        rows = [[
            w.get("Week_Label", ""),
            w.get("Mail_Volume", 0),
            w.get("Chat_Volume", 0),
            f"{w.get('FCR_Pct', 0) or 0:.1f}%",
            f"{w.get('Avg_AHT_Mail_min', 0) or 0:.1f}m",
            f"{w.get('Avg_AHT_Chat_min', 0) or 0:.1f}m",
            f"{w.get('Avg_FRT_Mail_min', 0) or 0:.1f}m",
            f"{w.get('Avg_FRT_Chat_min', 0) or 0:.1f}m",
            f"{w.get('Transfer_Rate_Pct', 0) or 0:.1f}%",
        ] for w in recent]
        _table(sl, hdrs, rows,
               Inches(0.3), Inches(4.28), Inches(12.7), Inches(2.85),
               hdr_bg=C_ORANGE,
               col_widths=[1.8, 0.9, 0.9, 0.9, 1.15, 1.15, 1.15, 1.15, 1.15],
               col_aligns=[PP_ALIGN.LEFT] + [PP_ALIGN.CENTER] * 8)

    # Benchmark footnote
    bm_txt = (f"Benchmarks:  Chat FRT ≤ {benchmarks.get('chat_frt_min',1)} min  |  "
              f"Mail FRT ≤ {benchmarks.get('mail_frt_min',60)} min  |  "
              f"AHT ≤ {benchmarks.get('aht_min',30)} min  |  "
              f"FCR ≥ {benchmarks.get('fcr_pct',80)}%  |  "
              f"Escalation ≤ {benchmarks.get('escalation_rate_pct',5)}%")
    _txb(sl, bm_txt, Inches(0.3), Inches(7.08), Inches(12.7), Inches(0.22),
         size=Pt(7.5), color=C_DARK, align=PP_ALIGN.CENTER, italic=True)


# ── Slide 5 — Transferred Requests ───────────────────────────────────────────

def _slide_transferred(prs, snap, transferred):
    sl = prs.slides.add_slide(prs.slide_layouts[6])
    _rect(sl, 0, 0, SLIDE_W, SLIDE_H, C_WHITE)
    _header(sl, "Transferred Request Tracker",
            "Out-of-scope cases handed to specialist teams — tracking resolution & SLA compliance")
    _footer(sl, snap.get("week_label", ""))

    summary = transferred.get("summary", {})
    total    = summary.get("total", 0) or 0
    done     = summary.get("completed", 0) or 0
    open_n   = summary.get("open", 0) or 0
    comp_pct = summary.get("completion_pct", 0) or 0
    avg_res  = summary.get("avg_res_hrs", 0) or 0

    cw, ch = Inches(2.3), Inches(1.2)
    gap, sx = Inches(0.22), Inches(0.3)
    _kpi_card(sl, "Total Transferred", str(total),    "all-time",         sx,              Inches(1.15), cw, ch)
    _kpi_card(sl, "Completed",         str(done),     "cases closed",     sx + cw + gap,   Inches(1.15), cw, ch, C_GREEN)
    _kpi_card(sl, "Open / Pending",    str(open_n),   "awaiting closure", sx + 2*(cw+gap), Inches(1.15), cw, ch, C_RED)
    _kpi_card(sl, "Completion Rate",   f"{comp_pct:.1f}%", "target ≥ 80%",sx + 3*(cw+gap), Inches(1.15), cw, ch,
              C_GREEN if comp_pct >= 80 else C_RED)
    _kpi_card(sl, "Avg Resolution",    f"{avg_res:.1f}h", "hours to close",sx + 4*(cw+gap), Inches(1.15), cw, ch, C_DARK)

    # What transferred means — full-width explanatory strip below the KPI cards
    _note_box(sl,
        "Transferred requests are contacts that fall outside the OAM team's scope and are "
        "handed to specialist teams (e.g., Legal, Compliance, Tech). The team tracks these "
        "to ensure they are resolved within SLA and provides follow-up updates to the supplier.",
        Inches(0.3), Inches(2.45), Inches(12.73), Inches(0.5),
        bg=C_LGRAY)

    # Status donut
    if total > 0:
        buf = _donut_chart(
            ["Completed", "Open"],
            [max(done, 0.001), max(open_n, 0.001)],
            ['#2E7D32', '#C62828'],
            title="Resolution Status")
        sl.shapes.add_picture(buf, Inches(9.6), Inches(3.1), Inches(3.4), Inches(1.95))

    # Open cases table
    open_cases = transferred.get("open_cases", [])[:12]
    if open_cases:
        _txb(sl, f"OPEN CASES  ({len(open_cases)} shown)", Inches(0.3), Inches(3.05),
             Inches(9.1), Inches(0.3), size=Pt(9), bold=True, color=C_RED)
        hdrs = ["Brand", "Week", "Category", "Status", "SLA", "Next Step", "Analyst"]
        rows = [[
            c.get("Brand Name", ""),
            c.get("Week_Label", c.get("Week", "")),
            c.get("Category", ""),
            c.get("Status", ""),
            c.get("SLA", ""),
            str(c.get("Next Step", "") or "")[:28],
            c.get("Analyst Name", ""),
        ] for c in open_cases]
        _table(sl, hdrs, rows,
               Inches(0.3), Inches(3.4), Inches(9.1), Inches(3.75),
               hdr_bg=C_RED,
               col_widths=[2.5, 1.0, 1.8, 1.3, 0.9, 2.8, 1.5],
               col_aligns=[PP_ALIGN.LEFT, PP_ALIGN.CENTER, PP_ALIGN.LEFT,
                           PP_ALIGN.CENTER, PP_ALIGN.CENTER, PP_ALIGN.LEFT, PP_ALIGN.LEFT])

    # Brand resolution table
    brands_tr = transferred.get("brands", [])[:8]
    if brands_tr:
        _txb(sl, "BRAND SUMMARY", Inches(9.6), Inches(5.2), Inches(3.4), Inches(0.3),
             size=Pt(9), bold=True, color=C_ORANGE)
        br_hdrs = ["Brand", "Total", "Done", "%"]
        br_rows = [[
            b.get("Brand Name", ""),
            b.get("Total", 0),
            b.get("Completed", 0),
            f"{b.get('Completion_Pct', 0):.0f}%",
        ] for b in brands_tr]
        _table(sl, br_hdrs, br_rows,
               Inches(9.6), Inches(5.52), Inches(3.4), Inches(1.63),
               hdr_bg=C_DARK,
               col_widths=[1.9, 0.7, 0.7, 0.7],
               col_aligns=[PP_ALIGN.LEFT, PP_ALIGN.CENTER, PP_ALIGN.CENTER, PP_ALIGN.CENTER])


# ── Slide 6 — Business Value KPIs ────────────────────────────────────────────

def _slide_bv(prs, snap, bv, benchmarks):
    sl = prs.slides.add_slide(prs.slide_layouts[6])
    _rect(sl, 0, 0, SLIDE_W, SLIDE_H, C_WHITE)
    _header(sl, "Business Value KPIs",
            "Strategic metrics that quantify iOPEX's value delivery to The Home Depot")
    _footer(sl, snap.get("week_label", ""))

    # Intro
    _note_box(sl,
        "These KPIs go beyond standard productivity metrics. They demonstrate the strategic, "
        "measurable value iOPEX delivers — reducing escalations, improving supplier experience, "
        "ensuring SLA compliance, and driving continuous improvement for The Home Depot's OAM function.",
        Inches(0.3), Inches(1.15), Inches(12.7), Inches(0.58),
        bg=RGBColor(0xFF, 0xF3, 0xEB), fg=C_BLACK)

    kpi_defs = [
        ("Escalation Avoidance",
         bv.get("escalation_avoidance_rate") or bv.get("escalation_avoidance_pct", "—"),
         "%", "≥ 95%",
         "% of contacts resolved in-house without escalation. "
         "High value = team handles complexity independently.",
         C_GREEN),
        ("Issue Recurrence Rate",
         bv.get("issue_recurrence_rate") or bv.get("issue_recurrence_rate_pct", "—"),
         "%", "≤ 20%",
         "% of issues that reappear for the same brand/category. "
         "Low value = root causes are being fixed.",
         C_RED),
        ("Chat Responsiveness",
         bv.get("chat_responsiveness_index") or bv.get("chat_responsiveness_idx", "—"),
         "", "≥ 100%",
         "Chat FRT vs 1-min benchmark (>100% = beating target). "
         "Reflects live-chat speed quality.",
         C_ORANGE),
        ("Operational Efficiency",
         bv.get("operational_efficiency_score") or bv.get("operational_efficiency_pct", "—"),
         "%", "≥ 80%",
         "% of contacts meeting both AHT and FRT targets simultaneously. "
         "Single composite efficiency index.",
         C_DARK),
        ("SLA Compliance",
         bv.get("sla_compliance_rate") or bv.get("transferred_resolution_pct", "—"),
         "%", "≥ 80%",
         "% of transferred tickets resolved within the agreed SLA window. "
         "Demonstrates end-to-end ownership.",
         C_GREEN),
        ("After-Hours Coverage",
         bv.get("after_hours_coverage") or bv.get("after_hours_coverage_pct", "—"),
         "%", "Informational",
         "% of supplier contacts handled outside core hours. "
         "Shows extended support commitment.",
         C_DARK),
        ("FCR Benchmark Delta",
         bv.get("fcr_benchmark_delta") or bv.get("first_touch_resolution_pct", "—"),
         "", f"vs {benchmarks.get('fcr_pct', 80)}% BM",
         "Difference between actual FCR and the benchmark. "
         "Positive delta = exceeding expectations.",
         C_ORANGE),
        ("Brand Engagement",
         bv.get("multi_channel_balance") or bv.get("brand_engagement_score", "—"),
         "", "Informational",
         "Breadth of brand coverage across all channels. "
         "Higher index = serving a wider supplier base.",
         C_DARK),
    ]

    # 4 cards per row, 2 rows
    cw, ch, gap = Inches(3.1), Inches(2.18), Inches(0.13)
    sx, sy = Inches(0.3), Inches(1.88)
    for i, (name, val, unit, target, desc, bg) in enumerate(kpi_defs):
        row, col = i // 4, i % 4
        x = sx + col * (cw + gap)
        y = sy + row * (ch + Inches(0.12))
        _rect(sl, x, y, cw, ch, bg)
        _txb(sl, name, x + Inches(0.12), y + Inches(0.08),
             cw - Inches(0.24), Inches(0.3),
             size=Pt(8.5), bold=True, color=C_WHITE, align=PP_ALIGN.LEFT)
        val_str = f"{val}" if unit == "" else f"{val}{unit}"
        _txb(sl, val_str, x + Inches(0.12), y + Inches(0.36),
             cw - Inches(0.24), Inches(0.58),
             size=Pt(22), bold=True, color=C_WHITE, align=PP_ALIGN.CENTER)
        _txb(sl, f"Target: {target}", x + Inches(0.12), y + Inches(0.92),
             cw - Inches(0.24), Inches(0.22),
             size=Pt(7.5), color=C_WHITE, align=PP_ALIGN.CENTER, italic=True)
        _txb(sl, desc, x + Inches(0.12), y + Inches(1.14),
             cw - Inches(0.24), Inches(0.92),
             size=Pt(7), color=C_WHITE, align=PP_ALIGN.LEFT)


# ── Slide 7 — Analyst Performance ─────────────────────────────────────────────

def _slide_analysts(prs, snap, analysts):
    sl = prs.slides.add_slide(prs.slide_layouts[6])
    _rect(sl, 0, 0, SLIDE_W, SLIDE_H, C_WHITE)
    _header(sl, "Analyst Performance",
            "Individual contributor KPI breakdown — identifying top performers and coaching opportunities")
    _footer(sl, snap.get("week_label", ""))

    if not analysts:
        _txb(sl, "No analyst data available.", Inches(0.5), Inches(2), Inches(12), Inches(1),
             size=Pt(14), color=C_GRAY, align=PP_ALIGN.CENTER)
        return

    # Bar chart — volume by analyst
    names  = [a.get("Analyst Name", "")[:18] for a in analysts[:12]]
    totals = [a.get("Total", 0) or 0 for a in analysts[:12]]
    if names:
        buf = _hbar_chart(names[::-1], totals[::-1], "Contact Volume by Analyst", '#F96302')
        sl.shapes.add_picture(buf, Inches(0.3), Inches(1.15), Inches(4.5), Inches(3.8))

    # Performance table — ranked by transfer rate (lower is better)
    hdrs = ["#", "Analyst", "Total", "FCR%", "AHT (min)", "FRT (min)", "Transfer%", "Performance"]
    bm_fcr = 80
    rows = []
    for i, a in enumerate(analysts[:16]):
        fcr  = a.get('FCR', 0) or 0
        tr   = a.get('Transfer_Rate_Pct', 0) or 0
        aht  = a.get('Avg_AHT', 0) or 0
        perf = "Strong" if fcr >= bm_fcr and tr <= 5 else ("Developing" if fcr >= 70 else "Needs Review")
        rows.append([
            a.get("Rank", i + 1),
            a.get("Analyst Name", ""),
            a.get("Total", 0),
            f"{fcr:.1f}%",
            f"{aht:.1f}",
            f"{a.get('Avg_FRT', 0) or 0:.1f}",
            f"{tr:.1f}%",
            perf,
        ])
    _table(sl, hdrs, rows,
           Inches(5.0), Inches(1.15), Inches(8.0), Inches(5.9),
           hdr_bg=C_ORANGE,
           col_widths=[0.5, 2.5, 0.75, 0.8, 0.95, 0.95, 1.0, 1.1],
           col_aligns=[PP_ALIGN.CENTER, PP_ALIGN.LEFT] + [PP_ALIGN.CENTER] * 6)

    # Legend note
    _note_box(sl,
        "Performance Rating:  Strong = FCR ≥ 80% AND Transfer Rate ≤ 5%  |  "
        "Developing = FCR 70–79%  |  Needs Review = FCR < 70%",
        Inches(0.3), Inches(5.1), Inches(4.5), Inches(0.52),
        bg=C_LGRAY)


# ── Main entry ────────────────────────────────────────────────────────────────

def generate_ppt(data: dict, output_path: str):
    prs = Presentation()
    prs.slide_width  = SLIDE_W
    prs.slide_height = SLIDE_H

    snap     = data.get("snapshot", {})
    ytd      = data.get("ytd") or {}
    bm       = data.get("benchmarks", {})
    wk       = data.get("weekly_kpis", [])
    ba       = data.get("brand_analysis", {})
    tr       = data.get("transferred", {})
    bv       = data.get("business_value_kpis", {})
    analysts = data.get("analysts", [])

    _slide_cover(prs, snap, ytd)
    _slide_exec(prs, snap, ytd, bm)
    _slide_brands(prs, snap, ba)
    _slide_channels(prs, snap, wk, bm)
    _slide_transferred(prs, snap, tr)
    _slide_bv(prs, snap, bv, bm)
    _slide_analysts(prs, snap, analysts)

    prs.save(output_path)
