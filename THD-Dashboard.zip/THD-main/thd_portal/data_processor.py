"""
THD OAM Analytics - Data Processor
Shared data loading, cleaning, and KPI computation used by both the
automated Excel report generator and the Flask portal.
"""
import pandas as pd
import numpy as np
from pathlib import Path

# ─── Configuration ────────────────────────────────────────────────────────────
# Resolve paths relative to this file's location so the project works on any machine.
# data_processor.py lives in thd_portal/, so parent = project root.
BASE_DIR = Path(__file__).resolve().parent.parent
EXCEL_PATH = BASE_DIR / "Productivity_Sheet.xlsx"

BENCHMARKS = {
    "chat_frt_min":         1.0,    # Chat First Response Time ≤ 1 min
    "mail_frt_min":         60.0,   # Mail First Response Time ≤ 60 min
    "aht_min":              30.0,   # Average Handling Time ≤ 30 min
    "resolution_min":       30.0,   # Resolution Time ≤ 30 min
    "fcr_pct":              80.0,   # First Contact Resolution ≥ 80%
    "ssat":                 4.5,    # Supplier Satisfaction ≥ 4.5
    "escalation_rate_pct":  5.0,    # Escalation Rate ≤ 5%
    "transferred_sla_hrs":  48.0,   # Transferred ticket SLA ≤ 48 hrs
}



# ─── Helpers ──────────────────────────────────────────────────────────────────
def _time_str_to_minutes(series):
    """Convert 'HH:MM:SS' strings or timedelta to float minutes."""
    def _parse(v):
        if pd.isna(v):
            return np.nan
        if isinstance(v, pd.Timedelta):
            return v.total_seconds() / 60
        s = str(v).strip()
        parts = s.split(":")
        try:
            if len(parts) == 3:
                h, m, sec = int(parts[0]), int(parts[1]), float(parts[2])
                return h * 60 + m + sec / 60
            elif len(parts) == 2:
                return int(parts[0]) * 60 + int(parts[1])
        except Exception:
            pass
        return np.nan
    return series.apply(_parse)


def _clean_text(s):
    return str(s).strip() if pd.notna(s) else ""


def _week_sort_key(week_str, fiscal_year):
    """Return integer sort key: YYYYWW"""
    try:
        n = int(str(week_str).replace("Week", "").replace("week", "").strip())
        return fiscal_year * 100 + n
    except Exception:
        return 999999


def _assign_fiscal_year(row):
    """Assign fiscal year on the THD retail calendar.

    The fiscal year runs February → January and is labelled by the calendar
    year in which it STARTS. So Feb–Dec of year N belong to FY(N), and January
    of year N belongs to FY(N-1).
        Retail FY      Period
        FY2025         Feb 2025 → Jan 2026
        FY2026         Feb 2026 → Jan 2027
    """
    d = row.get("_date")
    if pd.notna(d):
        return d.year if d.month >= 2 else d.year - 1
    # Fall back when the date is unparseable: assume the fiscal year present in
    # the current dataset rather than mis-splitting on a week-number heuristic.
    return 2025


# ─── BAU Sheet ────────────────────────────────────────────────────────────────
def load_bau():
    df = pd.read_excel(EXCEL_PATH, sheet_name="BAU")

    # Normalise column names (strip whitespace)
    df.columns = [c.strip() for c in df.columns]

    # ── Date / week ────────────────────────────────────────────────────────
    df["_date"] = pd.to_datetime(df.get("Request Received Date"), errors="coerce")
    df["_week_num"] = (
        df["Week"].astype(str).str.extract(r"(\d+)")[0].astype(float)
    )
    df["Fiscal_Year"] = df.apply(_assign_fiscal_year, axis=1)
    # Sort weeks chronologically by CALENDAR year — week numbers reset in
    # January, not at the February fiscal-year boundary — so the fiscal-year
    # label and the chronological sort key stay independent.
    df["_cal_year"] = df["_date"].dt.year.fillna(df["Fiscal_Year"]).astype(int)
    df["Week_Sort"] = df.apply(
        lambda r: _week_sort_key(r["Week"], int(r["_cal_year"])), axis=1
    )
    df["Week_Label"] = df.apply(
        lambda r: f"FY{str(int(r['Fiscal_Year']))[2:]} W{int(r['_week_num']):02d}"
        if pd.notna(r["_week_num"])
        else "Unknown",
        axis=1,
    )

    # ── Channel normalise ──────────────────────────────────────────────────
    df["Mode"] = df["Mode"].str.strip().replace({"Email": "Mail", "email": "Mail"})

    # ── Brand Name ─────────────────────────────────────────────────────────
    df["Brand Name"] = (
        df["Brand Name"].astype(str).str.strip().str.upper()
        .str.replace(r"\s+", " ", regex=True)
    )
    df["Brand Name"] = df["Brand Name"].replace("MULTIPLE BRANDS", "(Multi-Brand Case)")

    # ── Category normalise ─────────────────────────────────────────────────
    cat_map = {
        "Campaign setup guidance":       "Campaign Setup Guidance",
        "OA platform access/Login issue":"OA Platform Access/Login Issues",
        "Reporting/Data requests":        "Reporting/Data Requests",
        "Others":                         "Other",
    }
    df["Category"] = df["Category"].str.strip().replace(cat_map)

    # ── FCR normalise ──────────────────────────────────────────────────────
    df["First contact resolution"] = (
        df["First contact resolution"].astype(str).str.strip().str.capitalize()
    )

    # ── Time fields → minutes ─────────────────────────────────────────────
    df["AHT_min"]       = _time_str_to_minutes(df.get("AHT", pd.Series()))
    df["FRT_min"]       = _time_str_to_minutes(df.get("First Response Time", pd.Series()))
    df["Res_min"]       = _time_str_to_minutes(df.get("Resolution", pd.Series()))

    # ── After-Hours normalise ──────────────────────────────────────────────
    df["After-Hours"] = df["After-Hours"].astype(str).str.strip().replace({"Select": "No"})

    # ── Transfer flag ─────────────────────────────────────────────────────
    df["Transferred_flag"] = df.get("Transfered", pd.Series(dtype=str)).astype(str).str.strip().str.lower() == "yes"

    return df


# ─── Transferred Sheet ────────────────────────────────────────────────────────
def load_transferred():
    df = pd.read_excel(EXCEL_PATH, sheet_name="Transferred")
    df.columns = [c.strip() for c in df.columns]

    df["_date"] = pd.to_datetime(df.get("Request Received Date"), errors="coerce")
    df["_week_num"] = (
        df["Week"].astype(str).str.extract(r"(\d+)")[0].astype(float)
    )
    df["Fiscal_Year"] = df.apply(_assign_fiscal_year, axis=1)
    # Sort weeks chronologically by CALENDAR year — week numbers reset in
    # January, not at the February fiscal-year boundary — so the fiscal-year
    # label and the chronological sort key stay independent.
    df["_cal_year"] = df["_date"].dt.year.fillna(df["Fiscal_Year"]).astype(int)
    df["Week_Sort"] = df.apply(
        lambda r: _week_sort_key(r["Week"], int(r["_cal_year"])), axis=1
    )
    df["Week_Label"] = df.apply(
        lambda r: f"FY{str(int(r['Fiscal_Year']))[2:]} W{int(r['_week_num']):02d}"
        if pd.notna(r["_week_num"])
        else "Unknown",
        axis=1,
    )

    df["Brand Name"] = (
        df["Brand Name"].astype(str).str.strip().str.upper()
        .str.replace(r"\s+", " ", regex=True)
    )
    df["Brand Name"] = df["Brand Name"].replace("MULTIPLE BRANDS", "(Multi-Brand Case)")
    df = df[df["Brand Name"].notna() & (df["Brand Name"] != "NAN")]

    for col in ["AHT", "Resolution Time", "First Response Time"]:
        if col in df.columns:
            df[col + "_min"] = pd.to_timedelta(df[col], errors="coerce").dt.total_seconds() / 60
        else:
            df[col + "_min"] = np.nan

    sla_map = {"24 hrs": 24 * 60, "24-48 hrs": 48 * 60, "48 hrs": 48 * 60, "3-5 business": 120 * 60}
    df["SLA_target_min"] = df["SLA"].map(sla_map)
    df["SLA_Met"] = df["Resolution Time_min"] <= df["SLA_target_min"]
    df["Is_Completed"] = df["Status"].astype(str).str.strip().str.lower() == "completed"

    return df


# ─── Brand Issue Analysis ─────────────────────────────────────────────────────
def brand_issue_analysis(df_bau, df_tr):
    """
    Identify NEW vs REPEATED issues per brand.
    A 'repeated issue' = same Brand + Category combination seen more than once.
    First occurrence per brand+category = New; subsequent = Repeated.
    Uses both BAU and Transferred data.
    """
    # Combine brands from both sheets
    cols = ["Brand Name", "Category", "_date", "Week_Label", "Week_Sort", "Mode"]
    bau_sub = df_bau[cols].copy()
    bau_sub["Source"] = "BAU"

    tr_cols = ["Brand Name", "Category", "_date", "Week_Label", "Week_Sort"]
    tr_sub = df_tr[tr_cols].copy()
    tr_sub["Mode"] = "Mail"
    tr_sub["Source"] = "Transferred"

    combined = pd.concat([bau_sub, tr_sub], ignore_index=True)
    combined = combined[
        combined["Brand Name"].notna() &
        (combined["Brand Name"] != "NAN") &
        (combined["Brand Name"] != "")
    ]
    combined["Category"] = combined["Category"].astype(str).str.strip()
    combined = combined.sort_values("_date", na_position="last")

    # Mark New vs Repeated
    seen = {}
    issue_types = []
    for _, row in combined.iterrows():
        key = (row["Brand Name"], row["Category"])
        count = seen.get(key, 0)
        issue_types.append("New" if count == 0 else "Repeated")
        seen[key] = count + 1
    combined["Issue_Type"] = issue_types

    # Brand-level summary
    brand_summary = combined.groupby("Brand Name").agg(
        Total_Issues     = ("Brand Name", "count"),
        New_Issues       = ("Issue_Type", lambda x: (x == "New").sum()),
        Repeated_Issues  = ("Issue_Type", lambda x: (x == "Repeated").sum()),
        Weeks_Active     = ("Week_Label", "nunique"),
        Top_Category     = ("Category", lambda x: x.value_counts().index[0] if len(x) > 0 else ""),
        Last_Seen        = ("_date", "max"),
    ).reset_index()

    brand_summary["Repeated_Pct"] = (
        brand_summary["Repeated_Issues"] / brand_summary["Total_Issues"] * 100
    ).round(1)
    brand_summary = brand_summary.sort_values("Total_Issues", ascending=False)

    # Category-level repeated summary (per brand + category)
    cat_summary = combined.groupby(["Brand Name", "Category"]).agg(
        Count        = ("Brand Name", "count"),
        New          = ("Issue_Type", lambda x: (x == "New").sum()),
        Repeated     = ("Issue_Type", lambda x: (x == "Repeated").sum()),
    ).reset_index()
    cat_summary = cat_summary.sort_values("Count", ascending=False)

    # Category-level New vs Repeated split (aggregated across all brands)
    category_split = combined.groupby("Category").agg(
        Total        = ("Category", "count"),
        New          = ("Issue_Type", lambda x: (x == "New").sum()),
        Repeated     = ("Issue_Type", lambda x: (x == "Repeated").sum()),
    ).reset_index()
    category_split["Repeated_Pct"] = (
        category_split["Repeated"] / category_split["Total"] * 100
    ).round(1)
    category_split = category_split.sort_values("Total", ascending=False)

    # Overall stats
    total = len(combined)
    new_total = (combined["Issue_Type"] == "New").sum()
    repeated_total = (combined["Issue_Type"] == "Repeated").sum()

    return {
        "combined":      combined,
        "brand_summary": brand_summary,
        "cat_summary":   cat_summary,
        "category_split": category_split,
        "total_issues":  total,
        "new_issues":    int(new_total),
        "repeated_issues": int(repeated_total),
        "new_pct":       round(new_total / total * 100, 1) if total else 0,
        "repeated_pct":  round(repeated_total / total * 100, 1) if total else 0,
    }


# ─── Weekly KPIs ─────────────────────────────────────────────────────────────
def weekly_kpis(df_bau):
    """Compute KPIs for every week in BAU."""
    rows = []
    for week_label, grp in df_bau.groupby("Week_Label"):
        week_sort = grp["Week_Sort"].iloc[0]
        total     = len(grp)
        mail_grp  = grp[grp["Mode"] == "Mail"]
        chat_grp  = grp[grp["Mode"] == "Chat"]

        fcr = (grp["First contact resolution"].str.lower() == "yes").sum() / total * 100 if total else 0
        transfer_rate = grp["Transferred_flag"].sum() / total * 100 if total else 0
        after_hours   = (grp["After-Hours"].str.lower() == "yes").sum() / total * 100 if total else 0

        avg_aht_mail  = mail_grp["AHT_min"].mean() if len(mail_grp) else np.nan
        avg_aht_chat  = chat_grp["AHT_min"].mean() if len(chat_grp) else np.nan
        avg_frt_mail  = mail_grp["FRT_min"].mean()  if len(mail_grp) else np.nan
        avg_frt_chat  = chat_grp["FRT_min"].mean()  if len(chat_grp) else np.nan
        avg_res_mail  = mail_grp["Res_min"].mean()  if len(mail_grp) else np.nan
        avg_res_chat  = chat_grp["Res_min"].mean()  if len(chat_grp) else np.nan

        # Calendar metadata
        min_date    = grp["_date"].dropna().min()
        cal_year    = int(min_date.year)   if pd.notna(min_date) else int(grp["Fiscal_Year"].iloc[0])
        cal_month   = int(min_date.month)  if pd.notna(min_date) else 1
        quarter     = (cal_month - 1) // 3 + 1
        month_str   = min_date.strftime("%b %Y") if pd.notna(min_date) else ""
        fy_label    = f"FY{str(int(grp['Fiscal_Year'].iloc[0]))[2:]}"

        rows.append({
            "Week_Label":        week_label,
            "Week_Sort":         week_sort,
            "Fiscal_Year_Label": fy_label,
            "Calendar_Year":     cal_year,
            "Calendar_Month":    cal_month,
            "Month_Str":         month_str,
            "Quarter":           quarter,
            "Total_Volume":      total,
            "Mail_Volume":       len(mail_grp),
            "Chat_Volume":       len(chat_grp),
            "FCR_Pct":           round(fcr, 1),
            "Transfer_Rate_Pct": round(transfer_rate, 1),
            "AfterHours_Pct":    round(after_hours, 1),
            "Avg_AHT_Mail_min":  round(avg_aht_mail, 1) if not pd.isna(avg_aht_mail) else None,
            "Avg_AHT_Chat_min":  round(avg_aht_chat, 1) if not pd.isna(avg_aht_chat) else None,
            "Avg_FRT_Mail_min":  round(avg_frt_mail, 1) if not pd.isna(avg_frt_mail) else None,
            "Avg_FRT_Chat_min":  round(avg_frt_chat, 1) if not pd.isna(avg_frt_chat) else None,
            "Avg_Res_Mail_min":  round(avg_res_mail, 1) if not pd.isna(avg_res_mail) else None,
            "Avg_Res_Chat_min":  round(avg_res_chat, 1) if not pd.isna(avg_res_chat) else None,
        })

    wk_df = pd.DataFrame(rows).sort_values("Week_Sort").reset_index(drop=True)

    # Add vs-last-week deltas (numeric columns only)
    str_cols = {"Week_Label", "Week_Sort", "Month_Str", "Quarter",
                "Fiscal_Year_Label", "Calendar_Year", "Calendar_Month"}
    num_cols = [c for c in wk_df.columns
                if c not in str_cols and pd.api.types.is_numeric_dtype(wk_df[c])]
    for col in num_cols:
        wk_df[f"{col}_vLW"] = wk_df[col].diff()

    return wk_df


# ─── Current-Week Snapshot ────────────────────────────────────────────────────
def current_week_snapshot(df_bau, df_tr, wk_kpis):
    """Return dict with current-week KPIs + benchmark comparisons."""
    latest = wk_kpis.iloc[-1] if len(wk_kpis) else None
    prev   = wk_kpis.iloc[-2] if len(wk_kpis) >= 2 else None

    def bench_pct(actual, target, lower_is_better=True):
        if pd.isna(actual) or actual is None or target == 0:
            return None
        if lower_is_better:
            return round(target / actual * 100, 1)
        else:
            return round(actual / target * 100, 1)

    def delta(key):
        if latest is None or prev is None:
            return None
        v = latest.get(f"{key}_vLW")
        return round(float(v), 1) if pd.notna(v) else None

    # Transferred stats for current week
    cur_week = latest["Week_Label"] if latest is not None else None
    tr_cur = df_tr[df_tr["Week_Label"] == cur_week] if cur_week else df_tr.iloc[0:0]
    tr_total     = len(tr_cur)
    tr_resolved  = tr_cur["Is_Completed"].sum() if tr_total else 0
    tr_open      = tr_total - tr_resolved
    tr_avg_res   = tr_cur["Resolution Time_min"].mean() if tr_total else None

    return {
        "week_label": cur_week,
        "total_volume":      int(latest["Total_Volume"]) if latest is not None else 0,
        "mail_volume":       int(latest["Mail_Volume"])  if latest is not None else 0,
        "chat_volume":       int(latest["Chat_Volume"])  if latest is not None else 0,
        "fcr_pct":           float(latest["FCR_Pct"])    if latest is not None else 0,
        "fcr_vlw":           delta("FCR_Pct"),
        "fcr_bench_pct":     bench_pct(latest["FCR_Pct"] if latest is not None else None,
                                        BENCHMARKS["fcr_pct"], lower_is_better=False),
        "transfer_rate_pct": float(latest["Transfer_Rate_Pct"]) if latest is not None else 0,
        "after_hours_pct":   float(latest["AfterHours_Pct"]) if latest is not None else 0,
        # Mail KPIs
        "aht_mail":    latest["Avg_AHT_Mail_min"] if latest is not None else None,
        "frt_mail":    latest["Avg_FRT_Mail_min"] if latest is not None else None,
        "res_mail":    latest["Avg_Res_Mail_min"] if latest is not None else None,
        "frt_mail_bench_pct": bench_pct(
            latest["Avg_FRT_Mail_min"] if latest is not None else None,
            BENCHMARKS["mail_frt_min"]),
        # Chat KPIs
        "aht_chat":    latest["Avg_AHT_Chat_min"] if latest is not None else None,
        "frt_chat":    latest["Avg_FRT_Chat_min"] if latest is not None else None,
        "res_chat":    latest["Avg_Res_Chat_min"] if latest is not None else None,
        "frt_chat_bench_pct": bench_pct(
            latest["Avg_FRT_Chat_min"] if latest is not None else None,
            BENCHMARKS["chat_frt_min"]),
        # Transferred
        "tr_total":    tr_total,
        "tr_resolved": int(tr_resolved),
        "tr_open":     int(tr_open),
        "tr_avg_res_hrs": round(float(tr_avg_res) / 60, 1) if tr_avg_res and not pd.isna(tr_avg_res) else None,
    }


# ─── Category Distribution ───────────────────────────────────────────────────
def category_distribution(df_bau):
    cat = df_bau.groupby(["Category", "Mode"]).size().reset_index(name="Count")
    pivot = cat.pivot_table(index="Category", columns="Mode", values="Count", fill_value=0)
    pivot["Total"] = pivot.sum(axis=1)
    pivot = pivot.sort_values("Total", ascending=False).reset_index()
    return pivot


# ─── Transferred Summary ─────────────────────────────────────────────────────
def transferred_summary(df_tr):
    brand_tr = df_tr.groupby("Brand Name").agg(
        Total          = ("Brand Name", "count"),
        Completed      = ("Is_Completed", "sum"),
        SLA_Met        = ("SLA_Met", "sum"),
        SLA_Tracked    = ("SLA_target_min", lambda x: x.notna().sum()),
        Avg_Res_hrs    = ("Resolution Time_min", lambda x: round(x.mean() / 60, 1) if x.notna().any() else None),
    ).reset_index()
    brand_tr["Completion_Pct"] = (brand_tr["Completed"] / brand_tr["Total"] * 100).round(1)
    brand_tr["SLA_Pct"] = (brand_tr["SLA_Met"] / brand_tr["SLA_Tracked"].replace(0, np.nan) * 100).round(1)
    brand_tr = brand_tr.sort_values("Total", ascending=False)

    open_cases = df_tr[~df_tr["Is_Completed"]].copy()
    open_cases = open_cases.sort_values("_date", na_position="last")

    return {
        "brand_summary":    brand_tr,
        "open_cases":       open_cases,
        "total":            len(df_tr),
        "total_completed":  int(df_tr["Is_Completed"].sum()),
        "total_open":       int((~df_tr["Is_Completed"]).sum()),
        "completion_pct":   round(df_tr["Is_Completed"].mean() * 100, 1),
        "avg_res_hrs":      round(df_tr["Resolution Time_min"].mean() / 60, 1)
                            if df_tr["Resolution Time_min"].notna().any() else None,
    }


# ─── Business Value KPIs (custom) ────────────────────────────────────────────
def business_value_kpis(df_bau, df_tr, brand_analysis, wk_kpis):
    """
    Custom iOPEX → THD Business Value KPIs beyond standard productivity metrics.
    """
    total        = len(df_bau)
    latest_wk    = wk_kpis.iloc[-1] if len(wk_kpis) else pd.Series(dtype=float)
    prev_wk      = wk_kpis.iloc[-2] if len(wk_kpis) >= 2 else pd.Series(dtype=float)

    # 1. Escalation Avoidance Rate
    escalation_avoid = 100 - float(latest_wk.get("Transfer_Rate_Pct", 0))

    # 2. Issue Recurrence Rate (how often brands repeat issues)
    recurrence_rate = brand_analysis["repeated_pct"]

    # 3. First-Touch Resolution Rate (same as FCR)
    ftr = float(latest_wk.get("FCR_Pct", 0))

    # 4. Chat Responsiveness Index (chat FRT vs 1-min benchmark)
    frt_chat = latest_wk.get("Avg_FRT_Chat_min")
    chat_resp_idx = round(BENCHMARKS["chat_frt_min"] / frt_chat * 100, 1) if frt_chat and frt_chat > 0 else None

    # 5. Transferred Ticket Resolution Rate
    tr_res_rate = transferred_summary(df_tr)["completion_pct"]

    # 6. After-Hours Coverage (extended support metric)
    ah_coverage = float(latest_wk.get("AfterHours_Pct", 0))

    # 7. Brand Engagement Score (unique brands served vs total volume)
    unique_brands = df_bau["Brand Name"].replace("NAN", np.nan).dropna().nunique()
    brand_engagement = round(unique_brands / max(total, 1) * 100, 1)

    # 8. Operational Efficiency Score (composite: AHT + FRT both at or below target)
    aht_ok   = (df_bau["AHT_min"] <= BENCHMARKS["aht_min"]).mean() * 100
    frt_mail_ok = (df_bau[df_bau["Mode"] == "Mail"]["FRT_min"] <= BENCHMARKS["mail_frt_min"]).mean() * 100
    frt_chat_ok = (df_bau[df_bau["Mode"] == "Chat"]["FRT_min"] <= BENCHMARKS["chat_frt_min"]).mean() * 100
    ops_eff = round((aht_ok + frt_mail_ok + frt_chat_ok) / 3, 1)

    return {
        "escalation_avoidance_pct":    round(escalation_avoid, 1),
        "issue_recurrence_rate_pct":   recurrence_rate,
        "first_touch_resolution_pct":  round(ftr, 1),
        "chat_responsiveness_idx":     chat_resp_idx,
        "transferred_resolution_pct":  tr_res_rate,
        "after_hours_coverage_pct":    round(ah_coverage, 1),
        "brand_engagement_score":      brand_engagement,
        "operational_efficiency_pct":  ops_eff,
        "unique_brands_served":        unique_brands,
        "total_volume":                total,
    }


# ─── Master load ─────────────────────────────────────────────────────────────
def load_all():
    """Single entry point – returns everything needed by report & portal."""
    df_bau = load_bau()
    df_tr  = load_transferred()
    brand  = brand_issue_analysis(df_bau, df_tr)
    wk     = weekly_kpis(df_bau)
    snap   = current_week_snapshot(df_bau, df_tr, wk)
    cat    = category_distribution(df_bau)
    tr_sum = transferred_summary(df_tr)
    bv     = business_value_kpis(df_bau, df_tr, brand, wk)

    return {
        "bau":            df_bau,
        "transferred":    df_tr,
        "brand_analysis": brand,
        "weekly_kpis":    wk,
        "snapshot":       snap,
        "categories":     cat,
        "transferred_summary": tr_sum,
        "business_value_kpis": bv,
        "benchmarks":     BENCHMARKS,
    }
