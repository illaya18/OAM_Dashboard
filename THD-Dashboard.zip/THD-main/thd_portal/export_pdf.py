"""
THD OAM Analytics Portal — PDF Export
Properly formatted multi-page landscape PDF using matplotlib.
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.backends.backend_pdf import PdfPages
import numpy as np
from datetime import date

# ── THD Palette ───────────────────────────────────────────────────────────────
ORANGE = "#F96302"
DARK   = "#CC4E00"
BLACK  = "#1A1A1A"
WHITE  = "#FFFFFF"
LGRAY  = "#F5F5F5"
GRAY   = "#BBBBBB"
GREEN  = "#2E7D32"
RED    = "#C62828"
AMBER  = "#E65C00"
LBLUE  = "#E3F2FD"

PW, PH = 17, 9.5   # landscape inches


# ── Core helpers ──────────────────────────────────────────────────────────────

def _new_fig(title, subtitle="", week_label=""):
    fig = plt.figure(figsize=(PW, PH), facecolor=WHITE)
    fig.patch.set_facecolor(WHITE)

    # Orange header band
    header = fig.add_axes([0, 0.905, 1, 0.095])
    header.axis("off")
    _fill(header, ORANGE)
    header.text(0.015, 0.65, title, transform=header.transAxes,
                fontsize=20, fontweight="bold", color=WHITE, va="center")
    header.text(0.015, 0.18, subtitle, transform=header.transAxes,
                fontsize=10, color=WHITE, va="center")
    header.text(0.985, 0.50, "iOPEX Technologies  |  The Home Depot OAM  |  Confidential",
                transform=header.transAxes, fontsize=8.5, color=WHITE,
                ha="right", va="center", style="italic")

    # Black footer bar
    footer = fig.add_axes([0, 0, 1, 0.032])
    footer.axis("off")
    _fill(footer, BLACK)
    footer.text(0.015, 0.5, f"Generated: {date.today():%B %d, %Y}",
                transform=footer.transAxes, fontsize=7, color=GRAY, va="center")
    footer.text(0.5, 0.5, week_label,
                transform=footer.transAxes, fontsize=7, color=WHITE,
                ha="center", va="center", fontweight="bold")
    footer.text(0.985, 0.5, "iOPEX Technologies",
                transform=footer.transAxes, fontsize=7, color=ORANGE,
                ha="right", va="center", fontweight="bold")
    return fig


def _fill(ax, color):
    """Paint a solid background on an axis-off axes.

    In this matplotlib build, ``ax.set_facecolor()`` is not honoured once the
    axis is turned off (the background patch is dropped), so coloured bands,
    KPI tiles and call-out boxes silently render transparent in the PDF.
    Drawing an explicit full-bleed rectangle is reliable across backends.
    """
    ax.add_patch(plt.Rectangle((0, 0), 1, 1, transform=ax.transAxes,
                               fc=color, ec="none", zorder=0))


def _fmt(v, decimals=1, suffix=""):
    if v is None: return "—"
    try:
        return f"{float(v):.{decimals}f}{suffix}"
    except Exception:
        return str(v)


def _draw_table(ax, headers, rows, hdr_color=ORANGE, row_colors=None,
                col_widths=None, fontsize=8, col_aligns=None):
    ax.axis("off")
    if not rows:
        ax.text(0.5, 0.5, "No data available", ha="center", va="center",
                fontsize=11, color=GRAY, transform=ax.transAxes)
        return

    n_cols = len(headers)
    n_rows = len(rows)

    # Auto column widths if not specified
    if col_widths is None:
        col_widths = [1 / n_cols] * n_cols
    # Normalise
    total = sum(col_widths)
    col_widths = [w / total for w in col_widths]

    # Per-column alignment — default: first column left (labels), rest centered.
    if col_aligns is None:
        col_aligns = ["left"] + ["center"] * (n_cols - 1)

    # Lay the table out to fill the full axes height so rows are evenly spaced
    # regardless of how tall/short the host axes is.
    y_top = 0.985
    hdr_h = y_top / (n_rows + 1.3)       # header a touch taller than a data row
    row_h = (y_top - hdr_h) / n_rows

    # Adaptive font size: scale to the *physical* row height so text never
    # overflows a short table nor looks tiny in a tall one. `fontsize` acts as
    # the upper bound (preserving each caller's intended maximum).
    fig = ax.figure
    ax_h_in  = ax.get_position().height * fig.get_figheight()
    row_h_in = row_h * ax_h_in
    fit_pt   = row_h_in * 72 * 0.46      # ~46% of row height → cap height + padding
    cell_fs  = max(5.5, min(fit_pt, fontsize))
    hdr_fs   = min(cell_fs + 0.5, 9.0)

    pad = 0.01   # horizontal padding (axes fraction) for left/right-aligned text

    def _anchor(x, cw, align):
        if align == "left":  return x + pad,      "left"
        if align == "right": return x + cw - pad, "right"
        return x + cw / 2, "center"

    # Header
    x = 0
    for hd, cw, al in zip(headers, col_widths, col_aligns):
        ax.add_patch(plt.Rectangle((x, y_top - hdr_h), cw, hdr_h,
                                   fc=hdr_color, ec=WHITE, lw=0.4,
                                   transform=ax.transAxes, clip_on=True))
        tx, ha = _anchor(x, cw, al)
        ax.text(tx, y_top - hdr_h / 2, str(hd),
                ha=ha, va="center", fontsize=hdr_fs, color=WHITE,
                fontweight="bold", transform=ax.transAxes, clip_on=True)
        x += cw

    # Data rows
    for ri, row in enumerate(rows):
        y = y_top - hdr_h - (ri + 1) * row_h
        if y < 0:
            break
        bg = LGRAY if ri % 2 == 0 else WHITE
        if row_colors and ri < len(row_colors):
            bg = row_colors[ri]
        x = 0
        for cell, cw, al in zip(row, col_widths, col_aligns):
            ax.add_patch(plt.Rectangle((x, y), cw, row_h,
                                       fc=bg, ec=GRAY, lw=0.2,
                                       transform=ax.transAxes, clip_on=True))
            tx, ha = _anchor(x, cw, al)
            ax.text(tx, y + row_h / 2, str(cell) if cell is not None else "",
                    ha=ha, va="center", fontsize=cell_fs,
                    color=BLACK, transform=ax.transAxes, clip_on=True)
            x += cw


def _kpi_tile(fig, rect, label, value, sub, bg=ORANGE):
    ax = fig.add_axes(rect)
    ax.axis("off")
    _fill(ax, bg)
    ax.text(0.5, 0.84, label, ha="center", va="center", transform=ax.transAxes,
            fontsize=8, color=WHITE, fontweight="bold")
    ax.text(0.5, 0.50, str(value), ha="center", va="center", transform=ax.transAxes,
            fontsize=20, color=WHITE, fontweight="bold")
    ax.text(0.5, 0.13, str(sub) if sub else "", ha="center", va="center",
            transform=ax.transAxes, fontsize=7, color=WHITE, style="italic")


def _spines_off(ax):
    for spine in ["top", "right"]:
        ax.spines[spine].set_visible(False)


# ── Page 1: Cover ─────────────────────────────────────────────────────────────

def _page_cover(pdf, snap, ytd):
    fig = plt.figure(figsize=(PW, PH), facecolor=BLACK)
    fig.patch.set_facecolor(BLACK)

    # Left orange strip
    s = fig.add_axes([0, 0, 0.04, 1])
    s.axis("off"); _fill(s, ORANGE)

    # Content area
    ax = fig.add_axes([0.06, 0.08, 0.88, 0.88])
    ax.axis("off"); _fill(ax, BLACK)

    ax.text(0, 0.90, "THE HOME DEPOT", fontsize=13, color=ORANGE,
            fontweight="bold", transform=ax.transAxes)
    ax.text(0, 0.72, "OAM Supplier Support\nAnalytics Report Card",
            fontsize=32, color=WHITE, fontweight="bold",
            transform=ax.transAxes, linespacing=1.2)
    wk = snap.get("week_label", "Latest")
    fy = snap.get("fiscal_year", "")
    ax.text(0, 0.53, f"{fy}  |  {wk}",
            fontsize=16, color=DARK, transform=ax.transAxes)

    # Divider
    ax.plot([0, 0.42], [0.49, 0.49], color=ORANGE, lw=2,
            transform=ax.transAxes, clip_on=False)

    ax.text(0, 0.44, "Prepared by: iOPEX Technologies",
            fontsize=11, color=WHITE, transform=ax.transAxes)
    ax.text(0, 0.38, f"Report Date: {date.today():%B %d, %Y}",
            fontsize=11, color=WHITE, transform=ax.transAxes)

    if ytd:
        ax.text(0, 0.28, "YEAR-TO-DATE SNAPSHOT", fontsize=9, color=ORANGE,
                fontweight="bold", transform=ax.transAxes)
        ax.text(0, 0.22,
                f"Total Volume: {ytd.get('total_volume', 0):,}   |   "
                f"FCR: {ytd.get('fcr_pct', 0)}%   |   "
                f"Transfer Rate: {ytd.get('transfer_rate_pct', 0)}%   |   "
                f"Weeks Covered: {ytd.get('weeks_count', 0)}",
                fontsize=10, color=GRAY, transform=ax.transAxes)

    ax.text(0, 0.05,
            "Contents:  Executive Summary  ·  Weekly Trends  ·  Brand Analysis  "
            "·  Transferred Requests  ·  Business Value KPIs  ·  Analyst Performance",
            fontsize=8, color=GRAY, transform=ax.transAxes)

    pdf.savefig(fig, bbox_inches="tight")
    plt.close(fig)


# ── Page 2: Executive Summary ─────────────────────────────────────────────────

def _page_executive(pdf, snap, ytd, benchmarks):
    fig = _new_fig("Executive Summary",
                   f"{snap.get('week_label','Latest')}  —  Current Week KPI Snapshot",
                   snap.get("week_label", ""))

    # 5 volume/quality KPI tiles — top row
    cards1 = [
        ("Total Volume",   f"{snap.get('total_volume', 0):,}", "contacts",  ORANGE),
        ("Mail Volume",    f"{snap.get('mail_volume', 0):,}",  "OAM inbox", DARK),
        ("Chat Volume",    f"{snap.get('chat_volume', 0):,}",  "live chat", DARK),
        ("FCR Rate",       _fmt(snap.get("fcr_pct"), 1, "%"),
         f"Benchmark ≥{benchmarks.get('fcr_pct', 80)}%", GREEN),
        ("Transfer Rate",  _fmt(snap.get("transfer_rate_pct"), 1, "%"),
         f"Benchmark ≤{benchmarks.get('escalation_rate_pct', 5)}%", RED),
    ]
    n = len(cards1)
    cw, ch = 0.185, 0.175
    gap = (1 - n * cw) / (n + 1)
    for i, (lbl, val, sub, bg) in enumerate(cards1):
        x = gap + i * (cw + gap)
        _kpi_tile(fig, [x, 0.71, cw, ch], lbl, val, sub, bg)

    # 5 timing KPI tiles — second row
    cards2 = [
        ("After-Hours %",  _fmt(snap.get("after_hours_pct"), 1, "%"),   "informational", DARK),
        ("AHT Mail",       _fmt(snap.get("aht_mail"), 1, " min"),
         f"BM ≤{benchmarks.get('aht_min', 30)} min", ORANGE),
        ("AHT Chat",       _fmt(snap.get("aht_chat"), 1, " min"),
         f"BM ≤{benchmarks.get('aht_min', 30)} min", DARK),
        ("FRT Mail",       _fmt(snap.get("frt_mail"), 1, " min"),
         f"BM ≤{benchmarks.get('mail_frt_min', 60)} min", ORANGE),
        ("FRT Chat",       _fmt(snap.get("frt_chat"), 2, " min"),
         f"BM ≤{benchmarks.get('chat_frt_min', 1)} min", GREEN),
    ]
    for i, (lbl, val, sub, bg) in enumerate(cards2):
        x = gap + i * (cw + gap)
        _kpi_tile(fig, [x, 0.515, cw, ch], lbl, val, sub, bg)

    # KPI glossary box
    ax_gloss = fig.add_axes([0.02, 0.365, 0.58, 0.135])
    ax_gloss.axis("off"); _fill(ax_gloss, LGRAY)
    glossary = ("FCR (First Contact Resolution): % of contacts resolved without callback or follow-up.\n"
                "AHT (Avg Handling Time): Time from contact start to close.\n"
                "FRT (First Response Time): Time to first agent reply.\n"
                "Transfer Rate: % of contacts escalated out-of-scope.")
    ax_gloss.text(0.025, 0.78, "KPI GLOSSARY", fontsize=8, fontweight="bold",
                  color=ORANGE, transform=ax_gloss.transAxes)
    ax_gloss.text(0.025, 0.6, glossary, fontsize=7.5, color=BLACK, va="top",
                  transform=ax_gloss.transAxes, linespacing=1.6)

    # Benchmark reference table
    ax_bm = fig.add_axes([0.62, 0.365, 0.36, 0.135])
    bm_rows = [
        ["Chat FRT", f"≤ {benchmarks.get('chat_frt_min', 1)} min"],
        ["Mail FRT", f"≤ {benchmarks.get('mail_frt_min', 60)} min"],
        ["AHT",      f"≤ {benchmarks.get('aht_min', 30)} min"],
        ["FCR",      f"≥ {benchmarks.get('fcr_pct', 80)}%"],
        ["Escalation", f"≤ {benchmarks.get('escalation_rate_pct', 5)}%"],
    ]
    _draw_table(ax_bm, ["KPI", "Target"], bm_rows,
                hdr_color=DARK, col_widths=[0.55, 0.45], fontsize=7.5)

    # YTD strip
    if ytd:
        ax_ytd = fig.add_axes([0.02, 0.245, 0.96, 0.11])
        ax_ytd.axis("off"); _fill(ax_ytd, "#FFF3EB")
        ax_ytd.text(0.01, 0.72, "YEAR-TO-DATE", fontsize=9,
                    fontweight="bold", color=ORANGE, transform=ax_ytd.transAxes)
        ytd_txt = (f"({ytd.get('fiscal_year', '')}  ·  {ytd.get('weeks_count', 0)} weeks)     "
                   f"Volume: {ytd.get('total_volume', 0):,}     FCR: {ytd.get('fcr_pct', 0)}%     "
                   f"Transfer: {ytd.get('transfer_rate_pct', 0)}%     "
                   f"After-Hours: {ytd.get('after_hours_pct', 0)}%     "
                   f"AHT Mail: {ytd.get('avg_aht_mail', 0)} min     "
                   f"FRT Chat: {ytd.get('avg_frt_chat', 0)} min")
        ax_ytd.text(0.01, 0.25, ytd_txt, fontsize=9, color=BLACK,
                    transform=ax_ytd.transAxes)

    # Insight box
    fcr = snap.get("fcr_pct") or 0
    tr  = snap.get("transfer_rate_pct") or 0
    insights = []
    insights.append(f"FCR {fcr:.1f}% — {'meeting' if fcr >= 80 else 'BELOW'} the ≥80% benchmark.")
    insights.append(f"Transfer rate {tr:.1f}% — {'within' if tr <= 5 else 'ABOVE'} the ≤5% target.")
    ax_ins = fig.add_axes([0.02, 0.15, 0.96, 0.085])
    ax_ins.axis("off")
    _fill(ax_ins, "#FFF3EB" if (fcr >= 80 and tr <= 5) else "#FDECEA")
    ax_ins.text(0.01, 0.65, "WEEK INSIGHT", fontsize=8,
                fontweight="bold", color=ORANGE, transform=ax_ins.transAxes)
    ax_ins.text(0.01, 0.18, "   |   ".join(insights), fontsize=8.5,
                color=BLACK, transform=ax_ins.transAxes)

    pdf.savefig(fig, bbox_inches="tight")
    plt.close(fig)


# ── Page 3: Weekly Trends ────────────────────────────────────────────────────

def _page_weekly_trends(pdf, snap, weekly_kpis, benchmarks):
    fig = _new_fig("Weekly Volume & Performance Trends",
                   "Last 12 weeks — Volume, FCR and Transfer Rate",
                   snap.get("week_label", ""))

    wk = weekly_kpis[-12:] if len(weekly_kpis) >= 12 else weekly_kpis
    if not wk:
        pdf.savefig(fig, bbox_inches="tight")
        plt.close(fig)
        return

    labels = [w.get("Week_Label", "") for w in wk]
    mail   = [w.get("Mail_Volume", 0) or 0 for w in wk]
    chat   = [w.get("Chat_Volume", 0) or 0 for w in wk]
    fcr    = [w.get("FCR_Pct", 0) or 0 for w in wk]
    trans  = [w.get("Transfer_Rate_Pct", 0) or 0 for w in wk]
    x      = np.arange(len(labels))

    # Volume bar chart
    ax1 = fig.add_axes([0.05, 0.13, 0.42, 0.73])
    ax1.set_facecolor(LGRAY)
    ax1.bar(x - 0.2, mail, 0.38, label="Mail", color=ORANGE, alpha=0.88, zorder=3)
    ax1.bar(x + 0.2, chat, 0.38, label="Chat", color=DARK,   alpha=0.88, zorder=3)
    ax1.set_xticks(x)
    ax1.set_xticklabels(labels, rotation=35, fontsize=7, ha="right")
    ax1.tick_params(axis="y", labelsize=7)
    ax1.set_title("Weekly Contact Volume — Mail vs Chat", fontsize=10, color=BLACK, pad=6)
    ax1.legend(fontsize=8, framealpha=0.8)
    ax1.yaxis.grid(True, alpha=0.4, zorder=0)
    ax1.set_axisbelow(True)
    _spines_off(ax1)

    # FCR + Transfer line chart
    ax2 = fig.add_axes([0.55, 0.13, 0.42, 0.73])
    ax2.set_facecolor(LGRAY)
    ax2.plot(x, fcr,   "-o", color=GREEN, lw=2, ms=4, label="FCR %", zorder=3)
    ax2.plot(x, trans, "-s", color=RED,   lw=2, ms=4, label="Transfer %", zorder=3)
    ax2.axhline(benchmarks.get("fcr_pct", 80), color=GREEN,
                ls="--", lw=1, alpha=0.6, label="FCR BM 80%")
    ax2.axhline(benchmarks.get("escalation_rate_pct", 5), color=RED,
                ls="--", lw=1, alpha=0.6, label="Trans BM 5%")
    ax2.set_xticks(x)
    ax2.set_xticklabels(labels, rotation=35, fontsize=7, ha="right")
    ax2.tick_params(axis="y", labelsize=7)
    ax2.set_title("FCR % and Transfer Rate Trend", fontsize=10, color=BLACK, pad=6)
    ax2.legend(fontsize=7.5, ncol=2, framealpha=0.8)
    ax2.yaxis.grid(True, alpha=0.4, zorder=0)
    ax2.set_axisbelow(True)
    _spines_off(ax2)

    pdf.savefig(fig, bbox_inches="tight")
    plt.close(fig)


# ── Page 4: Channel Performance ──────────────────────────────────────────────

def _page_channels(pdf, snap, weekly_kpis, benchmarks):
    fig = _new_fig("Channel Performance — Mail vs Chat",
                   "Last 10 weeks: AHT, FRT, FCR by channel",
                   snap.get("week_label", ""))

    recent = weekly_kpis[-10:] if len(weekly_kpis) >= 10 else weekly_kpis

    # FRT trend line chart (top half)
    ax_frt = fig.add_axes([0.05, 0.52, 0.55, 0.35])
    if recent:
        labels = [w.get("Week_Label", "") for w in recent]
        x = np.arange(len(labels))
        frt_mail = [w.get("Avg_FRT_Mail_min", 0) or 0 for w in recent]
        frt_chat = [w.get("Avg_FRT_Chat_min", 0) or 0 for w in recent]
        ax_frt.set_facecolor(LGRAY)
        ax_frt.plot(x, frt_mail, "-o", color=ORANGE, lw=2, ms=4, label="FRT Mail")
        ax_frt.plot(x, frt_chat, "-s", color=DARK,   lw=2, ms=4, label="FRT Chat")
        ax_frt.axhline(benchmarks.get("mail_frt_min", 60), color=ORANGE,
                       ls="--", lw=1, alpha=0.5, label=f"Mail BM {benchmarks.get('mail_frt_min',60)}m")
        ax_frt.axhline(benchmarks.get("chat_frt_min", 1), color=GREEN,
                       ls="--", lw=1, alpha=0.5, label=f"Chat BM {benchmarks.get('chat_frt_min',1)}m")
        ax_frt.set_xticks(x)
        ax_frt.set_xticklabels(labels, rotation=30, fontsize=7, ha="right")
        ax_frt.tick_params(axis="y", labelsize=7)
        ax_frt.set_title("First Response Time Trend (min)", fontsize=9, color=BLACK)
        ax_frt.legend(fontsize=7, ncol=2, framealpha=0.8)
        ax_frt.yaxis.grid(True, alpha=0.4)
        ax_frt.set_axisbelow(True)
        _spines_off(ax_frt)

    # Current week channel comparison table (top-right)
    ax_cur = fig.add_axes([0.63, 0.52, 0.35, 0.35])
    cur_hdrs = ["KPI", "Chat", "Mail", "Benchmark"]
    cur_rows = [
        ["FRT",  _fmt(snap.get("frt_chat"), 2, "m"),  _fmt(snap.get("frt_mail"), 1, "m"),
         f"C≤{benchmarks.get('chat_frt_min',1)}  M≤{benchmarks.get('mail_frt_min',60)}"],
        ["AHT",  _fmt(snap.get("aht_chat"), 1, "m"),  _fmt(snap.get("aht_mail"), 1, "m"),
         f"≤{benchmarks.get('aht_min',30)} min"],
        ["Res",  _fmt(snap.get("res_chat"), 1, "m"),  _fmt(snap.get("res_mail"), 1, "m"),
         "≤30 min"],
        ["FCR",  "100%",  _fmt(snap.get("fcr_pct"), 1, "%"), "≥80%"],
        ["Transfer", _fmt(snap.get("transfer_rate_pct"), 1, "%"), "—", "≤5%"],
    ]
    _draw_table(ax_cur, cur_hdrs, cur_rows, hdr_color=ORANGE,
                col_widths=[0.22, 0.22, 0.22, 0.34], fontsize=8)
    ax_cur.set_title("Current Week vs Benchmark", fontsize=8.5,
                     color=BLACK, pad=4, loc="left")

    # Weekly detail table (bottom half)
    ax_tbl = fig.add_axes([0.02, 0.06, 0.96, 0.42])
    if recent:
        hdrs = ["Week", "Mail Vol", "Chat Vol", "FCR%", "AHT Mail", "AHT Chat",
                "FRT Mail", "FRT Chat", "Transfer%"]
        rows = [[
            w.get("Week_Label", ""),
            w.get("Mail_Volume", 0),
            w.get("Chat_Volume", 0),
            _fmt(w.get("FCR_Pct"), 1, "%"),
            _fmt(w.get("Avg_AHT_Mail_min"), 1, "m"),
            _fmt(w.get("Avg_AHT_Chat_min"), 1, "m"),
            _fmt(w.get("Avg_FRT_Mail_min"), 1, "m"),
            _fmt(w.get("Avg_FRT_Chat_min"), 2, "m"),
            _fmt(w.get("Transfer_Rate_Pct"), 1, "%"),
        ] for w in recent]
        _draw_table(ax_tbl, hdrs, rows, hdr_color=DARK,
                    col_widths=[1.8, 1.0, 1.0, 0.9, 1.1, 1.1, 1.1, 1.1, 1.1],
                    fontsize=8)

    pdf.savefig(fig, bbox_inches="tight")
    plt.close(fig)


# ── Page 5: Brand Analysis ────────────────────────────────────────────────────

def _page_brand_analysis(pdf, snap, brand_analysis):
    fig = _new_fig("Brand Issue Analysis",
                   "New vs Repeated Issues — root-cause tracking by brand",
                   snap.get("week_label", ""))

    summary = brand_analysis.get("summary", {})
    new_n = summary.get("new_issues", 0) or 0
    rep_n = summary.get("repeated_issues", 0) or 0
    new_p = summary.get("new_pct", 0) or 0
    rep_p = summary.get("repeated_pct", 0) or 0

    # Summary KPI tiles
    tiles = [
        ("Total Issues",     str(summary.get("total_issues", 0)), "",    ORANGE),
        ("New Issues",       f"{new_p:.1f}%",  f"{new_n} combos", GREEN),
        ("Repeated Issues",  f"{rep_p:.1f}%",  f"{rep_n} recur",  RED),
    ]
    cw, ch = 0.18, 0.16
    for i, (lbl, val, sub, bg) in enumerate(tiles):
        _kpi_tile(fig, [0.02 + i * 0.21, 0.78, cw, ch], lbl, val, sub, bg)

    # Note box
    ax_note = fig.add_axes([0.65, 0.78, 0.33, 0.16])
    ax_note.axis("off"); _fill(ax_note, LGRAY)
    ax_note.text(0.02, 0.78, "INTERPRETATION", fontsize=8, fontweight="bold",
                 color=ORANGE, transform=ax_note.transAxes)
    ax_note.text(0.02, 0.38,
                 "New = first occurrence for Brand+Category.\n"
                 "Repeated = same combo appeared before.\n"
                 "High repeat % → investigate root cause.",
                 fontsize=7.5, color=BLACK, transform=ax_note.transAxes)

    # Pie chart
    ax_pie = fig.add_axes([0.02, 0.10, 0.22, 0.62])
    ax_pie.axis("off")
    if new_n + rep_n > 0:
        wedges, _, autos = ax_pie.pie(
            [max(new_n, 0.001), max(rep_n, 0.001)],
            colors=[GREEN, RED], autopct="%1.1f%%", startangle=90,
            wedgeprops={"width": 0.55},
            textprops={"fontsize": 9})
        ax_pie.legend(wedges, ["New", "Repeated"], loc="lower center",
                      fontsize=8, ncol=2, bbox_to_anchor=(0.5, -0.05), framealpha=0.7)
    ax_pie.set_title("New vs Repeated", fontsize=9, color=BLACK, pad=4)

    # Brand table
    brands = brand_analysis.get("brands", [])[:16]
    ax_tbl = fig.add_axes([0.27, 0.10, 0.71, 0.62])
    if brands:
        hdrs = ["Brand", "Total", "New", "Repeat", "Repeat%", "Top Category"]
        rows = [[
            b.get("Brand Name", ""),
            b.get("Total_Issues", b.get("Total", 0)),
            b.get("New_Issues",   b.get("New", 0)),
            b.get("Repeated_Issues", b.get("Repeated", 0)),
            f"{b.get('Repeated_Pct', 0):.1f}%",
            str(b.get("Top_Category", ""))[:32],
        ] for b in brands]
        _draw_table(ax_tbl, hdrs, rows, hdr_color=ORANGE,
                    col_widths=[2.8, 0.8, 0.8, 0.9, 0.9, 2.5], fontsize=8,
                    col_aligns=["left", "center", "center", "center", "center", "left"])

    pdf.savefig(fig, bbox_inches="tight")
    plt.close(fig)


# ── Page 6: Transferred Requests ─────────────────────────────────────────────

def _page_transferred(pdf, snap, transferred):
    fig = _new_fig("Transferred Request Tracker",
                   "Out-of-scope cases — resolution tracking & SLA compliance",
                   snap.get("week_label", ""))

    summary = transferred.get("summary", {})
    total    = summary.get("total", 0) or 0
    done     = summary.get("completed", 0) or 0
    open_n   = summary.get("open", 0) or 0
    comp_pct = summary.get("completion_pct", 0) or 0
    avg_res  = summary.get("avg_res_hrs", 0) or 0

    tiles = [
        ("Total",          str(total),              "",          ORANGE),
        ("Completed",      str(done),               "",          GREEN),
        ("Open / Pending", str(open_n),             "",          RED),
        ("Completion %",   f"{comp_pct:.1f}%",     "target ≥80%",
         GREEN if comp_pct >= 80 else RED),
        ("Avg Resolution", f"{avg_res:.1f}h",       "hours",     DARK),
    ]
    n = len(tiles)
    cw, ch = 0.17, 0.155
    gap = (1 - n * cw) / (n + 1)
    for i, (lbl, val, sub, bg) in enumerate(tiles):
        _kpi_tile(fig, [gap + i * (cw + gap), 0.78, cw, ch], lbl, val, sub, bg)

    # Status donut
    ax_d = fig.add_axes([0.67, 0.10, 0.30, 0.62])
    ax_d.axis("off")
    if total > 0:
        wedges, _, autos = ax_d.pie(
            [max(done, 0.001), max(open_n, 0.001)],
            colors=[GREEN, RED], autopct="%1.0f%%", startangle=90,
            wedgeprops={"width": 0.55},
            textprops={"fontsize": 10})
        ax_d.legend(wedges, ["Completed", "Open"], loc="lower center",
                    fontsize=8.5, ncol=2, bbox_to_anchor=(0.5, -0.04), framealpha=0.7)
    ax_d.set_title("Resolution Status", fontsize=10, color=BLACK, pad=4)

    # Open cases table
    open_cases = transferred.get("open_cases", [])[:14]
    ax_tbl = fig.add_axes([0.02, 0.10, 0.63, 0.62])
    hdrs = ["Brand", "Week", "Category", "Status", "SLA", "Next Step"]
    rows = [[
        c.get("Brand Name", ""),
        c.get("Week_Label", c.get("Week", "")),
        c.get("Category", ""),
        c.get("Status", ""),
        c.get("SLA", ""),
        str(c.get("Next Step", "") or "")[:30],
    ] for c in open_cases]
    _draw_table(ax_tbl, hdrs, rows, hdr_color=RED,
                col_widths=[1.9, 0.8, 2.0, 1.9, 0.9, 2.3], fontsize=8,
                col_aligns=["left", "center", "left", "left", "center", "left"])
    ax_tbl.set_title(f"Open Cases ({len(open_cases)} shown)", fontsize=9,
                     color=RED, pad=4, loc="left", fontweight="bold")

    pdf.savefig(fig, bbox_inches="tight")
    plt.close(fig)


# ── Page 7: Business Value KPIs ──────────────────────────────────────────────

def _page_bv(pdf, snap, bv, benchmarks):
    fig = _new_fig("Business Value KPIs",
                   "Strategic metrics quantifying iOPEX value to The Home Depot",
                   snap.get("week_label", ""))

    kpi_defs = [
        ("Escalation Avoidance",
         _fmt(bv.get("escalation_avoidance_pct"), 1, "%"), "≥ 95%",
         "% of contacts handled in-house without escalation", GREEN),
        ("Issue Recurrence Rate",
         _fmt(bv.get("issue_recurrence_rate_pct"), 1, "%"), "≤ 20%",
         "% of issues repeated for same brand+category", RED),
        ("First-Touch Resolution",
         _fmt(bv.get("first_touch_resolution_pct"), 1, "%"), "≥ 80%",
         "% resolved on first contact — no follow-up needed", GREEN),
        ("Chat Responsiveness",
         _fmt(bv.get("chat_responsiveness_idx"), 1, "%"), "≥ 100%",
         "Chat FRT vs 1-min benchmark (>100% = beating target)", ORANGE),
        ("Transferred Resolution",
         _fmt(bv.get("transferred_resolution_pct"), 1, "%"), "≥ 80%",
         "% of transferred tickets resolved within SLA", GREEN),
        ("After-Hours Coverage",
         _fmt(bv.get("after_hours_coverage_pct"), 1, "%"), "Info only",
         "% of contacts outside business hours", DARK),
        ("Operational Efficiency",
         _fmt(bv.get("operational_efficiency_pct"), 1, "%"), "≥ 80%",
         "% of contacts meeting both AHT & FRT targets", ORANGE),
        ("Brand Engagement",
         _fmt(bv.get("brand_engagement_score"), 1, "%"), "Info only",
         "Breadth of brand coverage (unique/total × 100)", DARK),
    ]

    cw, ch, gap = 0.22, 0.21, 0.02
    row_gap = 0.04
    for i, (name, val, target, desc, bg) in enumerate(kpi_defs):
        row, col = i // 4, i % 4
        x = 0.02 + col * (cw + gap)
        y = 0.67 - row * (ch + row_gap)
        ax = fig.add_axes([x, y, cw, ch])
        ax.axis("off"); _fill(ax, bg)
        ax.text(0.5, 0.88, name, ha="center", va="center", transform=ax.transAxes,
                fontsize=8, color=WHITE, fontweight="bold")
        ax.text(0.5, 0.60, str(val), ha="center", va="center", transform=ax.transAxes,
                fontsize=20, color=WHITE, fontweight="bold")
        ax.text(0.5, 0.36, f"Target: {target}", ha="center", va="center",
                transform=ax.transAxes, fontsize=7.5, color=WHITE, style="italic")
        ax.text(0.5, 0.14, desc, ha="center", va="center",
                transform=ax.transAxes, fontsize=6.5, color=WHITE)

    # Value statement
    ax_vs = fig.add_axes([0.02, 0.06, 0.96, 0.10])
    ax_vs.axis("off"); _fill(ax_vs, "#FFF3EB")
    ax_vs.text(0.5, 0.72, "iOPEX Business Value Statement", ha="center",
               fontsize=10, fontweight="bold", color=ORANGE, transform=ax_vs.transAxes)
    ax_vs.text(0.5, 0.25,
               "These KPIs demonstrate the operational intelligence and proactive service management "
               "iOPEX delivers to The Home Depot's OAM function — "
               "reducing escalations, improving resolution speed, and ensuring SLA adherence.",
               ha="center", fontsize=8.5, color=BLACK, transform=ax_vs.transAxes)

    pdf.savefig(fig, bbox_inches="tight")
    plt.close(fig)


# ── Page 8: Analyst Performance ──────────────────────────────────────────────

def _page_analysts(pdf, snap, analysts):
    fig = _new_fig("Analyst Performance",
                   "Individual KPI breakdown — identifying top performers & coaching opportunities",
                   snap.get("week_label", ""))

    if not analysts:
        ax = fig.add_axes([0.1, 0.3, 0.8, 0.5])
        ax.axis("off")
        ax.text(0.5, 0.5, "No analyst data available.", ha="center", va="center",
                fontsize=14, color=GRAY, transform=ax.transAxes)
        pdf.savefig(fig, bbox_inches="tight")
        plt.close(fig)
        return

    # Bar chart (left)
    names  = [a.get("Analyst Name", "")[:18] for a in analysts[:12]]
    totals = [a.get("Total", 0) or 0 for a in analysts[:12]]
    ax_bar = fig.add_axes([0.03, 0.13, 0.33, 0.76])
    ax_bar.set_facecolor(LGRAY)
    y = np.arange(len(names))
    bars = ax_bar.barh(y, totals, color=ORANGE, alpha=0.85)
    ax_bar.set_yticks(y)
    ax_bar.set_yticklabels(names, fontsize=8)
    ax_bar.invert_yaxis()          # rank 1 (first analyst) on top, labels aligned to bars
    ax_bar.tick_params(axis="x", labelsize=7)
    ax_bar.set_title("Contact Volume by Analyst", fontsize=9, color=BLACK, pad=5)
    for bar, v in zip(bars, totals):
        ax_bar.text(bar.get_width() + max(totals) * 0.01, bar.get_y() + bar.get_height() / 2,
                    str(int(v)), va="center", fontsize=7)
    ax_bar.xaxis.grid(True, alpha=0.4)
    ax_bar.set_axisbelow(True)
    _spines_off(ax_bar)

    # Performance table (right)
    ax_tbl = fig.add_axes([0.39, 0.13, 0.59, 0.76])
    hdrs = ["Analyst", "Total", "FCR%", "AHT (min)", "FRT (min)", "Transfer%", "Rating"]
    rows = []
    for a in analysts[:16]:
        fcr = a.get("FCR", 0) or 0
        tr  = a.get("Transfer_Rate_Pct", 0) or 0
        rating = "Strong" if fcr >= 80 and tr <= 5 else ("Developing" if fcr >= 70 else "Review")
        rows.append([
            a.get("Analyst Name", ""),
            a.get("Total", 0),
            _fmt(fcr, 1, "%"),
            _fmt(a.get("Avg_AHT"), 1),
            _fmt(a.get("Avg_FRT"), 1),
            _fmt(tr, 1, "%"),
            rating,
        ])
    _draw_table(ax_tbl, hdrs, rows, hdr_color=ORANGE,
                col_widths=[2.5, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9], fontsize=8)

    # Legend
    ax_leg = fig.add_axes([0.39, 0.06, 0.59, 0.055])
    ax_leg.axis("off"); _fill(ax_leg, LGRAY)
    ax_leg.text(0.01, 0.55,
                "Rating:  Strong = FCR ≥80% AND Transfer ≤5%   |   "
                "Developing = FCR 70–79%   |   Review = FCR < 70%",
                fontsize=7.5, color=BLACK, transform=ax_leg.transAxes, va="center")

    pdf.savefig(fig, bbox_inches="tight")
    plt.close(fig)


# ── Main entry ────────────────────────────────────────────────────────────────

def generate_pdf(data: dict, output_path: str):
    snap     = data.get("snapshot", {})
    ytd      = data.get("ytd") or {}
    bm       = data.get("benchmarks", {})
    wk       = data.get("weekly_kpis", [])
    ba       = data.get("brand_analysis", {})
    tr       = data.get("transferred", {})
    bv       = data.get("business_value_kpis", {})
    analysts = data.get("analysts", [])

    with PdfPages(output_path) as pdf:
        pdf.infodict().update({
            "Title":   "THD OAM Analytics Report",
            "Author":  "iOPEX Technologies",
            "Subject": f"OAM Report Card — {snap.get('week_label', 'Latest')}",
            "Creator": "THD OAM Portal",
        })
        _page_cover(pdf, snap, ytd)
        _page_executive(pdf, snap, ytd, bm)
        _page_weekly_trends(pdf, snap, wk, bm)
        _page_channels(pdf, snap, wk, bm)
        _page_brand_analysis(pdf, snap, ba)
        _page_transferred(pdf, snap, tr)
        _page_bv(pdf, snap, bv, bm)
        _page_analysts(pdf, snap, analysts)
