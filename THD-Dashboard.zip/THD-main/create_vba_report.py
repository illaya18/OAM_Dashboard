"""
THD OAM — VBA-Powered Excel Report Automation Builder
Creates THD_OAM_VBA_Report.xlsm with all data + styling.
VBA code is written to THD_OAM_Macros.bas — import it once via the VBE.

Usage:
  python create_vba_report.py
Then open THD_OAM_VBA_Report.xlsm, press Alt+F11, right-click the project,
choose "Import File…", select THD_OAM_Macros.bas.  Done.
"""
import sys, os
from pathlib import Path
from datetime import datetime
import pandas as pd
import numpy as np
from openpyxl import Workbook
from openpyxl.styles import (PatternFill, Font, Alignment, Border, Side,
                              GradientFill)
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

BASE = Path(r"c:\Users\2243377\OneDrive - Cognizant\Documents\Personal\Illaya")
SRC  = BASE / "Productivity_Sheet.xlsx"
OUT  = BASE / "THD_OAM_VBA_Report.xlsx"
BAS  = BASE / "THD_OAM_Macros.bas"

# ─── THD Colors ───────────────────────────────────────────────────────────────
C_ORANGE      = "F96302"; C_DARK_ORANGE = "CC4E00"; C_BLACK = "000000"
C_WHITE       = "FFFFFF"; C_LIGHT_ORG  = "FFF3EB"; C_PALE_ORG  = "FFE0C8"
C_GRAY_DARK   = "333333"; C_GRAY_MID   = "666666"; C_GRAY_LIGHT = "F5F5F5"
C_GREEN       = "1E8449"; C_AMBER      = "F39C12"; C_RED        = "C0392B"
C_GREEN_LIGHT = "D5F5E3"; C_AMBER_LIGHT = "FDEBD0"; C_RED_LIGHT = "FADBD8"

_SIDE   = Side(style="thin", color=C_GRAY_MID)
_BORDER = Border(left=_SIDE, right=_SIDE, top=_SIDE, bottom=_SIDE)
_FILLS: dict = {}

def fill(hex_color):
    if hex_color not in _FILLS:
        _FILLS[hex_color] = PatternFill(start_color=hex_color,
                                        end_color=hex_color, fill_type="solid")
    return _FILLS[hex_color]

def font(color=C_BLACK, bold=False, size=10, name="Calibri"):
    return Font(color=color, bold=bold, size=size, name=name)

def align(h="center", v="center", wrap=False):
    return Alignment(horizontal=h, vertical=v, wrap_text=wrap)

def cell_style(ws, r, c, value="", bg=C_WHITE, fg=C_BLACK, bold=False,
               size=10, h_align="center", wrap=False, border=True):
    cl = ws.cell(row=r, column=c, value=value)
    cl.fill = fill(bg)
    cl.font = font(fg, bold, size)
    cl.alignment = align(h_align, "center", wrap)
    if border:
        cl.border = _BORDER
    return cl

def merge_range(ws, r1, c1, r2, c2, value="", bg=C_WHITE, fg=C_BLACK,
                bold=False, size=11, h_align="center"):
    ws.merge_cells(start_row=r1, start_column=c1, end_row=r2, end_column=c2)
    cl = ws.cell(row=r1, column=c1, value=value)
    cl.fill = fill(bg); cl.font = font(fg, bold, size)
    cl.alignment = align(h_align, "center")
    return cl


# ─── Load & prepare source data ───────────────────────────────────────────────
print("Loading source data …")
df_bau = pd.read_excel(SRC, sheet_name="BAU")
df_bau.columns = [c.strip() for c in df_bau.columns]
df_bau["_date"] = pd.to_datetime(df_bau.get("Request Received Date"), errors="coerce")
df_bau["_wnum"] = df_bau["Week"].astype(str).str.extract(r"(\d+)")[0].astype(float)
df_bau["_fy"]   = df_bau["_date"].apply(
    lambda d: 2026 if pd.notna(d) and d.year >= 2026 else 2025)
df_bau["Week_Label"] = df_bau.apply(
    lambda r: f"FY{str(int(r['_fy']))[2:]} W{int(r['_wnum']):02d}"
    if pd.notna(r["_wnum"]) else "Unknown", axis=1)
df_bau["Fiscal_Year"] = df_bau["_fy"].astype(int).apply(
    lambda y: f"FY{str(y)[2:]}")
df_bau["Mode"] = df_bau["Mode"].astype(str).str.strip().replace(
    {"Email": "Mail", "email": "Mail"})

df_tr = pd.read_excel(SRC, sheet_name="Transferred")
df_tr.columns = [c.strip() for c in df_tr.columns]
df_tr["_date"] = pd.to_datetime(df_tr.get("Request Received Date"), errors="coerce")
df_tr["_wnum"] = df_tr["Week"].astype(str).str.extract(r"(\d+)")[0].astype(float)
df_tr["_fy"]   = df_tr["_date"].apply(
    lambda d: 2026 if pd.notna(d) and d.year >= 2026 else 2025)
df_tr["Week_Label"] = df_tr.apply(
    lambda r: f"FY{str(int(r['_fy']))[2:]} W{int(r['_wnum']):02d}"
    if pd.notna(r["_wnum"]) else "Unknown", axis=1)
df_tr["Fiscal_Year"] = df_tr["_fy"].astype(int).apply(
    lambda y: f"FY{str(y)[2:]}")
print(f"  BAU: {len(df_bau)} rows   Transferred: {len(df_tr)} rows")

# Unique sorted values for dropdown lists
def _uniq(series_list):
    vals = set()
    for s in series_list:
        vals.update(s.dropna().astype(str).str.strip().unique())
    vals.discard(""); vals.discard("nan"); vals.discard("NaN")
    return sorted(vals)

fiscal_years = _uniq([df_bau["Fiscal_Year"], df_tr["Fiscal_Year"]])
week_labels  = _uniq([df_bau["Week_Label"],  df_tr["Week_Label"]])
brands       = _uniq([df_bau["Brand Name"],  df_tr["Brand Name"]])
channels     = _uniq([df_bau["Mode"]])
categories   = _uniq([df_bau["Category"],    df_tr["Category"]])
statuses     = _uniq([df_tr["Status"]])


# ─── Helper: write DataFrame to a sheet ───────────────────────────────────────
def write_df_sheet(ws, df, export_cols, disp_names=None):
    cols = [c for c in export_cols if c in df.columns]
    if disp_names is None:
        disp_names = {c: c for c in cols}

    for ci, col in enumerate(cols, 1):
        cell_style(ws, 1, ci, disp_names.get(col, col),
                   bg=C_ORANGE, fg=C_WHITE, bold=True, size=10)

    f_even = fill(C_LIGHT_ORG)
    f_odd  = fill(C_WHITE)
    fnt    = font(C_BLACK, False, 9)
    al_l   = align("left",   "center")
    al_c   = align("center", "center")
    brd    = _BORDER
    left_ci = {ci+1 for ci, col in enumerate(cols)
               if col in ("Analyst Name", "Brand Name", "Category", "Sub Category",
                          "Issue", "Resolution Provided", "Next Step",
                          "Recent Update / Follow up", "Work Flow Stage")}

    import datetime as _dt
    for ri, (_, row) in enumerate(df.iterrows(), 2):
        rf = f_even if ri % 2 == 0 else f_odd
        for ci, col in enumerate(cols, 1):
            v = row.get(col)
            if v is pd.NaT or (isinstance(v, float) and np.isnan(v)):
                v = ""
            elif isinstance(v, pd.Timestamp) and pd.notna(v):
                v = v.strftime("%Y-%m-%d")
            elif isinstance(v, bool):
                v = "Yes" if v else "No"
            elif isinstance(v, _dt.time):
                v = v.strftime("%H:%M:%S")
            elif isinstance(v, (_dt.datetime, _dt.date)):
                v = str(v)[:10]
            elif isinstance(v, pd.Timedelta):
                v = str(v)
            elif isinstance(v, (np.integer,)):
                v = int(v)
            elif isinstance(v, (np.floating,)):
                v = float(v)
            c = ws.cell(row=ri, column=ci, value=v)
            c.fill = rf; c.font = fnt
            c.alignment = al_l if ci in left_ci else al_c
            c.border = brd

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(cols))}1"
    for i in range(1, len(cols) + 1):
        ws.column_dimensions[get_column_letter(i)].width = 18
    ws.row_dimensions[1].height = 20


# ─── Helper: add dropdown validation ──────────────────────────────────────────
def add_dropdown(ws, cell_addr, options_list, allow_blank=True):
    """Add in-cell dropdown. options_list is a Python list."""
    if not options_list:
        return
    # Excel validation formula: comma-separated quoted list (max ~255 chars)
    # For long lists write a hidden lookup range instead
    joined = ",".join(str(o) for o in options_list)
    if len(joined) <= 250:
        formula = f'"{joined}"'
    else:
        # Write options to a named range on a hidden helper sheet
        formula = f'"{joined[:250]}"'  # truncate safely

    dv = DataValidation(
        type="list",
        formula1=formula,
        allow_blank=allow_blank,
        showDropDown=False,
        showErrorMessage=False
    )
    ws.add_data_validation(dv)
    dv.add(ws[cell_addr])


# ─── Build Report sheet ───────────────────────────────────────────────────────
def build_report_sheet(ws):
    ws.sheet_view.showGridLines = False

    # Title
    ws.merge_cells("A1:K2")
    c = ws.cell(row=1, column=1,
                value="THE HOME DEPOT  |  OAM Supplier Support — Interactive Report")
    c.fill = fill(C_ORANGE); c.font = font(C_WHITE, True, 16)
    c.alignment = align("center", "center")
    ws.row_dimensions[1].height = 36
    ws.row_dimensions[2].height = 12

    # Filter panel header
    ws.merge_cells("A3:K3")
    c3 = ws.cell(row=3, column=1,
                 value="FILTER PANEL — Select values below, then click the Generate Report button")
    c3.fill = fill(C_DARK_ORANGE); c3.font = font(C_WHITE, True, 11)
    c3.alignment = align("center", "center")
    ws.row_dimensions[3].height = 22

    # Filters: (row, label, default, dropdown_list, named_cell_comment)
    filter_defs = [
        (4,  "Fiscal Year",  "",    ["All"] + fiscal_years,
         "Select 'All' or a specific FY (e.g. FY25, FY26)"),
        (5,  "Week",         "",    ["All"] + week_labels,
         "Select 'All' or a specific week (e.g. FY26 W03)"),
        (6,  "Brand",        "",    ["All"] + brands[:200],   # cap at 200 to stay under Excel limit
         "Filter by supplier brand name"),
        (7,  "Channel",      "",    ["All"] + channels,
         "Mail = email contacts; Chat = Front live chat"),
        (8,  "Category",     "",    ["All"] + categories,
         "Issue category as classified by analyst"),
        (9,  "Status",       "",    ["All"] + statuses,
         "Transferred only: Completed / Working / Waiting etc."),
        (10, "Data Source",  "All", ["All", "BAU", "Transferred"],
         "All = BAU + Transferred; select one to filter"),
    ]

    for row, label, default, opts, comment in filter_defs:
        # Label (cols A-B)
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=2)
        lc = ws.cell(row=row, column=1, value=label)
        lc.fill = fill(C_GRAY_DARK); lc.font = font(C_WHITE, True, 10)
        lc.alignment = align("right", "center")
        ws.row_dimensions[row].height = 22

        # Dropdown cell (col C)
        dc = ws.cell(row=row, column=3, value=default)
        dc.fill = fill(C_LIGHT_ORG)
        dc.font = font(C_ORANGE, True, 10)
        dc.alignment = align("center", "center")
        dc.border = _BORDER
        add_dropdown(ws, f"C{row}", opts)

        # Hint (col D-K)
        ws.merge_cells(start_row=row, start_column=4, end_row=row, end_column=11)
        hc = ws.cell(row=row, column=4, value=comment)
        hc.fill = fill(C_GRAY_LIGHT)
        hc.font = font(C_GRAY_MID, False, 8)
        hc.font = Font(color=C_GRAY_MID, italic=True, size=8, name="Calibri")
        hc.alignment = align("left", "center")

    # Button row (row 11) — styled cells that label the button positions
    ws.row_dimensions[11].height = 10  # small spacer

    # Button placeholders (will be replaced by actual buttons when user imports VBA)
    btn_labels = [
        (12, 1, 3, "▶  GENERATE REPORT",   C_ORANGE,      C_WHITE),
        (12, 5, 7, "✕  CLEAR FILTERS",     C_DARK_ORANGE, C_WHITE),
        (12, 9, 11,"↻  REFRESH DROPDOWNS", C_GRAY_DARK,   C_WHITE),
    ]
    ws.row_dimensions[12].height = 28
    for row, c1, c2, label, bg, fg in btn_labels:
        ws.merge_cells(start_row=row, start_column=c1, end_row=row, end_column=c2)
        bc = ws.cell(row=row, column=c1, value=label)
        bc.fill = fill(bg); bc.font = font(fg, True, 11)
        bc.alignment = align("center", "center"); bc.border = _BORDER

    # Setup note (row 13)
    ws.row_dimensions[13].height = 8
    ws.merge_cells("A13:K13")
    nc = ws.cell(row=13, column=1,
                 value="SETUP: (1) Alt+F11 → right-click project → Import File → select THD_OAM_Macros.bas → Alt+Q  "
                       "(2) Alt+F8 → AddButtons → Run  "
                       "(3) Save as .xlsm  |  See README sheet for full instructions.")
    nc.fill = fill(C_AMBER_LIGHT)
    nc.font = Font(color=C_AMBER, italic=True, size=8, name="Calibri")
    nc.alignment = align("center", "center")
    ws.row_dimensions[13].height = 18

    # Output header (row 14+) — blank, filled at runtime by macro
    ws.merge_cells("A14:K14")
    out_hdr = ws.cell(row=14, column=1,
                      value="← Report output will appear here after clicking Generate Report →")
    out_hdr.fill = fill(C_GRAY_LIGHT)
    out_hdr.font = Font(color=C_GRAY_MID, italic=True, size=10, name="Calibri")
    out_hdr.alignment = align("center", "center")
    ws.row_dimensions[14].height = 20

    # Column widths
    ws.column_dimensions["A"].width = 14
    ws.column_dimensions["B"].width = 14
    ws.column_dimensions["C"].width = 24
    for i in range(4, 12):
        ws.column_dimensions[get_column_letter(i)].width = 16


# ─── Build README sheet ───────────────────────────────────────────────────────
def build_readme(ws):
    ws.sheet_view.showGridLines = False

    rows = [
        ("title", "THD OAM SUPPLIER SUPPORT — VBA AUTOMATED REPORT", ""),
        ("blank", "", ""),
        ("section", "PURPOSE", ""),
        ("text2", "This workbook provides interactive filtered reporting over BAU and Transferred Requests data.",
                  "Filter by Fiscal Year, Week, Brand, Channel, Category, Status, then click Generate Report."),
        ("blank", "", ""),
        ("section", "SHEETS", ""),
        ("row", "Report",        "Interactive dashboard — set filters and click Generate Report."),
        ("row", "BAU_Data",      "BAU source data with Week_Label and Fiscal_Year columns added."),
        ("row", "Transfer_Data", "Transferred source data with Week_Label and Fiscal_Year columns added."),
        ("row", "README",        "This documentation sheet."),
        ("blank", "", ""),
        ("section", "HOW TO ACTIVATE THE BUTTONS (one-time setup)", ""),
        ("step", "Step 1", "Open THD_OAM_VBA_Report.xlsx in Excel."),
        ("step", "Step 2", "Press Alt + F11 to open the Visual Basic Editor (VBE)."),
        ("step", "Step 3", "In the VBE, right-click on 'VBAProject (THD_OAM_VBA_Report)' in the left panel."),
        ("step", "Step 4", "Choose 'Import File…' from the menu."),
        ("step", "Step 5", f"Browse to and select: {BAS.name}  — click Open."),
        ("step", "Step 6", "The module 'THD_OAM_Macros' appears. Press Alt + Q to close VBE."),
        ("step", "Step 7", "In Excel: Developer tab → Macros → select 'AddButtons' → Run.  (Or press Alt+F8, type AddButtons, Run.)"),
        ("step", "Step 8", "Real clickable buttons appear on the Report sheet. Save the file — when Excel asks, choose 'Save as Macro-Enabled Workbook (.xlsm)'."),
        ("blank", "", ""),
        ("section", "ALTERNATIVE — Run macros directly from VBE", ""),
        ("text2", "If you prefer not to import the .bas file:",
                  "In the VBE, insert a new Module (Insert > Module), paste the code from THD_OAM_Macros.bas, then run."),
        ("blank", "", ""),
        ("section", "HOW TO USE THE REPORT", ""),
        ("step", "Step 1", "Go to the Report sheet."),
        ("step", "Step 2", "Select filter values from the orange dropdown cells (C4:C10). Leave blank or 'All' for no filter."),
        ("step", "Step 3", "Click the orange 'GENERATE REPORT' button. Output appears below row 14."),
        ("step", "Step 4", "Click 'CLEAR FILTERS' to reset all selections and remove the output."),
        ("step", "Step 5", "If Productivity_Sheet.xlsx was updated, re-run create_vba_report.py to refresh this workbook."),
        ("blank", "", ""),
        ("section", "FILTER REFERENCE", ""),
        ("row", "Fiscal Year",  "FY25 = Sep-Dec 2025 (Weeks 38-53).  FY26 = Jan 2026+ (Weeks 1-37)."),
        ("row", "Week",         "Format: 'FY26 W03' (fiscal year + zero-padded week number)."),
        ("row", "Brand",        "Supplier/brand name — upper-cased in source data."),
        ("row", "Channel",      "Mail = email via OAM inbox.  Chat = Front platform live chat."),
        ("row", "Category",     "Issue category as classified by the analyst."),
        ("row", "Status",       "Transferred only: Completed | Working | Waiting for Supplier | Kept on HOLD."),
        ("row", "Data Source",  "All = BAU + Transferred.  BAU = BAU only.  Transferred = escalated only."),
        ("blank", "", ""),
        ("section", "KPI GLOSSARY", ""),
        ("row", "FCR",            "First Contact Resolution — % resolved on first interaction. Target: >= 80%."),
        ("row", "AHT",            "Average Handling Time — end-to-end agent time per contact. Target: <= 30 min."),
        ("row", "FRT Chat",       "First Response Time (Chat) — time to first reply. Target: <= 1 min."),
        ("row", "FRT Mail",       "First Response Time (Mail) — time to first reply. Target: <= 60 min."),
        ("row", "Transfer Rate",  "% of contacts escalated to another team. Target: <= 5%."),
        ("row", "After-Hours",    "% of contacts received outside standard business hours."),
        ("row", "SLA",            "Agreed turnaround: 24 hrs | 48 hrs | 3-5 Business Days."),
        ("blank", "", ""),
        ("section", "DATA REFRESH", ""),
        ("row", "Source file",  str(SRC)),
        ("row", "Refresh command", "python create_vba_report.py   (from the Illaya folder)"),
        ("row", "Manual refresh", "Copy-paste new rows into BAU_Data / Transfer_Data sheets."),
        ("blank", "", ""),
        ("section", "SUPPORT", ""),
        ("row", "Prepared by",  "iOPEX Technologies  |  THD OAM Analytics Team"),
        ("row", "Contact",      "abhirami.karthikeyan@cognizant.com"),
        ("row", "Built",        datetime.now().strftime("%d %b %Y")),
    ]

    ws.column_dimensions["A"].width = 32
    ws.column_dimensions["B"].width = 80
    ws.column_dimensions["C"].width = 60

    r = 1
    for kind, a, b in rows:
        if kind == "title":
            ws.merge_cells(f"A{r}:C{r}")
            c = ws.cell(row=r, column=1, value=a)
            c.fill = fill(C_ORANGE); c.font = font(C_WHITE, True, 14)
            c.alignment = align("center", "center")
            ws.row_dimensions[r].height = 30
        elif kind == "section":
            ws.merge_cells(f"A{r}:C{r}")
            c = ws.cell(row=r, column=1, value=a)
            c.fill = fill(C_DARK_ORANGE); c.font = font(C_WHITE, True, 11)
            c.alignment = align("left", "center")
            ws.row_dimensions[r].height = 22
        elif kind == "step":
            cl = ws.cell(row=r, column=1, value=a)
            cl.fill = fill(C_GRAY_DARK); cl.font = font(C_WHITE, True, 10)
            cl.alignment = align("center", "center")
            cr = ws.cell(row=r, column=2, value=b)
            cr.fill = fill(C_LIGHT_ORG); cr.font = font(C_BLACK, False, 10)
            cr.alignment = align("left", "center", True)
            ws.merge_cells(f"B{r}:C{r}")
            ws.row_dimensions[r].height = 20
        elif kind == "row":
            bg = C_LIGHT_ORG if r % 2 == 0 else C_WHITE
            cl = ws.cell(row=r, column=1, value=a)
            cl.fill = fill(bg); cl.font = font(C_BLACK, True, 10)
            cl.alignment = align("left", "center")
            cr = ws.cell(row=r, column=2, value=b)
            cr.fill = fill(bg); cr.font = font(C_BLACK, False, 10)
            cr.alignment = align("left", "center", True)
            ws.merge_cells(f"B{r}:C{r}")
            ws.row_dimensions[r].height = 18
        elif kind == "text2":
            ws.merge_cells(f"A{r}:C{r}")
            c = ws.cell(row=r, column=1, value=a)
            c.fill = fill(C_WHITE); c.font = font(C_BLACK, False, 10)
            c.alignment = align("left", "center", True)
            ws.row_dimensions[r].height = 20
            if b:
                r += 1
                ws.merge_cells(f"A{r}:C{r}")
                c2 = ws.cell(row=r, column=1, value=b)
                c2.fill = fill(C_WHITE); c2.font = font(C_GRAY_MID, False, 10)
                c2.font = Font(color=C_GRAY_MID, italic=True, size=10, name="Calibri")
                c2.alignment = align("left", "center", True)
                ws.row_dimensions[r].height = 18
        elif kind == "blank":
            ws.row_dimensions[r].height = 8
        r += 1


# ─── VBA code (written to .bas file) ─────────────────────────────────────────
VBA_BAS = r"""Attribute VB_Name = "THD_OAM_Macros"
Option Explicit

' ============================================================
'  THD OAM Supplier Support — Report Automation Macros
'  After importing this .bas file, run AddButtons() ONCE to
'  replace the styled-cell placeholders with real clickable
'  Form Control buttons wired to the three macros below.
' ============================================================


' ── AddButtons — run ONCE after importing this .bas file ─────────────────────
Public Sub AddButtons()
    Dim ws As Worksheet: Set ws = ThisWorkbook.Sheets("Report")

    ' Remove existing styled-cell placeholders on row 12
    Dim s As Shape
    For Each s In ws.Shapes
        If s.TopLeftCell.Row = 12 Then s.Delete
    Next s
    ws.Rows(12).ClearContents
    ws.Rows(12).RowHeight = 28

    ' Add real Form Control buttons anchored to their cell ranges
    Dim btn As Button
    Dim rng As Range

    Set rng = ws.Range("A12:C12")
    Set btn = ws.Buttons.Add(rng.Left, rng.Top, rng.Width, rng.Height)
    With btn
        .Caption  = Chr(9654) & "  GENERATE REPORT"
        .OnAction = "GenerateReport"
        .Font.Bold = True: .Font.Size = 11: .Font.Name = "Calibri"
    End With

    Set rng = ws.Range("E12:G12")
    Set btn = ws.Buttons.Add(rng.Left, rng.Top, rng.Width, rng.Height)
    With btn
        .Caption  = Chr(10005) & "  CLEAR FILTERS"
        .OnAction = "ClearFilters"
        .Font.Bold = True: .Font.Size = 11: .Font.Name = "Calibri"
    End With

    Set rng = ws.Range("I12:K12")
    Set btn = ws.Buttons.Add(rng.Left, rng.Top, rng.Width, rng.Height)
    With btn
        .Caption  = Chr(8635) & "  REFRESH DROPDOWNS"
        .OnAction = "RefreshDropdowns"
        .Font.Bold = True: .Font.Size = 11: .Font.Name = "Calibri"
    End With

    MsgBox "Buttons are now active! Save the file as .xlsm to keep macros.", _
           vbInformation, "THD OAM Report"
End Sub

Private Const RPT_SHEET    As String = "Report"
Private Const BAU_SHEET    As String = "BAU_Data"
Private Const TR_SHEET     As String = "Transfer_Data"
Private Const OUT_START    As Long   = 15

Private Const C_FY    As String = "C4"
Private Const C_WEEK  As String = "C5"
Private Const C_BRAND As String = "C6"
Private Const C_CHAN  As String = "C7"
Private Const C_CAT   As String = "C8"
Private Const C_STAT  As String = "C9"
Private Const C_SRC   As String = "C10"

' THD color constants (BGR order for VBA)
Private Const CLR_ORANGE      As Long = &H0262F9
Private Const CLR_DARK_ORANGE As Long = &H004ECC
Private Const CLR_WHITE       As Long = &HFFFFFF
Private Const CLR_BLACK       As Long = &H000000
Private Const CLR_LIGHT_ORG   As Long = &HEBF3FF
Private Const CLR_GRAY_DARK   As Long = &H333333
Private Const CLR_GRAY_LIGHT  As Long = &HF5F5F5
Private Const CLR_GREEN_LIGHT As Long = &HE3F5D5
Private Const CLR_AMBER_LIGHT As Long = &HD0EBFD
Private Const CLR_RED_LIGHT   As Long = &HD8DBFA


' ── Public entry points ───────────────────────────────────────────────────────

Public Sub GenerateReport()
    Application.ScreenUpdating = False
    Application.Calculation = xlCalculationManual
    On Error GoTo ErrHandler

    Dim wsR As Worksheet: Set wsR = ThisWorkbook.Sheets(RPT_SHEET)
    Dim wsB As Worksheet: Set wsB = ThisWorkbook.Sheets(BAU_SHEET)
    Dim wsT As Worksheet: Set wsT = ThisWorkbook.Sheets(TR_SHEET)

    Dim fFY   As String: fFY   = NormVal(wsR.Range(C_FY).Value)
    Dim fWeek As String: fWeek = NormVal(wsR.Range(C_WEEK).Value)
    Dim fBrnd As String: fBrnd = NormVal(wsR.Range(C_BRAND).Value)
    Dim fChan As String: fChan = NormVal(wsR.Range(C_CHAN).Value)
    Dim fCat  As String: fCat  = NormVal(wsR.Range(C_CAT).Value)
    Dim fStat As String: fStat = NormVal(wsR.Range(C_STAT).Value)
    Dim fSrc  As String: fSrc  = NormVal(wsR.Range(C_SRC).Value)

    Dim doBAU As Boolean: doBAU = (fSrc = "ALL" Or fSrc = "BAU" Or fSrc = "")
    Dim doTR  As Boolean: doTR  = (fSrc = "ALL" Or fSrc = "TRANSFERRED" Or fSrc = "")

    ClearOutput wsR

    Dim outRow As Long: outRow = OUT_START
    Dim bauCnt As Long: bauCnt = 0
    Dim trCnt  As Long: trCnt  = 0

    ' -- Title -----------------------------------------------------------------
    WriteTitle wsR, outRow, fFY, fWeek, fBrnd, fChan, fCat, fStat, fSrc
    outRow = outRow + 2

    ' -- BAU section -----------------------------------------------------------
    If doBAU Then
        Dim bauRows() As Long
        bauRows = CollectRows(wsB, fFY, fWeek, fBrnd, fChan, fCat, "")
        bauCnt = UBound(bauRows) + 1
        WriteSection wsR, wsB, bauRows, outRow, "BAU CONTACTS", True
        outRow = outRow + bauCnt + 4
        If bauCnt > 0 Then
            WriteSummary wsR, wsB, bauRows, outRow
            outRow = outRow + 7
        End If
    End If

    ' -- Transferred section ---------------------------------------------------
    If doTR Then
        Dim trRows() As Long
        trRows = CollectRows(wsT, fFY, fWeek, fBrnd, fChan, fCat, fStat)
        trCnt  = UBound(trRows) + 1
        WriteSection wsR, wsT, trRows, outRow, "TRANSFERRED REQUESTS", False
        outRow = outRow + trCnt + 4
    End If

    wsR.Columns.AutoFit
    wsR.Activate: wsR.Range("A1").Select

    MsgBox "Report ready!  BAU: " & bauCnt & " rows   Transferred: " & trCnt & " rows.", _
           vbInformation, "THD OAM Report"
    GoTo Cleanup

ErrHandler:
    MsgBox "Error " & Err.Number & ": " & Err.Description, vbCritical, "Report Error"
Cleanup:
    Application.ScreenUpdating = True
    Application.Calculation = xlCalculationAutomatic
End Sub


Public Sub ClearFilters()
    Dim wsR As Worksheet: Set wsR = ThisWorkbook.Sheets(RPT_SHEET)
    wsR.Range(C_FY).Value   = ""
    wsR.Range(C_WEEK).Value = ""
    wsR.Range(C_BRAND).Value = ""
    wsR.Range(C_CHAN).Value  = ""
    wsR.Range(C_CAT).Value  = ""
    wsR.Range(C_STAT).Value = ""
    wsR.Range(C_SRC).Value  = "All"
    ClearOutput wsR
    MsgBox "Filters cleared.", vbInformation, "THD OAM Report"
End Sub


Public Sub RefreshDropdowns()
    ' Re-build dropdown lists from current data — call after adding new rows
    Dim wsB As Worksheet: Set wsB = ThisWorkbook.Sheets(BAU_SHEET)
    Dim wsT As Worksheet: Set wsT = ThisWorkbook.Sheets(TR_SHEET)
    Dim wsR As Worksheet: Set wsR = ThisWorkbook.Sheets(RPT_SHEET)

    Dim lastB As Long: lastB = wsB.Cells(wsB.Rows.Count, 1).End(xlUp).Row
    Dim lastT As Long: lastT = wsT.Cells(wsT.Rows.Count, 1).End(xlUp).Row

    RebuildDropdown wsR.Range(C_FY),   MergeUniq(wsB, "Fiscal_Year",   lastB, wsT, "Fiscal_Year",   lastT)
    RebuildDropdown wsR.Range(C_WEEK), MergeUniq(wsB, "Week_Label",    lastB, wsT, "Week_Label",    lastT)
    RebuildDropdown wsR.Range(C_BRAND),MergeUniq(wsB, "Brand Name",    lastB, wsT, "Brand Name",    lastT)
    RebuildDropdown wsR.Range(C_CHAN), MergeUniq(wsB, "Mode",          lastB, Nothing, "",          0)
    RebuildDropdown wsR.Range(C_CAT),  MergeUniq(wsB, "Category",      lastB, wsT, "Category",     lastT)
    RebuildDropdown wsR.Range(C_STAT), MergeUniq(Nothing, "",          0,    wsT, "Status",        lastT)
    MsgBox "Dropdowns refreshed.", vbInformation, "THD OAM Report"
End Sub


' ── Private helpers ───────────────────────────────────────────────────────────

Private Function NormVal(v As Variant) As String
    Dim s As String: s = UCase(Trim(CStr(v)))
    If s = "" Or s = "ALL" Then NormVal = "ALL" Else NormVal = s
End Function


Private Function ColIdx(ws As Worksheet, colName As String) As Long
    Dim c As Long
    For c = 1 To ws.UsedRange.Columns.Count
        If LCase(Trim(CStr(ws.Cells(1, c).Value))) = LCase(colName) Then
            ColIdx = c: Exit Function
        End If
    Next c
    ColIdx = 0
End Function


Private Function CollectRows(ws As Worksheet, fFY As String, fWeek As String, _
                              fBrnd As String, fChan As String, fCat As String, _
                              fStat As String) As Long()
    Dim last As Long: last = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    Dim buf() As Long: ReDim buf(last - 2)
    Dim cnt As Long: cnt = 0
    Dim cFY   As Long: cFY   = ColIdx(ws, "Fiscal_Year")
    Dim cWeek As Long: cWeek = ColIdx(ws, "Week_Label")
    Dim cBrnd As Long: cBrnd = ColIdx(ws, "Brand Name")
    Dim cChan As Long: cChan = ColIdx(ws, "Mode")
    Dim cCat  As Long: cCat  = ColIdx(ws, "Category")
    Dim cStat As Long: cStat = ColIdx(ws, "Status")

    Dim i As Long
    For i = 2 To last
        Dim ok As Boolean: ok = True
        If fFY   <> "ALL" And cFY   > 0 Then ok = ok And (UCase(Trim(CStr(ws.Cells(i, cFY).Value)))   = fFY)
        If fWeek <> "ALL" And cWeek > 0 Then ok = ok And (UCase(Trim(CStr(ws.Cells(i, cWeek).Value))) = UCase(fWeek))
        If fBrnd <> "ALL" And cBrnd > 0 Then ok = ok And (UCase(Trim(CStr(ws.Cells(i, cBrnd).Value))) = fBrnd)
        If fChan <> "ALL" And cChan > 0 Then ok = ok And (UCase(Trim(CStr(ws.Cells(i, cChan).Value))) = fChan)
        If fCat  <> "ALL" And cCat  > 0 Then ok = ok And (UCase(Trim(CStr(ws.Cells(i, cCat).Value)))  = fCat)
        If fStat <> "ALL" And cStat > 0 Then ok = ok And (UCase(Trim(CStr(ws.Cells(i, cStat).Value))) = fStat)
        If ok Then buf(cnt) = i: cnt = cnt + 1
    Next i
    If cnt = 0 Then ReDim buf(-1) Else ReDim Preserve buf(cnt - 1)
    CollectRows = buf
End Function


Private Sub WriteTitle(wsR As Worksheet, outRow As Long, _
                        fFY As String, fWeek As String, fBrnd As String, _
                        fChan As String, fCat As String, fStat As String, fSrc As String)
    Dim summary As String
    If fFY   <> "ALL" Then summary = summary & "FY=" & fFY & "  "
    If fWeek <> "ALL" Then summary = summary & "Week=" & fWeek & "  "
    If fBrnd <> "ALL" Then summary = summary & "Brand=" & fBrnd & "  "
    If fChan <> "ALL" Then summary = summary & "Chan=" & fChan & "  "
    If fCat  <> "ALL" Then summary = summary & "Cat=" & fCat & "  "
    If fStat <> "ALL" Then summary = summary & "Status=" & fStat & "  "
    If summary = "" Then summary = "All Data (no filters)"
    summary = Trim(summary) & "  |  Source: " & IIf(fSrc = "ALL" Or fSrc = "", "BAU + Transferred", fSrc)

    With wsR.Range("A" & outRow & ":K" & outRow)
        .Merge: .Value = "THE HOME DEPOT  |  OAM  — " & summary
        .Interior.Color = CLR_ORANGE
        .Font.Color = CLR_WHITE: .Font.Bold = True: .Font.Size = 12
        .HorizontalAlignment = xlCenter: .RowHeight = 24
    End With
End Sub


Private Sub WriteSection(wsR As Worksheet, wsSrc As Worksheet, rows() As Long, _
                          outRow As Long, title As String, isBAU As Boolean)
    Dim cnt As Long: cnt = UBound(rows) + 1
    With wsR.Range("A" & outRow & ":K" & outRow)
        .Merge: .Value = title & "  (" & cnt & " rows)"
        .Interior.Color = IIf(isBAU, CLR_DARK_ORANGE, &H922B21)
        .Font.Color = CLR_WHITE: .Font.Bold = True: .Font.Size = 11
        .HorizontalAlignment = xlCenter: .RowHeight = 22
    End With
    outRow = outRow + 1

    If cnt = 0 Then
        wsR.Cells(outRow, 1).Value = "(No rows matched the selected filters)"
        Exit Sub
    End If

    Dim showCols() As String, dispNames() As String
    If isBAU Then
        showCols  = Split("Week_Label,Fiscal_Year,Brand Name,Mode,Category,Sub Category,First contact resolution,Transfered,AHT,Resolution,After-Hours,Analyst Name", ",")
        dispNames = Split("Week,FY,Brand,Channel,Category,Sub-Cat,FCR,Transferred,AHT,Resolution,After-Hrs,Analyst", ",")
    Else
        showCols  = Split("Week_Label,Fiscal_Year,Brand Name,Mode,Category,Status,SLA,Next Step,Recent Update / Follow up,Analyst Name", ",")
        dispNames = Split("Week,FY,Brand,Channel,Category,Status,SLA,Next Step,Last Update,Analyst", ",")
    End If

    Dim ci As Long
    For ci = 0 To UBound(showCols)
        With wsR.Cells(outRow, ci + 1)
            .Value = dispNames(ci)
            .Interior.Color = CLR_ORANGE: .Font.Color = CLR_WHITE
            .Font.Bold = True: .Font.Size = 10
            .HorizontalAlignment = xlCenter
            .Borders.LineStyle = xlContinuous
        End With
    Next ci
    outRow = outRow + 1

    Dim srcCols() As Long: ReDim srcCols(UBound(showCols))
    For ci = 0 To UBound(showCols)
        srcCols(ci) = ColIdx(wsSrc, showCols(ci))
    Next ci

    Dim ri As Long
    For ri = 0 To UBound(rows)
        Dim bg As Long: bg = IIf(ri Mod 2 = 0, CLR_LIGHT_ORG, CLR_WHITE)
        For ci = 0 To UBound(showCols)
            Dim v As Variant
            v = IIf(srcCols(ci) > 0, wsSrc.Cells(rows(ri), srcCols(ci)).Value, "")
            With wsR.Cells(outRow + ri, ci + 1)
                .Value = v: .Interior.Color = bg
                .Font.Size = 9: .Borders.LineStyle = xlContinuous
                .Borders.Color = &H666666
            End With
        Next ci
    Next ri
End Sub


Private Sub WriteSummary(wsR As Worksheet, wsB As Worksheet, _
                          rows() As Long, outRow As Long)
    With wsR.Range("A" & outRow & ":K" & outRow)
        .Merge: .Value = "BAU SUMMARY — filtered selection"
        .Interior.Color = CLR_GRAY_DARK: .Font.Color = CLR_WHITE
        .Font.Bold = True: .Font.Size = 11: .HorizontalAlignment = xlCenter
    End With
    outRow = outRow + 1

    Dim cFCR  As Long: cFCR  = ColIdx(wsB, "First contact resolution")
    Dim cMode As Long: cMode = ColIdx(wsB, "Mode")
    Dim cTR   As Long: cTR   = ColIdx(wsB, "Transfered")

    Dim total As Long: total = UBound(rows) + 1
    Dim fcr As Long, mail As Long, chat As Long, trans As Long
    Dim i As Long
    For i = 0 To UBound(rows)
        If UCase(Trim(CStr(wsB.Cells(rows(i), cFCR).Value)))  = "YES"  Then fcr   = fcr + 1
        If UCase(Trim(CStr(wsB.Cells(rows(i), cMode).Value))) = "MAIL" Then mail  = mail + 1 Else chat = chat + 1
        If UCase(Trim(CStr(wsB.Cells(rows(i), cTR).Value)))   = "YES"  Then trans = trans + 1
    Next i

    Dim stats(3, 1) As Variant
    stats(0, 0) = "Total Contacts":  stats(0, 1) = total
    stats(1, 0) = "FCR Rate":        stats(1, 1) = Format(fcr / total * 100, "0.0") & "%"
    stats(2, 0) = "Mail / Chat":     stats(2, 1) = mail & " / " & chat
    stats(3, 0) = "Transfer Rate":   stats(3, 1) = Format(trans / total * 100, "0.0") & "%"

    Dim si As Long
    For si = 0 To 3
        Dim col As Long: col = si * 2 + 1
        With wsR.Cells(outRow, col)
            .Value = stats(si, 0): .Interior.Color = CLR_ORANGE
            .Font.Color = CLR_WHITE: .Font.Bold = True: .Font.Size = 9
            .Borders.LineStyle = xlContinuous
        End With
        With wsR.Cells(outRow, col + 1)
            .Value = stats(si, 1): .Interior.Color = CLR_LIGHT_ORG
            .Font.Bold = True: .Font.Size = 10: .Borders.LineStyle = xlContinuous
        End With
    Next si
End Sub


Private Sub ClearOutput(wsR As Worksheet)
    Dim last As Long: last = wsR.Cells(wsR.Rows.Count, 1).End(xlUp).Row
    If last >= OUT_START Then wsR.Rows(OUT_START & ":" & last).Delete
End Sub


Private Function MergeUniq(ws1 As Object, col1 As String, last1 As Long, _
                             ws2 As Object, col2 As String, last2 As Long) As String
    Dim d As Object: Set d = CreateObject("Scripting.Dictionary")
    Dim i As Long, ci As Long, v As String
    If Not ws1 Is Nothing And last1 > 1 Then
        ci = ColIdx(ws1, col1)
        If ci > 0 Then
            For i = 2 To last1
                v = Trim(CStr(ws1.Cells(i, ci).Value))
                If Len(v) > 0 And v <> "nan" Then d(v) = 1
            Next i
        End If
    End If
    If Not ws2 Is Nothing And last2 > 1 Then
        ci = ColIdx(ws2, col2)
        If ci > 0 Then
            For i = 2 To last2
                v = Trim(CStr(ws2.Cells(i, ci).Value))
                If Len(v) > 0 And v <> "nan" Then d(v) = 1
            Next i
        End If
    End If
    Dim keys() As String: ReDim keys(d.Count - 1)
    Dim k As Long: k = 0
    Dim key As Variant
    For Each key In d.Keys: keys(k) = CStr(key): k = k + 1: Next key
    ' Sort
    Dim j As Long, tmp As String
    For i = 0 To UBound(keys) - 1
        For j = 0 To UBound(keys) - 1 - i
            If keys(j) > keys(j+1) Then tmp = keys(j): keys(j) = keys(j+1): keys(j+1) = tmp
        Next j
    Next i
    MergeUniq = "All," & Join(keys, ",")
End Function


Private Sub RebuildDropdown(rng As Range, listStr As String)
    With rng.Validation
        .Delete
        If Len(listStr) > 0 Then
            .Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, _
                 Operator:=xlBetween, Formula1:="""" & listStr & """"
            .IgnoreBlank = True: .InCellDropdown = True
        End If
    End With
End Sub
"""


# ─── Main ─────────────────────────────────────────────────────────────────────
def main():
    print("Building workbook …")
    wb = Workbook()
    wb.template = False

    # -- Report sheet ----------------------------------------------------------
    ws_rpt = wb.active
    ws_rpt.title = "Report"
    ws_rpt.sheet_properties.tabColor = C_ORANGE
    ws_rpt.sheet_view.showGridLines = False
    build_report_sheet(ws_rpt)

    # -- BAU_Data sheet --------------------------------------------------------
    print("  Writing BAU_Data …")
    ws_bau = wb.create_sheet("BAU_Data")
    ws_bau.sheet_properties.tabColor = C_DARK_ORANGE
    ws_bau.sheet_view.showGridLines = False
    bau_export = [c for c in [
        "Week_Label", "Fiscal_Year", "Request Received Date", "Analyst Name",
        "Mode", "Brand Name", "Category", "Sub Category", "Issue",
        "First contact resolution", "Transfered", "AHT", "Resolution",
        "First Response Time", "After-Hours", "Work Flow Stage", "Resolution Provided"
    ] if c in df_bau.columns]
    write_df_sheet(ws_bau, df_bau, bau_export)

    # -- Transfer_Data sheet ---------------------------------------------------
    print("  Writing Transfer_Data …")
    ws_tr = wb.create_sheet("Transfer_Data")
    ws_tr.sheet_properties.tabColor = "922B21"
    ws_tr.sheet_view.showGridLines = False
    tr_export = [c for c in [
        "Week_Label", "Fiscal_Year", "Request Received Date", "Analyst Name",
        "Mode", "Brand Name", "Category", "Sub Category", "Issue",
        "Status", "SLA", "Resolution Time", "Next Step",
        "Recent Update / Follow up", "Work Flow Stage"
    ] if c in df_tr.columns]
    write_df_sheet(ws_tr, df_tr, tr_export)

    # -- README sheet ----------------------------------------------------------
    print("  Writing README …")
    ws_readme = wb.create_sheet("README")
    ws_readme.sheet_properties.tabColor = C_GRAY_MID
    ws_readme.sheet_view.showGridLines = False
    build_readme(ws_readme)

    # Save as XLSX (openpyxl cannot create .xlsm from scratch;
    # after importing THD_OAM_Macros.bas, Excel will prompt to re-save as .xlsm)
    print(f"  Saving {OUT.name} …")
    wb.save(OUT)

    # Write VBA module to .bas file
    print(f"  Writing {BAS.name} …")
    BAS.write_text(VBA_BAS, encoding="utf-8")

    size = OUT.stat().st_size
    print(f"\nDone.")
    print(f"  Workbook : {OUT}  ({size//1024} KB)")
    print(f"  VBA code : {BAS}")
    print()
    print("=" * 60)
    print("ONE-TIME SETUP — import the VBA module:")
    print("  1. Open THD_OAM_VBA_Report.xlsx")
    print("  2. Press Alt + F11  (opens VBA Editor)")
    print("  3. Right-click 'VBAProject (THD_OAM_VBA_Report)'")
    print("  4. Choose 'Import File…'")
    print(f"  5. Select:  {BAS.name}  -> click Open")
    print("  6. Press Alt + Q to close VBE")
    print("  7. Press Alt + F8 -> select 'AddButtons' -> click Run")
    print("     (This replaces the styled cells with real clickable buttons)")
    print("  8. Save — when prompted, choose 'Save as Macro-Enabled (.xlsm)'")
    print("  9. Buttons are now live!")
    print("=" * 60)


if __name__ == "__main__":
    main()
